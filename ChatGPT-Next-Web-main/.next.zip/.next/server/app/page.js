(() => {
var exports = {};
exports.id = 931;
exports.ids = [931];
exports.modules = {

/***/ 8038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 8704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 7897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 6786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 5232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param.js");

/***/ }),

/***/ 8652:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 9274:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 1668:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1109:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 7782:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 3349:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 2081:
/***/ ((module) => {

"use strict";
module.exports = require("child_process");

/***/ }),

/***/ 1017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 7282:
/***/ ((module) => {

"use strict";
module.exports = require("process");

/***/ }),

/***/ 7310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 1935:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var _defs, _mask;
function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

var SvgAdd = function SvgAdd(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", _extends({
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
    width: 16,
    height: 16,
    fill: "none"
  }, props), _defs || (_defs = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("defs", null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    id: "add_svg__a",
    d: "M0 0h16v16H0z"
  }))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", null, _mask || (_mask = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("mask", {
    id: "add_svg__b",
    fill: "#fff"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("use", {
    xlinkHref: "#add_svg__a"
  }))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    mask: "url(#add_svg__b)"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    style: {
      stroke: "#333",
      strokeWidth: 1.3333333333333333,
      strokeOpacity: 1,
      strokeDasharray: "0 0"
    },
    transform: "translate(1.333 1.333)",
    d: "M13.33 6.67A6.66 6.66 0 0 0 6.67 0C2.98 0 0 2.98 0 6.67a6.66 6.66 0 0 0 6.67 6.66c3.68 0 6.66-2.98 6.66-6.66Z"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    style: {
      stroke: "#333",
      strokeWidth: 1.3333333333333333,
      strokeOpacity: 1,
      strokeDasharray: "0 0"
    },
    transform: "translate(8 5.333)",
    d: "M0 0v5.33"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    style: {
      stroke: "#333",
      strokeWidth: 1.3333333333333333,
      strokeOpacity: 1,
      strokeDasharray: "0 0"
    },
    transform: "translate(5.333 8)",
    d: "M0 0h5.33"
  }))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SvgAdd);

/***/ }),

/***/ 3106:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var _defs, _rect, _mask, _mask2;
function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

var SvgBot = function SvgBot(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", _extends({
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
    width: 30,
    height: 30,
    fill: "none"
  }, props), _defs || (_defs = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("defs", null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    id: "bot_svg__a",
    d: "M0 0h30v30H0z"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    id: "bot_svg__c",
    d: "M0 0h20.455v20.455H0z"
  }))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", null, _rect || (_rect = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("rect", {
    fill: "#E7F8FF",
    width: 30,
    height: 30,
    rx: 10
  })), _mask || (_mask = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("mask", {
    id: "bot_svg__b",
    fill: "#fff"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("use", {
    xlinkHref: "#bot_svg__a"
  }))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    mask: "url(#bot_svg__b)"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    transform: "translate(4.773 4.773)"
  }, _mask2 || (_mask2 = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("mask", {
    id: "bot_svg__d",
    fill: "#fff"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("use", {
    xlinkHref: "#bot_svg__c"
  }))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    mask: "url(#bot_svg__d)"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    fillRule: "evenodd",
    style: {
      fill: "#1f948c"
    },
    d: "M19.11 8.37c.17-.52.26-1.06.26-1.61 0-.9-.24-1.79-.71-2.57a5.24 5.24 0 0 0-4.53-2.59c-.37 0-.73.04-1.09.11A5.201 5.201 0 0 0 9.17 0h-.04C6.86 0 4.86 1.44 4.16 3.57A5.11 5.11 0 0 0 .71 6.04C.24 6.83 0 7.72 0 8.63c0 1.27.48 2.51 1.35 3.45-.18.52-.27 1.07-.27 1.61 0 .91.25 1.8.71 2.58 1.13 1.94 3.41 2.94 5.63 2.47a5.18 5.18 0 0 0 3.86 1.71h.05c2.26 0 4.27-1.44 4.97-3.57a5.132 5.132 0 0 0 3.45-2.47c.46-.78.7-1.67.7-2.58 0-1.28-.48-2.51-1.34-3.46ZM8.947 18.158c-.04.03-.08.05-.12.07.7.58 1.57.89 2.48.89h.01c2.14 0 3.88-1.72 3.88-3.83v-4.76c0-.02-.02-.04-.04-.05l-1.74-.99v5.75c0 .23-.13.45-.34.57l-4.13 2.35Zm-.67-1.153 4.17-2.38c.02-.01.03-.03.03-.05v-1.99l-5.04 2.87c-.21.12-.47.12-.68 0l-4.13-2.35c-.04-.02-.09-.06-.12-.07-.04.21-.06.43-.06.65 0 .67.18 1.33.52 1.92v-.01c.7 1.19 1.98 1.92 3.37 1.92.68 0 1.35-.18 1.94-.51ZM3.903 5.168v-.14c-.85.31-1.57.9-2.02 1.68a3.78 3.78 0 0 0-.52 1.91c0 1.37.74 2.64 1.94 3.33l4.17 2.37c.02.01.04.01.06 0l1.75-1-5.04-2.87a.64.64 0 0 1-.34-.57v-4.71Zm13.253 3.337-4.18-2.38c-.02 0-.04 0-.06.01l-1.74.99 5.04 2.87c.21.12.34.34.34.58v4.85c1.52-.56 2.54-1.99 2.54-3.6 0-1.37-.74-2.63-1.94-3.32ZM8.014 5.83c-.02.01-.03.03-.03.05v1.99L13.024 5a.692.692 0 0 1 .68 0l4.13 2.35c.04.02.08.05.12.07.03-.21.05-.43.05-.65 0-2.11-1.74-3.83-3.88-3.83-.68 0-1.35.18-1.94.51l-4.17 2.38Zm1.133-4.492c-2.15 0-3.89 1.72-3.89 3.83v4.76c0 .02.02.03.03.04l1.75 1v-5.75c0-.23.13-.45.34-.57l4.13-2.35c.04-.03.09-.06.12-.07-.7-.58-1.58-.89-2.48-.89ZM7.983 11.51l2.24 1.27 2.25-1.27V8.95l-2.25-1.28-2.24 1.28v2.56Z"
  }))))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SvgBot);

/***/ }),

/***/ 4299:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var _defs, _mask;
function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

var SvgClose = function SvgClose(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", _extends({
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
    width: 16,
    height: 16,
    fill: "none"
  }, props), _defs || (_defs = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("defs", null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    id: "close_svg__a",
    d: "M0 0h16v16H0z"
  }))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", null, _mask || (_mask = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("mask", {
    id: "close_svg__b",
    fill: "#fff"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("use", {
    xlinkHref: "#close_svg__a"
  }))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    mask: "url(#close_svg__b)"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    style: {
      stroke: "#333",
      strokeWidth: 1.3333333333333333,
      strokeOpacity: 1,
      strokeDasharray: "0 0"
    },
    transform: "translate(2.667 2.667)",
    d: "m0 0 10.67 10.67M0 10.67 10.67 0"
  }))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SvgClose);

/***/ }),

/***/ 3231:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var _defs, _mask;
function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

var SvgCopy = function SvgCopy(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", _extends({
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
    width: 16,
    height: 16,
    fill: "none"
  }, props), _defs || (_defs = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("defs", null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    id: "copy_svg__a",
    d: "M0 0h16v16H0z"
  }))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", null, _mask || (_mask = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("mask", {
    id: "copy_svg__b",
    fill: "#fff"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("use", {
    xlinkHref: "#copy_svg__a"
  }))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    mask: "url(#copy_svg__b)"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    style: {
      stroke: "#333",
      strokeWidth: 1.3333333333333333,
      strokeOpacity: 1,
      strokeDasharray: "0 0"
    },
    transform: "translate(4.333 1.667)",
    d: "M0 2.48V.94C0 .42.42 0 .94 0h8.12c.52 0 .94.42.94.94v8.12c0 .52-.42.94-.94.94H7.51"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    style: {
      stroke: "#333",
      strokeWidth: 1.3333333333333333,
      strokeOpacity: 1,
      strokeDasharray: "0 0"
    },
    transform: "translate(1.667 4.333)",
    d: "M.94 0C.42 0 0 .42 0 .94v8.12c0 .52.42.94.94.94h8.12c.52 0 .94-.42.94-.94V.94C10 .42 9.58 0 9.06 0H.94Z"
  }))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SvgCopy);

/***/ }),

/***/ 7360:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var _path, _path2;
function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

var SvgDelete = function SvgDelete(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", _extends({
    xmlns: "http://www.w3.org/2000/svg",
    fill: "none",
    width: 14.663,
    height: 14.663
  }, props), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    style: {
      mixBlendMode: "passthrough"
    }
  }, _path || (_path = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    d: "M7.337.667c-3.69 0-6.67 2.98-6.67 6.67a6.66 6.66 0 0 0 6.67 6.66c3.68 0 6.66-2.98 6.66-6.66a6.66 6.66 0 0 0-6.66-6.67Z",
    fillRule: "evenodd",
    fill: "#D8D8D8",
    fillOpacity: 0.01
  })), _path2 || (_path2 = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    d: "m10.138 5.471-4.667 4.667q-.046.046-.1.083-.055.036-.116.062-.06.025-.125.038-.064.012-.13.012t-.13-.012q-.064-.013-.125-.038-.06-.026-.115-.062-.055-.037-.101-.083-.047-.046-.083-.101-.037-.055-.062-.115-.025-.06-.038-.125-.013-.065-.013-.13 0-.066.013-.13.013-.065.038-.125.025-.061.062-.116.036-.054.083-.1l4.666-4.667q.047-.047.101-.083.055-.037.116-.062.06-.025.125-.038.064-.013.13-.013.065 0 .13.013.064.013.125.038.06.025.115.062.055.036.101.083.046.046.083.1.036.055.062.116.025.06.038.125.012.064.012.13t-.012.13q-.013.064-.038.125-.026.06-.062.115-.037.055-.083.101ZM5.471 4.53l.667.666q.046.047.083.101.036.055.062.116.025.06.038.125.012.064.012.13 0 .065-.012.13-.013.064-.038.125-.026.06-.062.115-.036.055-.083.101-.046.046-.1.083-.056.036-.116.062-.06.025-.125.038-.065.012-.13.012-.066 0-.13-.012-.065-.013-.125-.038-.061-.026-.116-.062-.054-.036-.1-.083l-.667-.667q-.047-.046-.083-.1-.037-.055-.062-.116-.025-.06-.038-.125-.013-.064-.013-.13t.013-.13q.013-.064.038-.125.025-.06.062-.115.036-.055.083-.101.046-.047.1-.083.055-.037.116-.062.06-.025.125-.038.064-.013.13-.013t.13.013q.064.013.125.038.06.025.115.062.055.036.101.083Zm4 4 .667.666q.046.047.083.101.036.055.062.116.025.06.038.125.012.064.012.13 0 .065-.012.13-.013.064-.038.125-.026.06-.062.115-.036.055-.083.101-.046.046-.1.083-.056.036-.116.062-.06.025-.125.038-.065.012-.13.012-.066 0-.13-.012-.065-.013-.125-.038-.061-.026-.116-.062-.054-.036-.1-.083l-.667-.667q-.047-.046-.083-.1-.037-.055-.062-.116-.025-.06-.038-.125-.013-.064-.013-.13t.013-.13q.013-.064.038-.125.025-.06.062-.115.036-.055.083-.101.046-.047.1-.083.055-.037.116-.062.06-.025.125-.038.064-.013.13-.013t.13.013q.064.013.125.038.06.025.115.062.055.036.101.083Zm3.859-1.192q0-2.491-1.755-4.248-1.754-1.756-4.238-1.756-2.492 0-4.248 1.756-1.756 1.756-1.756 4.248 0 2.484 1.756 4.238 1.757 1.755 4.248 1.755 2.484 0 4.238-1.755 1.755-1.754 1.755-4.238Zm1.333 0q0 3.036-2.145 5.181t-5.181 2.145q-3.043 0-5.19-2.145Q0 10.374 0 7.337q0-3.044 2.147-5.19Q4.293 0 7.337 0q3.037 0 5.181 2.147 2.145 2.147 2.145 5.19ZM10.332 5q0 .066-.013.13t-.038.125q-.025.06-.061.114-.037.055-.083.101-.046.047-.1.083-.055.036-.116.061-.06.025-.125.038-.064.013-.13.013-.065 0-.13-.013-.063-.013-.124-.038-.06-.025-.115-.061-.054-.036-.1-.083-.047-.046-.083-.1-.037-.055-.062-.115-.025-.061-.038-.125-.012-.064-.012-.13 0-.065.012-.13.013-.064.038-.124.025-.061.062-.115.036-.055.082-.101.047-.047.101-.083.055-.036.115-.061.06-.025.125-.038.064-.013.13-.013.065 0 .13.013.064.013.124.038t.115.061q.055.036.1.083.047.046.084.1.036.055.061.116.025.06.038.124.013.065.013.13ZM5.665 9.667q0 .065-.013.13-.013.064-.038.124t-.061.115q-.036.055-.083.1-.046.047-.1.084-.055.036-.116.061-.06.025-.124.038-.064.013-.13.013-.065 0-.13-.013-.064-.013-.124-.038-.061-.025-.115-.061-.055-.037-.101-.083-.047-.046-.083-.1-.036-.055-.061-.116-.025-.06-.038-.125-.013-.064-.013-.13 0-.065.013-.13.013-.063.038-.124.025-.06.061-.115.036-.054.083-.1.046-.047.1-.083.055-.037.116-.062.06-.025.124-.038.065-.012.13-.012.066 0 .13.012.064.013.124.038.061.025.115.062.055.036.101.082.047.047.083.101.036.055.061.115.025.06.038.125.013.064.013.13Zm0-4.667q0 .066-.013.13t-.038.125q-.025.06-.061.114-.036.055-.083.101-.046.047-.1.083-.055.036-.116.061-.06.025-.124.038-.064.013-.13.013-.065 0-.13-.013-.064-.013-.124-.038-.061-.025-.115-.061-.055-.036-.101-.083-.047-.046-.083-.1-.036-.055-.061-.115-.025-.061-.038-.125-.013-.064-.013-.13 0-.065.013-.13.013-.064.038-.124.025-.061.061-.115.036-.055.083-.101.046-.047.1-.083.055-.036.116-.061.06-.025.124-.038.065-.013.13-.013.066 0 .13.013t.124.038q.061.025.115.061.055.036.101.083.047.046.083.1.036.055.061.116.025.06.038.124.013.065.013.13Zm.667.667q0 .065-.013.13-.013.064-.038.124t-.061.115q-.037.055-.083.1-.046.047-.1.084-.055.036-.116.061-.06.025-.125.038-.064.013-.13.013-.065 0-.13-.013-.063-.013-.124-.038-.06-.025-.115-.061-.054-.037-.1-.083-.047-.046-.083-.1-.037-.055-.062-.116-.025-.06-.038-.125-.012-.064-.012-.13 0-.065.012-.13.013-.063.038-.124.025-.06.062-.115.036-.054.082-.1.047-.047.101-.083.055-.037.115-.062.06-.025.125-.038.064-.012.13-.012.065 0 .13.012.064.013.124.038t.115.062q.055.036.1.082.047.047.084.101.036.055.061.115.025.06.038.125.013.064.013.13ZM9.665 9q0 .066-.013.13t-.038.125q-.025.06-.061.114-.036.055-.083.101-.046.047-.1.083-.055.036-.116.061-.06.025-.124.038-.064.013-.13.013-.065 0-.13-.013-.064-.013-.124-.038-.061-.025-.115-.061-.055-.036-.101-.083-.047-.046-.083-.1-.036-.055-.061-.115-.025-.061-.038-.125-.013-.064-.013-.13 0-.065.013-.13.013-.064.038-.124.025-.061.061-.115.036-.055.083-.101.046-.047.1-.083.055-.036.116-.061.06-.025.124-.038.065-.013.13-.013.066 0 .13.013t.124.038q.061.025.115.061.055.036.101.083.047.046.083.1.036.055.061.116.025.06.038.124.013.065.013.13Zm.667.667q0 .065-.013.13-.013.064-.038.124t-.061.115q-.037.055-.083.1-.046.047-.1.084-.055.036-.116.061-.06.025-.125.038-.064.013-.13.013-.065 0-.13-.013-.063-.013-.124-.038-.06-.025-.115-.061-.054-.037-.1-.083-.047-.046-.083-.1-.037-.055-.062-.116-.025-.06-.038-.125-.012-.064-.012-.13 0-.065.012-.13.013-.063.038-.124.025-.06.062-.115.036-.054.082-.1.047-.047.101-.083.055-.037.115-.062.06-.025.125-.038.064-.012.13-.012.065 0 .13.012.064.013.124.038t.115.062q.055.036.1.082.047.047.084.101.036.055.061.115.025.06.038.125.013.064.013.13Z",
    fill: "var(--primary)"
  }))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SvgDelete);

/***/ }),

/***/ 3076:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var _circle, _circle2, _circle3;
function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

var SvgThreeDots = function SvgThreeDots(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", _extends({
    width: 30,
    height: 14,
    viewBox: "0 0 120 30",
    xmlns: "http://www.w3.org/2000/svg",
    fill: "#fff"
  }, props), _circle || (_circle = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("circle", {
    cx: 15,
    cy: 15,
    r: 15,
    fill: "var(--primary, red)"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("animate", {
    attributeName: "r",
    from: 15,
    to: 15,
    begin: "0s",
    dur: "0.8s",
    values: "15;9;15",
    calcMode: "linear",
    repeatCount: "indefinite"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("animate", {
    attributeName: "fill-opacity",
    from: 1,
    to: 1,
    begin: "0s",
    dur: "0.8s",
    values: "1;.5;1",
    calcMode: "linear",
    repeatCount: "indefinite"
  }))), _circle2 || (_circle2 = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("circle", {
    cx: 60,
    cy: 15,
    r: 9,
    fillOpacity: 0.3,
    fill: "var(--primary, red)"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("animate", {
    attributeName: "r",
    from: 9,
    to: 9,
    begin: "0s",
    dur: "0.8s",
    values: "9;15;9",
    calcMode: "linear",
    repeatCount: "indefinite"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("animate", {
    attributeName: "fill-opacity",
    from: 0.5,
    to: 0.5,
    begin: "0s",
    dur: "0.8s",
    values: ".5;1;.5",
    calcMode: "linear",
    repeatCount: "indefinite"
  }))), _circle3 || (_circle3 = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("circle", {
    cx: 105,
    cy: 15,
    r: 15,
    fill: "var(--primary, red)"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("animate", {
    attributeName: "r",
    from: 15,
    to: 15,
    begin: "0s",
    dur: "0.8s",
    values: "15;9;15",
    calcMode: "linear",
    repeatCount: "indefinite"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("animate", {
    attributeName: "fill-opacity",
    from: 1,
    to: 1,
    begin: "0s",
    dur: "0.8s",
    values: "1;.5;1",
    calcMode: "linear",
    repeatCount: "indefinite"
  }))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SvgThreeDots);

/***/ }),

/***/ 1890:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppRouter": () => (/* reexport default from dynamic */ next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   "GlobalError": () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default.a),
/* harmony export */   "LayoutRouter": () => (/* reexport default from dynamic */ next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default.a),
/* harmony export */   "RenderFromTemplateContext": () => (/* reexport default from dynamic */ next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   "StaticGenerationSearchParamsBailoutProvider": () => (/* reexport default from dynamic */ next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_7___default.a),
/* harmony export */   "__next_app_webpack_require__": () => (/* binding */ __next_app_webpack_require__),
/* harmony export */   "createSearchParamsBailoutProxy": () => (/* reexport safe */ next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_8__.createSearchParamsBailoutProxy),
/* harmony export */   "decodeReply": () => (/* reexport safe */ next_dist_compiled_react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_10__.decodeReply),
/* harmony export */   "pages": () => (/* binding */ pages),
/* harmony export */   "renderToReadableStream": () => (/* reexport safe */ next_dist_compiled_react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_10__.renderToReadableStream),
/* harmony export */   "requestAsyncStorage": () => (/* reexport safe */ next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__.requestAsyncStorage),
/* harmony export */   "serverHooks": () => (/* reexport module object */ next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_9__),
/* harmony export */   "staticGenerationAsyncStorage": () => (/* reexport safe */ next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__.staticGenerationAsyncStorage),
/* harmony export */   "staticGenerationBailout": () => (/* reexport safe */ next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_6__.staticGenerationBailout),
/* harmony export */   "tree": () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8829);
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5226);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2872);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8412);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1839);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5120);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9282);
/* harmony import */ var next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3785);
/* harmony import */ var next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5183);
/* harmony import */ var next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(5815);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var next_dist_compiled_react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(6370);

    const tree = {
        children: [
        '',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 3877)), "E:\\code\\ChatGPT-Next-Web-main\\app\\page.tsx"],
          
        }]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 8666)), "E:\\code\\ChatGPT-Next-Web-main\\app\\layout.tsx"],
          
        }
      ]
      }.children;
    const pages = ["E:\\code\\ChatGPT-Next-Web-main\\app\\page.tsx"];

    
    
    
    

    

    

    
    
    

    

    
    const __next_app_webpack_require__ = __webpack_require__
  

/***/ }),

/***/ 8636:
/***/ (() => {



/***/ }),

/***/ 1681:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 5900));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 1780))

/***/ }),

/***/ 7112:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 9222, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 8301, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 3751, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 4765, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 5192, 23))

/***/ }),

/***/ 554:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "h": () => (/* binding */ IconButton)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _button_module_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(373);
/* harmony import */ var _button_module_scss__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_button_module_scss__WEBPACK_IMPORTED_MODULE_2__);



function IconButton(props) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
        className: (_button_module_scss__WEBPACK_IMPORTED_MODULE_2___default()["icon-button"]) + ` ${props.bordered && (_button_module_scss__WEBPACK_IMPORTED_MODULE_2___default().border)} ${props.shadow && (_button_module_scss__WEBPACK_IMPORTED_MODULE_2___default().shadow)} ${props.className ?? ""} clickable`,
        onClick: props.onClick,
        title: props.title,
        disabled: props.disabled,
        role: "button",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_button_module_scss__WEBPACK_IMPORTED_MODULE_2___default()["icon-button-icon"]) + ` ${props.noDark && "no-dark"}`,
                children: props.icon
            }),
            props.text && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_button_module_scss__WEBPACK_IMPORTED_MODULE_2___default()["icon-button-text"]),
                children: props.text
            })
        ]
    });
}


/***/ }),

/***/ 1741:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "qE": () => (/* binding */ Avatar),
  "en": () => (/* binding */ Chat)
});

// UNUSED EXPORTS: ChatActions, PromptHints

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6786);
// EXTERNAL MODULE: ./node_modules/use-debounce/dist/index.module.js
var index_module = __webpack_require__(238);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(8038);
;// CONCATENATED MODULE: ./app/icons/send-white.svg
var _defs, _mask;
function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

var SvgSendWhite = function SvgSendWhite(props) {
  return /*#__PURE__*/react_.createElement("svg", _extends({
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
    width: 16,
    height: 16,
    fill: "none"
  }, props), _defs || (_defs = /*#__PURE__*/react_.createElement("defs", null, /*#__PURE__*/react_.createElement("path", {
    id: "send-white_svg__a",
    d: "M0 0h16v16H0z"
  }))), /*#__PURE__*/react_.createElement("g", null, _mask || (_mask = /*#__PURE__*/react_.createElement("mask", {
    id: "send-white_svg__b",
    fill: "#fff"
  }, /*#__PURE__*/react_.createElement("use", {
    xlinkHref: "#send-white_svg__a"
  }))), /*#__PURE__*/react_.createElement("g", {
    mask: "url(#send-white_svg__b)"
  }, /*#__PURE__*/react_.createElement("path", {
    style: {
      stroke: "#fff",
      strokeWidth: 1.3333333333333333,
      strokeOpacity: 1,
      strokeDasharray: "0 0"
    },
    transform: "translate(1.333 2)",
    d: "M0 4.71 6.67 6l1.67 6.67L12.67 0 0 4.71Z"
  }), /*#__PURE__*/react_.createElement("path", {
    style: {
      stroke: "#fff",
      strokeWidth: 1.3333333333333333,
      strokeOpacity: 1,
      strokeDasharray: "0 0"
    },
    transform: "translate(8.003 6.117)",
    d: "M0 1.89 1.89 0"
  }))));
};
/* harmony default export */ const send_white = (SvgSendWhite);
;// CONCATENATED MODULE: ./app/icons/brain.svg
var brain_defs, brain_mask;
function brain_extends() { brain_extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return brain_extends.apply(this, arguments); }

var SvgBrain = function SvgBrain(props) {
  return /*#__PURE__*/react_.createElement("svg", brain_extends({
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
    width: 16,
    height: 16,
    fill: "none"
  }, props), brain_defs || (brain_defs = /*#__PURE__*/react_.createElement("defs", null, /*#__PURE__*/react_.createElement("path", {
    id: "brain_svg__a",
    d: "M0 0h16v16H0z"
  }))), /*#__PURE__*/react_.createElement("g", null, brain_mask || (brain_mask = /*#__PURE__*/react_.createElement("mask", {
    id: "brain_svg__b",
    fill: "#fff"
  }, /*#__PURE__*/react_.createElement("use", {
    xlinkHref: "#brain_svg__a"
  }))), /*#__PURE__*/react_.createElement("g", {
    mask: "url(#brain_svg__b)"
  }, /*#__PURE__*/react_.createElement("path", {
    style: {
      stroke: "#333",
      strokeWidth: 1.3333333333333333,
      strokeOpacity: 1,
      strokeDasharray: "0 0"
    },
    transform: "translate(1.333 1.333)",
    d: "M5.01 13.33c-.32-1.06-.82-1.86-1.48-2.38-.98-.78-2.56-.3-3.14-1.11-.58-.8.41-2.29.76-3.17.34-.88-1.33-1.19-1.13-1.44.13-.16.97-.64 2.53-1.44C3 1.26 4.63 0 7.47 0c4.24 0 5.86 3.6 5.86 5.89 0 2.29-1.96 4.76-4.75 5.29-.25.37.11 1.08 1.08 2.15"
  }), /*#__PURE__*/react_.createElement("path", {
    style: {
      stroke: "#333",
      strokeWidth: 1.3333333333333333,
      strokeOpacity: 1,
      strokeDasharray: "0 0"
    },
    transform: "translate(6.374 3.957)",
    d: "M2.1 3.33c-.19 1.09.04 1.6.69 1.53.65-.07 1.05-.34 1.18-.81 1.02.28 1.57.04 1.66-.72.12-1.15-.5-2.07-.75-2.07s-.91-.03-.91-.38C3.97.52 3.2.33 2.5.33c-.69 0-.27-.47-1.23-.29C.64.17.26.44.13.88c-.22.84-.16 1.43.19 1.78.35.34.94.56 1.78.67Z"
  }), /*#__PURE__*/react_.createElement("path", {
    style: {
      stroke: "#333",
      strokeWidth: 1.3333333333333333,
      strokeOpacity: 1,
      strokeDasharray: "0 0"
    },
    transform: "translate(8.193 8.5)",
    d: "M1.97 0c-.34.21-.8.56-1 .83-.49.69-.88 1.1-.97 1.54"
  }))));
};
/* harmony default export */ const brain = (SvgBrain);
;// CONCATENATED MODULE: ./app/icons/rename.svg
var rename_defs, rename_mask;
function rename_extends() { rename_extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return rename_extends.apply(this, arguments); }

var SvgRename = function SvgRename(props) {
  return /*#__PURE__*/react_.createElement("svg", rename_extends({
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
    width: 16,
    height: 16,
    fill: "none"
  }, props), rename_defs || (rename_defs = /*#__PURE__*/react_.createElement("defs", null, /*#__PURE__*/react_.createElement("path", {
    id: "rename_svg__a",
    d: "M0 0h16v16H0z"
  }))), /*#__PURE__*/react_.createElement("g", null, rename_mask || (rename_mask = /*#__PURE__*/react_.createElement("mask", {
    id: "rename_svg__b",
    fill: "#fff"
  }, /*#__PURE__*/react_.createElement("use", {
    xlinkHref: "#rename_svg__a"
  }))), /*#__PURE__*/react_.createElement("g", {
    mask: "url(#rename_svg__b)"
  }, /*#__PURE__*/react_.createElement("path", {
    style: {
      stroke: "#333",
      strokeWidth: 1.3333333333333333,
      strokeOpacity: 1,
      strokeDasharray: "0 0"
    },
    transform: "translate(1.775 1.3)",
    d: "M2.83 13.2 13.2 2.83 10.37 0 0 10.37v2.83h2.83Z"
  }), /*#__PURE__*/react_.createElement("path", {
    style: {
      stroke: "#333",
      strokeWidth: 1.3333333333333333,
      strokeOpacity: 1,
      strokeDasharray: "0 0"
    },
    transform: "translate(9.317 4.13)",
    d: "m0 0 2.83 2.83"
  }))));
};
/* harmony default export */ const rename = (SvgRename);
;// CONCATENATED MODULE: ./app/icons/share.svg
var share_defs, share_mask;
function share_extends() { share_extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return share_extends.apply(this, arguments); }

var SvgShare = function SvgShare(props) {
  return /*#__PURE__*/react_.createElement("svg", share_extends({
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
    width: 16,
    height: 16,
    fill: "none"
  }, props), share_defs || (share_defs = /*#__PURE__*/react_.createElement("defs", null, /*#__PURE__*/react_.createElement("path", {
    id: "share_svg__a",
    d: "M0 0h16v16H0z"
  }))), /*#__PURE__*/react_.createElement("g", null, share_mask || (share_mask = /*#__PURE__*/react_.createElement("mask", {
    id: "share_svg__b",
    fill: "#fff"
  }, /*#__PURE__*/react_.createElement("use", {
    xlinkHref: "#share_svg__a"
  }))), /*#__PURE__*/react_.createElement("g", {
    mask: "url(#share_svg__b)"
  }, /*#__PURE__*/react_.createElement("path", {
    style: {
      stroke: "#333",
      strokeWidth: 1.3333333333333333,
      strokeOpacity: 1,
      strokeDasharray: "0 0"
    },
    transform: "translate(2 1.333)",
    d: "M6.67 3.67C1.67 3.67 0 7.33 0 13c0 0 2-5 6.67-5v3.67l6-5.67-6-6v3.67Z"
  }))));
};
/* harmony default export */ const share = (SvgShare);
;// CONCATENATED MODULE: ./app/icons/return.svg
var return_defs, return_mask;
function return_extends() { return_extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return return_extends.apply(this, arguments); }

var SvgReturn = function SvgReturn(props) {
  return /*#__PURE__*/react_.createElement("svg", return_extends({
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
    width: 16,
    height: 16,
    fill: "none"
  }, props), return_defs || (return_defs = /*#__PURE__*/react_.createElement("defs", null, /*#__PURE__*/react_.createElement("path", {
    id: "return_svg__a",
    d: "M0 0h16v16H0z"
  }))), /*#__PURE__*/react_.createElement("g", null, return_mask || (return_mask = /*#__PURE__*/react_.createElement("mask", {
    id: "return_svg__b",
    fill: "#fff"
  }, /*#__PURE__*/react_.createElement("use", {
    xlinkHref: "#return_svg__a"
  }))), /*#__PURE__*/react_.createElement("g", {
    mask: "url(#return_svg__b)"
  }, /*#__PURE__*/react_.createElement("path", {
    style: {
      stroke: "#333",
      strokeWidth: 1.3333333333333333,
      strokeOpacity: 1,
      strokeDasharray: "0 0"
    },
    transform: "translate(2 2.667)",
    d: "M2.33 0 0 2l2.33 2.33"
  }), /*#__PURE__*/react_.createElement("path", {
    style: {
      stroke: "#333",
      strokeWidth: 1.3333333333333333,
      strokeOpacity: 1,
      strokeDasharray: "0 0"
    },
    transform: "translate(2 4.667)",
    d: "M0 0h7.66c2.3 0 4.25 1.87 4.34 4.17.09 2.42-1.91 4.5-4.34 4.5H2"
  }))));
};
/* harmony default export */ const icons_return = (SvgReturn);
// EXTERNAL MODULE: ./app/icons/copy.svg
var copy = __webpack_require__(3231);
;// CONCATENATED MODULE: ./app/icons/download.svg
var download_defs, download_mask;
function download_extends() { download_extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return download_extends.apply(this, arguments); }

var SvgDownload = function SvgDownload(props) {
  return /*#__PURE__*/react_.createElement("svg", download_extends({
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
    width: 16,
    height: 16,
    fill: "none"
  }, props), download_defs || (download_defs = /*#__PURE__*/react_.createElement("defs", null, /*#__PURE__*/react_.createElement("path", {
    id: "download_svg__a",
    d: "M0 0h16v16H0z"
  }))), /*#__PURE__*/react_.createElement("g", null, download_mask || (download_mask = /*#__PURE__*/react_.createElement("mask", {
    id: "download_svg__b",
    fill: "#fff"
  }, /*#__PURE__*/react_.createElement("use", {
    xlinkHref: "#download_svg__a"
  }))), /*#__PURE__*/react_.createElement("g", {
    mask: "url(#download_svg__b)"
  }, /*#__PURE__*/react_.createElement("path", {
    style: {
      stroke: "#333",
      strokeWidth: 1.3333333333333333,
      strokeOpacity: 1,
      strokeDasharray: "0 0"
    },
    transform: "translate(2 2)",
    d: "M1 12h10c.55 0 1-.45 1-1V1c0-.55-.45-1-1-1H1C.45 0 0 .45 0 1v10c0 .55.45 1 1 1Z"
  }), /*#__PURE__*/react_.createElement("path", {
    style: {
      stroke: "#333",
      strokeWidth: 1.3333333333333333,
      strokeOpacity: 1,
      strokeDasharray: "0 0"
    },
    transform: "translate(1.333 10.333)",
    d: "M0 0h3.67l.66 1.33H9L9.67 0h3.66"
  }), /*#__PURE__*/react_.createElement("path", {
    style: {
      stroke: "#333",
      strokeWidth: 1.3333333333333333,
      strokeOpacity: 1,
      strokeDasharray: "0 0"
    },
    transform: "translate(14 8.667)",
    d: "M0 3.33V0"
  }), /*#__PURE__*/react_.createElement("path", {
    style: {
      stroke: "#333",
      strokeWidth: 1.3333333333333333,
      strokeOpacity: 1,
      strokeDasharray: "0 0"
    },
    transform: "translate(6 7.333)",
    d: "m0 0 2 2 2-2"
  }), /*#__PURE__*/react_.createElement("path", {
    style: {
      stroke: "#333",
      strokeWidth: 1.3333333333333333,
      strokeOpacity: 1,
      strokeDasharray: "0 0"
    },
    transform: "translate(8 4)",
    d: "M0 5.33V0"
  }), /*#__PURE__*/react_.createElement("path", {
    style: {
      stroke: "#333",
      strokeWidth: 1.3333333333333333,
      strokeOpacity: 1,
      strokeDasharray: "0 0"
    },
    transform: "translate(2 8.667)",
    d: "M0 3.33V0"
  }))));
};
/* harmony default export */ const download = (SvgDownload);
// EXTERNAL MODULE: ./app/icons/three-dots.svg
var three_dots = __webpack_require__(3076);
// EXTERNAL MODULE: ./app/icons/bot.svg
var bot = __webpack_require__(3106);
;// CONCATENATED MODULE: ./app/icons/black-bot.svg
var black_bot_defs, _rect, black_bot_mask, _mask2;
function black_bot_extends() { black_bot_extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return black_bot_extends.apply(this, arguments); }

var SvgBlackBot = function SvgBlackBot(props) {
  return /*#__PURE__*/react_.createElement("svg", black_bot_extends({
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
    width: 30,
    height: 30,
    fill: "none"
  }, props), black_bot_defs || (black_bot_defs = /*#__PURE__*/react_.createElement("defs", null, /*#__PURE__*/react_.createElement("path", {
    id: "black-bot_svg__a",
    d: "M0 0h30v30H0z"
  }), /*#__PURE__*/react_.createElement("path", {
    id: "black-bot_svg__c",
    d: "M0 0h20.455v20.455H0z"
  }))), /*#__PURE__*/react_.createElement("g", null, _rect || (_rect = /*#__PURE__*/react_.createElement("rect", {
    fill: "#E7F8FF",
    width: 30,
    height: 30,
    rx: 10
  })), black_bot_mask || (black_bot_mask = /*#__PURE__*/react_.createElement("mask", {
    id: "black-bot_svg__b",
    fill: "#fff"
  }, /*#__PURE__*/react_.createElement("use", {
    xlinkHref: "#black-bot_svg__a"
  }))), /*#__PURE__*/react_.createElement("g", {
    mask: "url(#black-bot_svg__b)"
  }, /*#__PURE__*/react_.createElement("g", {
    transform: "translate(4.773 4.773)"
  }, _mask2 || (_mask2 = /*#__PURE__*/react_.createElement("mask", {
    id: "black-bot_svg__d",
    fill: "#fff"
  }, /*#__PURE__*/react_.createElement("use", {
    xlinkHref: "#black-bot_svg__c"
  }))), /*#__PURE__*/react_.createElement("g", {
    mask: "url(#black-bot_svg__d)"
  }, /*#__PURE__*/react_.createElement("path", {
    fillRule: "evenodd",
    style: {
      fill: "#000"
    },
    d: "M19.11 8.37c.17-.52.26-1.06.26-1.61 0-.9-.24-1.79-.71-2.57a5.24 5.24 0 0 0-4.53-2.59c-.37 0-.73.04-1.09.11A5.201 5.201 0 0 0 9.17 0h-.04C6.86 0 4.86 1.44 4.16 3.57A5.11 5.11 0 0 0 .71 6.04C.24 6.83 0 7.72 0 8.63c0 1.27.48 2.51 1.35 3.45-.18.52-.27 1.07-.27 1.61 0 .91.25 1.8.71 2.58 1.13 1.94 3.41 2.94 5.63 2.47a5.18 5.18 0 0 0 3.86 1.71h.05c2.26 0 4.27-1.44 4.97-3.57a5.132 5.132 0 0 0 3.45-2.47c.46-.78.7-1.67.7-2.58 0-1.28-.48-2.51-1.34-3.46ZM8.947 18.158c-.04.03-.08.05-.12.07.7.58 1.57.89 2.48.89h.01c2.14 0 3.88-1.72 3.88-3.83v-4.76c0-.02-.02-.04-.04-.05l-1.74-.99v5.75c0 .23-.13.45-.34.57l-4.13 2.35Zm-.67-1.153 4.17-2.38c.02-.01.03-.03.03-.05v-1.99l-5.04 2.87c-.21.12-.47.12-.68 0l-4.13-2.35c-.04-.02-.09-.06-.12-.07-.04.21-.06.43-.06.65 0 .67.18 1.33.52 1.92v-.01c.7 1.19 1.98 1.92 3.37 1.92.68 0 1.35-.18 1.94-.51ZM3.903 5.168v-.14c-.85.31-1.57.9-2.02 1.68a3.78 3.78 0 0 0-.52 1.91c0 1.37.74 2.64 1.94 3.33l4.17 2.37c.02.01.04.01.06 0l1.75-1-5.04-2.87a.64.64 0 0 1-.34-.57v-4.71Zm13.253 3.337-4.18-2.38c-.02 0-.04 0-.06.01l-1.74.99 5.04 2.87c.21.12.34.34.34.58v4.85c1.52-.56 2.54-1.99 2.54-3.6 0-1.37-.74-2.63-1.94-3.32ZM8.014 5.83c-.02.01-.03.03-.03.05v1.99L13.024 5a.692.692 0 0 1 .68 0l4.13 2.35c.04.02.08.05.12.07.03-.21.05-.43.05-.65 0-2.11-1.74-3.83-3.88-3.83-.68 0-1.35.18-1.94.51l-4.17 2.38Zm1.133-4.492c-2.15 0-3.89 1.72-3.89 3.83v4.76c0 .02.02.03.03.04l1.75 1v-5.75c0-.23.13-.45.34-.57l4.13-2.35c.04-.03.09-.06.12-.07-.7-.58-1.58-.89-2.48-.89ZM7.983 11.51l2.24 1.27 2.25-1.27V8.95l-2.25-1.28-2.24 1.28v2.56Z"
  }))))));
};
/* harmony default export */ const black_bot = (SvgBlackBot);
// EXTERNAL MODULE: ./app/icons/add.svg
var add = __webpack_require__(1935);
// EXTERNAL MODULE: ./app/icons/delete.svg
var icons_delete = __webpack_require__(7360);
;// CONCATENATED MODULE: ./app/icons/max.svg
var max_defs, max_mask;
function max_extends() { max_extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return max_extends.apply(this, arguments); }

var SvgMax = function SvgMax(props) {
  return /*#__PURE__*/react_.createElement("svg", max_extends({
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
    width: 16,
    height: 16,
    fill: "none"
  }, props), max_defs || (max_defs = /*#__PURE__*/react_.createElement("defs", null, /*#__PURE__*/react_.createElement("path", {
    id: "max_svg__a",
    d: "M0 0h16v16H0z"
  }))), /*#__PURE__*/react_.createElement("g", null, max_mask || (max_mask = /*#__PURE__*/react_.createElement("mask", {
    id: "max_svg__b",
    fill: "#fff"
  }, /*#__PURE__*/react_.createElement("use", {
    xlinkHref: "#max_svg__a"
  }))), /*#__PURE__*/react_.createElement("g", {
    mask: "url(#max_svg__b)"
  }, /*#__PURE__*/react_.createElement("path", {
    style: {
      stroke: "#333",
      strokeWidth: 1.3333333333333333,
      strokeOpacity: 1,
      strokeDasharray: "0 0"
    },
    transform: "translate(2 2)",
    d: "m0 0 3.33 3.3"
  }), /*#__PURE__*/react_.createElement("path", {
    style: {
      stroke: "#333",
      strokeWidth: 1.3333333333333333,
      strokeOpacity: 1,
      strokeDasharray: "0 0"
    },
    transform: "translate(2 10.667)",
    d: "M0 3.3 3.33 0"
  }), /*#__PURE__*/react_.createElement("path", {
    style: {
      stroke: "#333",
      strokeWidth: 1.3333333333333333,
      strokeOpacity: 1,
      strokeDasharray: "0 0"
    },
    transform: "translate(10.7 10.667)",
    d: "M3.3 3.3 0 0"
  }), /*#__PURE__*/react_.createElement("path", {
    style: {
      stroke: "#333",
      strokeWidth: 1.3333333333333333,
      strokeOpacity: 1,
      strokeDasharray: "0 0"
    },
    transform: "translate(10.667 2)",
    d: "M3.3 0 0 3.3"
  }), /*#__PURE__*/react_.createElement("path", {
    style: {
      stroke: "#333",
      strokeWidth: 1.3333333333333333,
      strokeOpacity: 1,
      strokeDasharray: "0 0"
    },
    transform: "translate(11 2)",
    d: "M0 0h3v3"
  }), /*#__PURE__*/react_.createElement("path", {
    style: {
      stroke: "#333",
      strokeWidth: 1.3333333333333333,
      strokeOpacity: 1,
      strokeDasharray: "0 0"
    },
    transform: "translate(11 11)",
    d: "M3 0v3H0"
  }), /*#__PURE__*/react_.createElement("path", {
    style: {
      stroke: "#333",
      strokeWidth: 1.3333333333333333,
      strokeOpacity: 1,
      strokeDasharray: "0 0"
    },
    transform: "translate(2 11)",
    d: "M3 3H0V0"
  }), /*#__PURE__*/react_.createElement("path", {
    style: {
      stroke: "#333",
      strokeWidth: 1.3333333333333333,
      strokeOpacity: 1,
      strokeDasharray: "0 0"
    },
    transform: "translate(2 2)",
    d: "M0 3V0h3"
  }))));
};
/* harmony default export */ const max = (SvgMax);
;// CONCATENATED MODULE: ./app/icons/min.svg
var min_defs, min_mask;
function min_extends() { min_extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return min_extends.apply(this, arguments); }

var SvgMin = function SvgMin(props) {
  return /*#__PURE__*/react_.createElement("svg", min_extends({
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
    width: 16,
    height: 16,
    fill: "none"
  }, props), min_defs || (min_defs = /*#__PURE__*/react_.createElement("defs", null, /*#__PURE__*/react_.createElement("path", {
    id: "min_svg__a",
    d: "M0 0h16v16H0z"
  }))), /*#__PURE__*/react_.createElement("g", null, min_mask || (min_mask = /*#__PURE__*/react_.createElement("mask", {
    id: "min_svg__b",
    fill: "#fff"
  }, /*#__PURE__*/react_.createElement("use", {
    xlinkHref: "#min_svg__a"
  }))), /*#__PURE__*/react_.createElement("g", {
    mask: "url(#min_svg__b)"
  }, /*#__PURE__*/react_.createElement("path", {
    style: {
      stroke: "#333",
      strokeWidth: 1.3333333333333333,
      strokeOpacity: 1,
      strokeDasharray: "0 0"
    },
    transform: "translate(2 2)",
    d: "m0 0 3.33 3.3"
  }), /*#__PURE__*/react_.createElement("path", {
    style: {
      stroke: "#333",
      strokeWidth: 1.3333333333333333,
      strokeOpacity: 1,
      strokeDasharray: "0 0"
    },
    transform: "translate(2 10.667)",
    d: "M0 3.3 3.33 0"
  }), /*#__PURE__*/react_.createElement("path", {
    style: {
      stroke: "#333",
      strokeWidth: 1.3333333333333333,
      strokeOpacity: 1,
      strokeDasharray: "0 0"
    },
    transform: "translate(10.7 10.667)",
    d: "M3.3 3.3 0 0"
  }), /*#__PURE__*/react_.createElement("path", {
    style: {
      stroke: "#333",
      strokeWidth: 1.3333333333333333,
      strokeOpacity: 1,
      strokeDasharray: "0 0"
    },
    transform: "translate(10.667 2)",
    d: "M3.3 0 0 3.3"
  }), /*#__PURE__*/react_.createElement("path", {
    style: {
      stroke: "#333",
      strokeWidth: 1.3333333333333333,
      strokeOpacity: 1,
      strokeDasharray: "0 0"
    },
    transform: "translate(10.667 2.333)",
    d: "M0 0v3h3"
  }), /*#__PURE__*/react_.createElement("path", {
    style: {
      stroke: "#333",
      strokeWidth: 1.3333333333333333,
      strokeOpacity: 1,
      strokeDasharray: "0 0"
    },
    transform: "translate(2.333 2.333)",
    d: "M3 0v3H0"
  }), /*#__PURE__*/react_.createElement("path", {
    style: {
      stroke: "#333",
      strokeWidth: 1.3333333333333333,
      strokeOpacity: 1,
      strokeDasharray: "0 0"
    },
    transform: "translate(2.333 10.667)",
    d: "M3 3V0H0"
  }), /*#__PURE__*/react_.createElement("path", {
    style: {
      stroke: "#333",
      strokeWidth: 1.3333333333333333,
      strokeOpacity: 1,
      strokeDasharray: "0 0"
    },
    transform: "translate(10.667 10.667)",
    d: "M0 3V0h2.97"
  }))));
};
/* harmony default export */ const min = (SvgMin);
;// CONCATENATED MODULE: ./app/icons/light.svg
var light_defs, light_mask;
function light_extends() { light_extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return light_extends.apply(this, arguments); }

var SvgLight = function SvgLight(props) {
  return /*#__PURE__*/react_.createElement("svg", light_extends({
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
    width: 16,
    height: 16,
    fill: "none"
  }, props), light_defs || (light_defs = /*#__PURE__*/react_.createElement("defs", null, /*#__PURE__*/react_.createElement("path", {
    id: "light_svg__a",
    d: "M0 0h16v16H0z"
  }))), /*#__PURE__*/react_.createElement("g", null, light_mask || (light_mask = /*#__PURE__*/react_.createElement("mask", {
    id: "light_svg__b",
    fill: "#fff"
  }, /*#__PURE__*/react_.createElement("use", {
    xlinkHref: "#light_svg__a"
  }))), /*#__PURE__*/react_.createElement("g", {
    mask: "url(#light_svg__b)"
  }, /*#__PURE__*/react_.createElement("path", {
    style: {
      stroke: "#333",
      strokeWidth: 1.3333333333333333,
      strokeOpacity: 1,
      strokeDasharray: "0 0"
    },
    transform: "translate(4.34 4.216)",
    d: "M0 3.67c0 2.02 1.64 3.66 3.67 3.66 2.02 0 3.66-1.64 3.66-3.66a3.664 3.664 0 1 0-7.33 0Z"
  }), /*#__PURE__*/react_.createElement("path", {
    style: {
      stroke: "#333",
      strokeWidth: 1.3333333333333333,
      strokeOpacity: 1,
      strokeDasharray: "0 0"
    },
    transform: "translate(12.167 12.172)",
    d: "M.82.82 0 0"
  }), /*#__PURE__*/react_.createElement("path", {
    style: {
      stroke: "#333",
      strokeWidth: 1.3333333333333333,
      strokeOpacity: 1,
      strokeDasharray: "0 0"
    },
    transform: "translate(3.007 3.065)",
    d: "M.68.69 0 0"
  }), /*#__PURE__*/react_.createElement("path", {
    style: {
      stroke: "#333",
      strokeWidth: 1.3333333333333333,
      strokeOpacity: 1,
      strokeDasharray: "0 0"
    },
    transform: "translate(8 1.216)",
    d: "M0 1V0"
  }), /*#__PURE__*/react_.createElement("path", {
    style: {
      stroke: "#333",
      strokeWidth: 1.3333333333333333,
      strokeOpacity: 1,
      strokeDasharray: "0 0"
    },
    transform: "translate(13.333 8.216)",
    d: "M1.33 0H0"
  }), /*#__PURE__*/react_.createElement("path", {
    style: {
      stroke: "#333",
      strokeWidth: 1.3333333333333333,
      strokeOpacity: 1,
      strokeDasharray: "0 0"
    },
    transform: "translate(12.51 3.065)",
    d: "M0 .82.82 0"
  }), /*#__PURE__*/react_.createElement("path", {
    fillRule: "evenodd",
    style: {
      fill: "#333"
    },
    transform: "translate(5.673 5.549)",
    d: "M2.33 0C1.04 0 0 1.04 0 2.33s1.04 2.34 2.33 2.34V0Z"
  }), /*#__PURE__*/react_.createElement("path", {
    style: {
      stroke: "#333",
      strokeWidth: 1.3333333333333333,
      strokeOpacity: 1,
      strokeDasharray: "0 0"
    },
    transform: "translate(1.333 7.882)",
    d: "M0 0h1.33"
  }), /*#__PURE__*/react_.createElement("path", {
    style: {
      stroke: "#333",
      strokeWidth: 1.3333333333333333,
      strokeOpacity: 1,
      strokeDasharray: "0 0"
    },
    transform: "translate(3.348 12.313)",
    d: "M0 .68.68 0"
  }), /*#__PURE__*/react_.createElement("path", {
    style: {
      stroke: "#333",
      strokeWidth: 1.3333333333333333,
      strokeOpacity: 1,
      strokeDasharray: "0 0"
    },
    transform: "translate(8 13.549)",
    d: "M0 1.33V0"
  }))));
};
/* harmony default export */ const light = (SvgLight);
;// CONCATENATED MODULE: ./app/icons/dark.svg
var dark_defs, dark_mask;
function dark_extends() { dark_extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return dark_extends.apply(this, arguments); }

var SvgDark = function SvgDark(props) {
  return /*#__PURE__*/react_.createElement("svg", dark_extends({
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
    width: 16,
    height: 16,
    fill: "none"
  }, props), dark_defs || (dark_defs = /*#__PURE__*/react_.createElement("defs", null, /*#__PURE__*/react_.createElement("path", {
    id: "dark_svg__a",
    d: "M0 0h16v16H0z"
  }))), /*#__PURE__*/react_.createElement("g", null, dark_mask || (dark_mask = /*#__PURE__*/react_.createElement("mask", {
    id: "dark_svg__b",
    fill: "#fff"
  }, /*#__PURE__*/react_.createElement("use", {
    xlinkHref: "#dark_svg__a"
  }))), /*#__PURE__*/react_.createElement("g", {
    mask: "url(#dark_svg__b)"
  }, /*#__PURE__*/react_.createElement("path", {
    style: {
      stroke: "#333",
      strokeWidth: 1.3333333333333333,
      strokeOpacity: 1,
      strokeDasharray: "0 0"
    },
    transform: "translate(1.333 1.333)",
    d: "M6.67 0 4.91 1.76H1.76v3.15L0 6.67l1.76 1.75v3.16h3.15l1.76 1.75 1.75-1.75h3.16V8.42l1.75-1.75-1.75-1.76V1.76H8.42L6.67 0Z"
  }), /*#__PURE__*/react_.createElement("path", {
    style: {
      stroke: "#333",
      strokeWidth: 1.3333333333333333,
      strokeOpacity: 1,
      strokeDasharray: "0 0"
    },
    transform: "translate(5.667 5.448)",
    d: "M4 .55c-1.83-1.33-4 0-4 1.34 1.67 0 3.33.33 3.33 3 1.34 0 2.5-3 .67-4.34Z"
  }))));
};
/* harmony default export */ const dark = (SvgDark);
;// CONCATENATED MODULE: ./app/icons/auto.svg
var auto_defs, auto_mask;
function auto_extends() { auto_extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return auto_extends.apply(this, arguments); }

var SvgAuto = function SvgAuto(props) {
  return /*#__PURE__*/react_.createElement("svg", auto_extends({
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
    width: 16,
    height: 16,
    fill: "none"
  }, props), auto_defs || (auto_defs = /*#__PURE__*/react_.createElement("defs", null, /*#__PURE__*/react_.createElement("path", {
    id: "auto_svg__a",
    d: "M0 0h16v16H0z"
  }))), /*#__PURE__*/react_.createElement("g", null, auto_mask || (auto_mask = /*#__PURE__*/react_.createElement("mask", {
    id: "auto_svg__b",
    fill: "#fff"
  }, /*#__PURE__*/react_.createElement("use", {
    xlinkHref: "#auto_svg__a"
  }))), /*#__PURE__*/react_.createElement("g", {
    mask: "url(#auto_svg__b)"
  }, /*#__PURE__*/react_.createElement("path", {
    style: {
      stroke: "#333",
      strokeWidth: 1,
      strokeOpacity: 1,
      strokeDasharray: "0 0"
    },
    transform: "translate(5.667 5.333)",
    d: "m0 5.337.73-1.67m3.938 1.67-.73-1.67M.728 3.67 2.33 0l1.61 3.67M.73 3.667h3.21"
  }), /*#__PURE__*/react_.createElement("path", {
    style: {
      stroke: "#333",
      strokeWidth: 1.3333333333333333,
      strokeOpacity: 1,
      strokeDasharray: "0 0"
    },
    transform: "translate(1.333 1.333)",
    d: "M13.07 5.33A6.672 6.672 0 0 0 0 5.33l2-.66"
  }), /*#__PURE__*/react_.createElement("path", {
    style: {
      stroke: "#333",
      strokeWidth: 1.3333333333333333,
      strokeOpacity: 1,
      strokeDasharray: "0 0"
    },
    transform: "translate(1.333 9.333)",
    d: "M0 0a6.672 6.672 0 0 0 13.07 0l-1.74.67"
  }))));
};
/* harmony default export */ const auto = (SvgAuto);
;// CONCATENATED MODULE: ./app/icons/bottom.svg
var bottom_defs, bottom_mask;
function bottom_extends() { bottom_extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return bottom_extends.apply(this, arguments); }

var SvgBottom = function SvgBottom(props) {
  return /*#__PURE__*/react_.createElement("svg", bottom_extends({
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
    width: 16,
    height: 16,
    fill: "none"
  }, props), bottom_defs || (bottom_defs = /*#__PURE__*/react_.createElement("defs", null, /*#__PURE__*/react_.createElement("path", {
    id: "bottom_svg__a",
    d: "M0 0h16v16H0z"
  }))), /*#__PURE__*/react_.createElement("g", null, bottom_mask || (bottom_mask = /*#__PURE__*/react_.createElement("mask", {
    id: "bottom_svg__b",
    fill: "#fff"
  }, /*#__PURE__*/react_.createElement("use", {
    xlinkHref: "#bottom_svg__a"
  }))), /*#__PURE__*/react_.createElement("g", {
    mask: "url(#bottom_svg__b)"
  }, /*#__PURE__*/react_.createElement("path", {
    style: {
      stroke: "#333",
      strokeWidth: 1.3333333333333333,
      strokeOpacity: 1,
      strokeDasharray: "0 0"
    },
    transform: "translate(4 4)",
    d: "M8 0 4 4 0 0"
  }), /*#__PURE__*/react_.createElement("path", {
    style: {
      stroke: "#333",
      strokeWidth: 1.3333333333333333,
      strokeOpacity: 1,
      strokeDasharray: "0 0"
    },
    transform: "translate(4 8)",
    d: "M8 0 4 4 0 0"
  }))));
};
/* harmony default export */ const bottom = (SvgBottom);
;// CONCATENATED MODULE: ./app/icons/pause.svg
var pause_defs, pause_mask;
function pause_extends() { pause_extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return pause_extends.apply(this, arguments); }

var SvgPause = function SvgPause(props) {
  return /*#__PURE__*/react_.createElement("svg", pause_extends({
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
    width: 16,
    height: 16,
    fill: "none"
  }, props), pause_defs || (pause_defs = /*#__PURE__*/react_.createElement("defs", null, /*#__PURE__*/react_.createElement("path", {
    id: "pause_svg__a",
    d: "M0 0h16v16H0z"
  }))), /*#__PURE__*/react_.createElement("g", null, pause_mask || (pause_mask = /*#__PURE__*/react_.createElement("mask", {
    id: "pause_svg__b",
    fill: "#fff"
  }, /*#__PURE__*/react_.createElement("use", {
    xlinkHref: "#pause_svg__a"
  }))), /*#__PURE__*/react_.createElement("g", {
    mask: "url(#pause_svg__b)"
  }, /*#__PURE__*/react_.createElement("path", {
    style: {
      stroke: "#333",
      strokeWidth: 1.3333333333333333,
      strokeOpacity: 1,
      strokeDasharray: "0 0"
    },
    transform: "translate(1.333 1.333)",
    d: "M13.33 6.67A6.66 6.66 0 0 0 6.67 0C2.98 0 0 2.98 0 6.67a6.66 6.66 0 0 0 6.67 6.66c3.68 0 6.66-2.98 6.66-6.66Z"
  }), /*#__PURE__*/react_.createElement("path", {
    style: {
      stroke: "#333",
      strokeWidth: 1.3333333333333333,
      strokeOpacity: 1,
      strokeDasharray: "0 0"
    },
    transform: "translate(6.333 6)",
    d: "M0 0v4"
  }), /*#__PURE__*/react_.createElement("path", {
    style: {
      stroke: "#333",
      strokeWidth: 1.3333333333333333,
      strokeOpacity: 1,
      strokeDasharray: "0 0"
    },
    transform: "translate(9.667 6)",
    d: "M0 0v4"
  }))));
};
/* harmony default export */ const pause = (SvgPause);
// EXTERNAL MODULE: ./app/store/index.ts + 3 modules
var store = __webpack_require__(1209);
// EXTERNAL MODULE: ./app/utils.ts
var utils = __webpack_require__(6433);
// EXTERNAL MODULE: ./node_modules/next/dist/shared/lib/app-dynamic.js
var app_dynamic = __webpack_require__(9535);
var app_dynamic_default = /*#__PURE__*/__webpack_require__.n(app_dynamic);
// EXTERNAL MODULE: ./app/requests.ts
var requests = __webpack_require__(6561);
// EXTERNAL MODULE: ./app/store/prompt.ts
var store_prompt = __webpack_require__(9498);
// EXTERNAL MODULE: ./app/locales/index.ts + 8 modules
var locales = __webpack_require__(1452);
// EXTERNAL MODULE: ./app/components/button.tsx
var components_button = __webpack_require__(554);
// EXTERNAL MODULE: ./app/components/home.module.scss
var home_module = __webpack_require__(7986);
var home_module_default = /*#__PURE__*/__webpack_require__.n(home_module);
// EXTERNAL MODULE: ./app/components/chat.module.scss
var chat_module = __webpack_require__(3493);
var chat_module_default = /*#__PURE__*/__webpack_require__.n(chat_module);
// EXTERNAL MODULE: ./app/components/ui-lib.tsx + 1 modules
var ui_lib = __webpack_require__(2634);
// EXTERNAL MODULE: ./node_modules/react-router-dom/dist/umd/react-router-dom.production.min.js
var react_router_dom_production_min = __webpack_require__(9742);
// EXTERNAL MODULE: ./app/constant.ts
var constant = __webpack_require__(2080);
;// CONCATENATED MODULE: ./app/components/chat.tsx


































const Markdown = app_dynamic_default()(async ()=>/*#__PURE__*/ (0,react_.memo)((await Promise.all(/* import() */[__webpack_require__.e(717), __webpack_require__.e(8), __webpack_require__.e(182)]).then(__webpack_require__.bind(__webpack_require__, 8182))).Markdown), {
    loadableGenerated: {
        modules: [
            "E:\\code\\ChatGPT-Next-Web-main\\app\\components\\chat.tsx -> " + "./markdown"
        ]
    },
    loading: ()=>/*#__PURE__*/ jsx_runtime_.jsx(three_dots/* default */.Z, {})
});
const Emoji = app_dynamic_default()(async ()=>(await __webpack_require__.e(/* import() */ 480).then(__webpack_require__.bind(__webpack_require__, 480))).Emoji, {
    loadableGenerated: {
        modules: [
            "E:\\code\\ChatGPT-Next-Web-main\\app\\components\\chat.tsx -> " + "emoji-picker-react"
        ]
    },
    loading: ()=>/*#__PURE__*/ jsx_runtime_.jsx(three_dots/* default */.Z, {})
});
function Avatar(props) {
    const config = (0,store/* useAppConfig */.MG)();
    if (props.role !== "user") {
        return /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "no-dark",
            children: props.model?.startsWith("gpt-4") ? /*#__PURE__*/ jsx_runtime_.jsx(black_bot, {
                className: (home_module_default())["user-avtar"]
            }) : /*#__PURE__*/ jsx_runtime_.jsx(bot/* default */.Z, {
                className: (home_module_default())["user-avtar"]
            })
        });
    }
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: (home_module_default())["user-avtar"],
        children: /*#__PURE__*/ jsx_runtime_.jsx(Emoji, {
            unified: config.avatar,
            size: 18,
            getEmojiUrl: utils/* getEmojiUrl */.qc
        })
    });
}
function exportMessages(messages, topic) {
    const mdText = `# ${topic}\n\n` + messages.map((m)=>{
        return m.role === "user" ? `## ${locales/* default.Export.MessageFromYou */.ZP.Export.MessageFromYou}:\n${m.content}` : `## ${locales/* default.Export.MessageFromChatGPT */.ZP.Export.MessageFromChatGPT}:\n${m.content.trim()}`;
    }).join("\n\n");
    const filename = `${topic}.md`;
    (0,ui_lib/* showModal */.K4)({
        title: locales/* default.Export.Title */.ZP.Export.Title,
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "markdown-body",
            children: /*#__PURE__*/ jsx_runtime_.jsx("pre", {
                className: (home_module_default())["export-content"],
                children: mdText
            })
        }),
        actions: [
            /*#__PURE__*/ jsx_runtime_.jsx(components_button/* IconButton */.h, {
                icon: /*#__PURE__*/ jsx_runtime_.jsx(copy/* default */.Z, {}),
                bordered: true,
                text: locales/* default.Export.Copy */.ZP.Export.Copy,
                onClick: ()=>(0,utils/* copyToClipboard */.vQ)(mdText)
            }, "copy"),
            /*#__PURE__*/ jsx_runtime_.jsx(components_button/* IconButton */.h, {
                icon: /*#__PURE__*/ jsx_runtime_.jsx(download, {}),
                bordered: true,
                text: locales/* default.Export.Download */.ZP.Export.Download,
                onClick: ()=>(0,utils/* downloadAs */.CP)(mdText, filename)
            }, "download")
        ]
    });
}
function PromptToast(props) {
    const chatStore = (0,store/* useChatStore */.aK)();
    const session = chatStore.currentSession();
    const context = session.context;
    const addContextPrompt = (prompt1)=>{
        chatStore.updateCurrentSession((session)=>{
            session.context.push(prompt1);
        });
    };
    const removeContextPrompt = (i)=>{
        chatStore.updateCurrentSession((session)=>{
            session.context.splice(i, 1);
        });
    };
    const updateContextPrompt = (i, prompt1)=>{
        chatStore.updateCurrentSession((session)=>{
            session.context[i] = prompt1;
        });
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (chat_module_default())["prompt-toast"],
        children: [
            props.showToast && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (chat_module_default())["prompt-toast-inner"] + " clickable",
                role: "button",
                onClick: ()=>props.setShowModal(true),
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(brain, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: (chat_module_default())["prompt-toast-content"],
                        children: locales/* default.Context.Toast */.ZP.Context.Toast(context.length)
                    })
                ]
            }),
            props.showModal && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "modal-mask",
                children: /*#__PURE__*/ jsx_runtime_.jsx(ui_lib/* Modal */.u_, {
                    title: locales/* default.Context.Edit */.ZP.Context.Edit,
                    onClose: ()=>props.setShowModal(false),
                    actions: [
                        /*#__PURE__*/ jsx_runtime_.jsx(components_button/* IconButton */.h, {
                            icon: /*#__PURE__*/ jsx_runtime_.jsx(copy/* default */.Z, {}),
                            bordered: true,
                            text: locales/* default.Memory.Reset */.ZP.Memory.Reset,
                            onClick: ()=>confirm(locales/* default.Memory.ResetConfirm */.ZP.Memory.ResetConfirm) && chatStore.resetSession()
                        }, "reset"),
                        /*#__PURE__*/ jsx_runtime_.jsx(components_button/* IconButton */.h, {
                            icon: /*#__PURE__*/ jsx_runtime_.jsx(copy/* default */.Z, {}),
                            bordered: true,
                            text: locales/* default.Memory.Copy */.ZP.Memory.Copy,
                            onClick: ()=>(0,utils/* copyToClipboard */.vQ)(session.memoryPrompt)
                        }, "copy")
                    ],
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (chat_module_default())["context-prompt"],
                                children: [
                                    context.map((c, i)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: (chat_module_default())["context-prompt-row"],
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("select", {
                                                    value: c.role,
                                                    className: (chat_module_default())["context-role"],
                                                    onChange: (e)=>updateContextPrompt(i, {
                                                            ...c,
                                                            role: e.target.value
                                                        }),
                                                    children: store/* ROLES.map */.K$.map((r)=>/*#__PURE__*/ jsx_runtime_.jsx("option", {
                                                            value: r,
                                                            children: r
                                                        }, r))
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx(ui_lib/* Input */.II, {
                                                    value: c.content,
                                                    type: "text",
                                                    className: (chat_module_default())["context-content"],
                                                    rows: 1,
                                                    onInput: (e)=>updateContextPrompt(i, {
                                                            ...c,
                                                            content: e.currentTarget.value
                                                        })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx(components_button/* IconButton */.h, {
                                                    icon: /*#__PURE__*/ jsx_runtime_.jsx(icons_delete/* default */.Z, {}),
                                                    className: (chat_module_default())["context-delete-button"],
                                                    onClick: ()=>removeContextPrompt(i),
                                                    bordered: true
                                                })
                                            ]
                                        }, i)),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: (chat_module_default())["context-prompt-row"],
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(components_button/* IconButton */.h, {
                                            icon: /*#__PURE__*/ jsx_runtime_.jsx(add/* default */.Z, {}),
                                            text: locales/* default.Context.Add */.ZP.Context.Add,
                                            bordered: true,
                                            className: (chat_module_default())["context-prompt-button"],
                                            onClick: ()=>addContextPrompt({
                                                    role: "system",
                                                    content: "",
                                                    date: ""
                                                })
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (chat_module_default())["memory-prompt"],
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: (chat_module_default())["memory-prompt-title"],
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                children: [
                                                    locales/* default.Memory.Title */.ZP.Memory.Title,
                                                    " (",
                                                    session.lastSummarizeIndex,
                                                    " of",
                                                    " ",
                                                    session.messages.length,
                                                    ")"
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                                                className: (chat_module_default())["memory-prompt-action"],
                                                children: [
                                                    locales/* default.Memory.Send */.ZP.Memory.Send,
                                                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                        type: "checkbox",
                                                        checked: session.sendMemory,
                                                        onChange: ()=>chatStore.updateCurrentSession((session)=>session.sendMemory = !session.sendMemory)
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: (chat_module_default())["memory-prompt-content"],
                                        children: session.memoryPrompt || locales/* default.Memory.EmptyContent */.ZP.Memory.EmptyContent
                                    })
                                ]
                            })
                        ]
                    })
                })
            })
        ]
    }, "prompt-toast");
}
function useSubmitHandler() {
    const config = (0,store/* useAppConfig */.MG)();
    const submitKey = config.submitKey;
    const shouldSubmit = (e)=>{
        if (e.key !== "Enter") return false;
        if (e.key === "Enter" && e.nativeEvent.isComposing) return false;
        return config.submitKey === store/* SubmitKey.AltEnter */.mQ.AltEnter && e.altKey || config.submitKey === store/* SubmitKey.CtrlEnter */.mQ.CtrlEnter && e.ctrlKey || config.submitKey === store/* SubmitKey.ShiftEnter */.mQ.ShiftEnter && e.shiftKey || config.submitKey === store/* SubmitKey.MetaEnter */.mQ.MetaEnter && e.metaKey || config.submitKey === store/* SubmitKey.Enter */.mQ.Enter && !e.altKey && !e.ctrlKey && !e.shiftKey && !e.metaKey;
    };
    return {
        submitKey,
        shouldSubmit
    };
}
function PromptHints(props) {
    if (props.prompts.length === 0) return null;
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: (home_module_default())["prompt-hints"],
        children: props.prompts.map((prompt1, i)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (home_module_default())["prompt-hint"],
                onClick: ()=>props.onPromptSelect(prompt1),
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (home_module_default())["hint-title"],
                        children: prompt1.title
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (home_module_default())["hint-content"],
                        children: prompt1.content
                    })
                ]
            }, prompt1.title + i.toString()))
    });
}
function useScrollToBottom() {
    // for auto-scroll
    const scrollRef = (0,react_.useRef)(null);
    const [autoScroll, setAutoScroll] = (0,react_.useState)(true);
    const scrollToBottom = ()=>{
        const dom = scrollRef.current;
        if (dom) {
            setTimeout(()=>dom.scrollTop = dom.scrollHeight, 1);
        }
    };
    // auto scroll
    (0,react_.useLayoutEffect)(()=>{
        autoScroll && scrollToBottom();
    });
    return {
        scrollRef,
        autoScroll,
        setAutoScroll,
        scrollToBottom
    };
}
function ChatActions(props) {
    const config = (0,store/* useAppConfig */.MG)();
    // switch themes
    const theme = config.theme;
    function nextTheme() {
        const themes = [
            store/* Theme.Auto */.Q2.Auto,
            store/* Theme.Light */.Q2.Light,
            store/* Theme.Dark */.Q2.Dark
        ];
        const themeIndex = themes.indexOf(theme);
        const nextIndex = (themeIndex + 1) % themes.length;
        const nextTheme = themes[nextIndex];
        config.update((config)=>config.theme = nextTheme);
    }
    // stop all responses
    const couldStop = requests/* ControllerPool.hasPending */.u4.hasPending();
    const stopAll = ()=>requests/* ControllerPool.stopAll */.u4.stopAll();
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (chat_module_default())["chat-input-actions"],
        children: [
            couldStop && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: `${(chat_module_default())["chat-input-action"]} clickable`,
                onClick: stopAll,
                children: /*#__PURE__*/ jsx_runtime_.jsx(pause, {})
            }),
            !props.hitBottom && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: `${(chat_module_default())["chat-input-action"]} clickable`,
                onClick: props.scrollToBottom,
                children: /*#__PURE__*/ jsx_runtime_.jsx(bottom, {})
            }),
            props.hitBottom && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: `${(chat_module_default())["chat-input-action"]} clickable`,
                onClick: props.showPromptModal,
                children: /*#__PURE__*/ jsx_runtime_.jsx(brain, {})
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: `${(chat_module_default())["chat-input-action"]} clickable`,
                onClick: nextTheme,
                children: theme === store/* Theme.Auto */.Q2.Auto ? /*#__PURE__*/ jsx_runtime_.jsx(auto, {}) : theme === store/* Theme.Light */.Q2.Light ? /*#__PURE__*/ jsx_runtime_.jsx(light, {}) : theme === store/* Theme.Dark */.Q2.Dark ? /*#__PURE__*/ jsx_runtime_.jsx(dark, {}) : null
            })
        ]
    });
}
function Chat() {
    const chatStore = (0,store/* useChatStore */.aK)();
    const [session, sessionIndex] = (0,store/* useChatStore */.aK)((state)=>[
            state.currentSession(),
            state.currentSessionIndex
        ]);
    const config = (0,store/* useAppConfig */.MG)();
    const fontSize = config.fontSize;
    const inputRef = (0,react_.useRef)(null);
    const [userInput, setUserInput] = (0,react_.useState)("");
    const [beforeInput, setBeforeInput] = (0,react_.useState)("");
    const [isLoading, setIsLoading] = (0,react_.useState)(false);
    const { submitKey , shouldSubmit  } = useSubmitHandler();
    const { scrollRef , setAutoScroll , scrollToBottom  } = useScrollToBottom();
    const [hitBottom, setHitBottom] = (0,react_.useState)(false);
    const isMobileScreen = (0,utils/* useMobileScreen */.S0)();
    const navigate = (0,react_router_dom_production_min.useNavigate)();
    const onChatBodyScroll = (e)=>{
        const isTouchBottom = e.scrollTop + e.clientHeight >= e.scrollHeight - 20;
        setHitBottom(isTouchBottom);
    };
    // prompt hints
    const promptStore = (0,store_prompt/* usePromptStore */.f5)();
    const [promptHints, setPromptHints] = (0,react_.useState)([]);
    const onSearch = (0,index_module/* useDebouncedCallback */.y1)((text)=>{
        setPromptHints(promptStore.search(text));
    }, 100, {
        leading: true,
        trailing: true
    });
    const onPromptSelect = (prompt1)=>{
        setUserInput(prompt1.content);
        setPromptHints([]);
        inputRef.current?.focus();
    };
    // auto grow input
    const [inputRows, setInputRows] = (0,react_.useState)(2);
    const measure = (0,index_module/* useDebouncedCallback */.y1)(()=>{
        const rows = inputRef.current ? (0,utils/* autoGrowTextArea */.lx)(inputRef.current) : 1;
        const inputRows = Math.min(5, Math.max(2 + Number(!isMobileScreen), rows));
        setInputRows(inputRows);
    }, 100, {
        leading: true,
        trailing: true
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
    (0,react_.useEffect)(measure, [
        userInput
    ]);
    // only search prompts when user input is short
    const SEARCH_TEXT_LIMIT = 30;
    const onInput = (text)=>{
        console.log("iiiiii");
        setUserInput(text);
        const n = text.trim().length;
        // clear search results
        if (n === 0) {
            setPromptHints([]);
        } else if (!config.disablePromptHint && n < SEARCH_TEXT_LIMIT) {
            // check if need to trigger auto completion
            if (text.startsWith("/")) {
                let searchText = text.slice(1);
                onSearch(searchText);
            }
        }
    };
    // submit user input
    const onUserSubmit = ()=>{
        if (userInput.length <= 0) return;
        setIsLoading(true);
        chatStore.onUserInput(userInput).then(()=>setIsLoading(false));
        setBeforeInput(userInput);
        setUserInput("");
        setPromptHints([]);
        if (!isMobileScreen) inputRef.current?.focus();
        setAutoScroll(true);
    };
    // stop response
    const onUserStop = (messageId)=>{
        requests/* ControllerPool.stop */.u4.stop(sessionIndex, messageId);
    };
    // check if should send message
    const onInputKeyDown = (e)=>{
        // if ArrowUp and no userInput
        if (e.key === "ArrowUp" && userInput.length <= 0) {
            setUserInput(beforeInput);
            e.preventDefault();
            return;
        }
        if (shouldSubmit(e)) {
            onUserSubmit();
            e.preventDefault();
        }
    };
    const onRightClick = (e, message)=>{
        // auto fill user input
        if (message.role === "user") {
            setUserInput(message.content);
        }
        // copy to clipboard
        if ((0,utils/* selectOrCopy */.Ri)(e.currentTarget, message.content)) {
            e.preventDefault();
        }
    };
    const findLastUserIndex = (messageId)=>{
        // find last user input message and resend
        let lastUserMessageIndex = null;
        for(let i = 0; i < session.messages.length; i += 1){
            const message = session.messages[i];
            if (message.id === messageId) {
                break;
            }
            if (message.role === "user") {
                lastUserMessageIndex = i;
            }
        }
        return lastUserMessageIndex;
    };
    const deleteMessage = (userIndex)=>{
        chatStore.updateCurrentSession((session)=>session.messages.splice(userIndex, 2));
    };
    const onDelete = (botMessageId)=>{
        const userIndex = findLastUserIndex(botMessageId);
        if (userIndex === null) return;
        deleteMessage(userIndex);
    };
    const onResend = (botMessageId)=>{
        // find last user input message and resend
        const userIndex = findLastUserIndex(botMessageId);
        if (userIndex === null) return;
        setIsLoading(true);
        const content = session.messages[userIndex].content;
        deleteMessage(userIndex);
        chatStore.onUserInput(content).then(()=>setIsLoading(false));
        inputRef.current?.focus();
    };
    const context = session.context.slice();
    const accessStore = (0,store/* useAccessStore */._X)();
    if (context.length === 0 && session.messages.at(0)?.content !== store/* BOT_HELLO.content */.ux.content) {
        const copiedHello = Object.assign({}, store/* BOT_HELLO */.ux);
        if (!accessStore.isAuthorized()) {
            copiedHello.content = locales/* default.Error.Unauthorized */.ZP.Error.Unauthorized;
        }
        context.push(copiedHello);
    }
    // preview messages
    const messages = context.concat(session.messages).concat(isLoading ? [
        {
            ...(0,store/* createMessage */.tn)({
                role: "assistant",
                content: "……"
            }),
            preview: true
        }
    ] : []).concat(userInput.length > 0 && config.sendPreviewBubble ? [
        {
            ...(0,store/* createMessage */.tn)({
                role: "user",
                content: userInput
            }),
            preview: true
        }
    ] : []);
    const [showPromptModal, setShowPromptModal] = (0,react_.useState)(false);
    const renameSession = ()=>{
        const newTopic = prompt(locales/* default.Chat.Rename */.ZP.Chat.Rename, session.topic);
        if (newTopic && newTopic !== session.topic) {
            chatStore.updateCurrentSession((session)=>session.topic = newTopic);
        }
    };
    // Auto focus
    (0,react_.useEffect)(()=>{
        if (isMobileScreen) return;
        inputRef.current?.focus();
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (home_module_default()).chat,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (home_module_default())["window-header"],
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (home_module_default())["window-header-title"],
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: `${(home_module_default())["window-header-main-title"]} ${(home_module_default())["chat-body-title"]}`,
                                onClickCapture: renameSession,
                                children: session.topic
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (home_module_default())["window-header-sub-title"],
                                children: locales/* default.Chat.SubTitle */.ZP.Chat.SubTitle(session.messages.length)
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (home_module_default())["window-actions"],
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (home_module_default())["window-action-button"] + " " + (home_module_default()).mobile,
                                children: /*#__PURE__*/ jsx_runtime_.jsx(components_button/* IconButton */.h, {
                                    icon: /*#__PURE__*/ jsx_runtime_.jsx(icons_return, {}),
                                    bordered: true,
                                    title: locales/* default.Chat.Actions.ChatList */.ZP.Chat.Actions.ChatList,
                                    onClick: ()=>navigate(constant/* Path.Home */.y$.Home)
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (home_module_default())["window-action-button"],
                                children: /*#__PURE__*/ jsx_runtime_.jsx(components_button/* IconButton */.h, {
                                    icon: /*#__PURE__*/ jsx_runtime_.jsx(rename, {}),
                                    bordered: true,
                                    onClick: renameSession
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (home_module_default())["window-action-button"],
                                children: /*#__PURE__*/ jsx_runtime_.jsx(components_button/* IconButton */.h, {
                                    icon: /*#__PURE__*/ jsx_runtime_.jsx(share, {}),
                                    bordered: true,
                                    title: locales/* default.Chat.Actions.Export */.ZP.Chat.Actions.Export,
                                    onClick: ()=>{
                                        exportMessages(session.messages.filter((msg)=>!msg.isError), session.topic);
                                    }
                                })
                            }),
                            !isMobileScreen && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (home_module_default())["window-action-button"],
                                children: /*#__PURE__*/ jsx_runtime_.jsx(components_button/* IconButton */.h, {
                                    icon: config.tightBorder ? /*#__PURE__*/ jsx_runtime_.jsx(min, {}) : /*#__PURE__*/ jsx_runtime_.jsx(max, {}),
                                    bordered: true,
                                    onClick: ()=>{
                                        config.update((config)=>config.tightBorder = !config.tightBorder);
                                    }
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(PromptToast, {
                        showToast: !hitBottom,
                        showModal: showPromptModal,
                        setShowModal: setShowPromptModal
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (home_module_default())["chat-body"],
                ref: scrollRef,
                onScroll: (e)=>onChatBodyScroll(e.currentTarget),
                onMouseDown: ()=>inputRef.current?.blur(),
                onWheel: (e)=>setAutoScroll(hitBottom && e.deltaY > 0),
                onTouchStart: ()=>{
                    inputRef.current?.blur();
                    setAutoScroll(false);
                },
                children: messages.map((message, i)=>{
                    const isUser = message.role === "user";
                    const showActions = !isUser && i > 0 && !(message.preview || message.content.length === 0);
                    const showTyping = message.preview || message.streaming;
                    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: isUser ? (home_module_default())["chat-message-user"] : (home_module_default())["chat-message"],
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (home_module_default())["chat-message-container"],
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: (home_module_default())["chat-message-avatar"],
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(Avatar, {
                                        role: message.role,
                                        model: message.model
                                    })
                                }),
                                showTyping && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: (home_module_default())["chat-message-status"],
                                    children: locales/* default.Chat.Typing */.ZP.Chat.Typing
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: (home_module_default())["chat-message-item"],
                                    children: [
                                        showActions && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: (home_module_default())["chat-message-top-actions"],
                                            children: [
                                                message.streaming ? /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: (home_module_default())["chat-message-top-action"],
                                                    onClick: ()=>onUserStop(message.id ?? i),
                                                    children: locales/* default.Chat.Actions.Stop */.ZP.Chat.Actions.Stop
                                                }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                            className: (home_module_default())["chat-message-top-action"],
                                                            onClick: ()=>onDelete(message.id ?? i),
                                                            children: locales/* default.Chat.Actions.Delete */.ZP.Chat.Actions.Delete
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                            className: (home_module_default())["chat-message-top-action"],
                                                            onClick: ()=>onResend(message.id ?? i),
                                                            children: locales/* default.Chat.Actions.Retry */.ZP.Chat.Actions.Retry
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: (home_module_default())["chat-message-top-action"],
                                                    onClick: ()=>(0,utils/* copyToClipboard */.vQ)(message.content),
                                                    children: locales/* default.Chat.Actions.Copy */.ZP.Chat.Actions.Copy
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(Markdown, {
                                            content: message.content,
                                            loading: (message.preview || message.content.length === 0) && !isUser,
                                            onContextMenu: (e)=>onRightClick(e, message),
                                            onDoubleClickCapture: ()=>{
                                                if (!isMobileScreen) return;
                                                setUserInput(message.content);
                                            },
                                            fontSize: fontSize,
                                            parentRef: scrollRef
                                        })
                                    ]
                                }),
                                !isUser && !message.preview && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: (home_module_default())["chat-message-actions"],
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: (home_module_default())["chat-message-action-date"],
                                        children: message.date.toLocaleString()
                                    })
                                })
                            ]
                        })
                    }, i);
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (home_module_default())["chat-input-panel"],
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(PromptHints, {
                        prompts: promptHints,
                        onPromptSelect: onPromptSelect
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(ChatActions, {
                        showPromptModal: ()=>setShowPromptModal(true),
                        scrollToBottom: scrollToBottom,
                        hitBottom: hitBottom
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (home_module_default())["chat-input-panel-inner"],
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("textarea", {
                                ref: inputRef,
                                className: (home_module_default())["chat-input"],
                                placeholder: locales/* default.Chat.Input */.ZP.Chat.Input(submitKey),
                                onInput: (e)=>onInput(e.currentTarget.value),
                                value: userInput,
                                onKeyDown: onInputKeyDown,
                                onFocus: ()=>setAutoScroll(true),
                                onBlur: ()=>{
                                    setAutoScroll(false);
                                    setTimeout(()=>setPromptHints([]), 500);
                                },
                                autoFocus: true,
                                rows: inputRows
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(components_button/* IconButton */.h, {
                                icon: /*#__PURE__*/ jsx_runtime_.jsx(send_white, {}),
                                text: locales/* default.Chat.Send */.ZP.Chat.Send,
                                className: (home_module_default())["chat-input-send"],
                                noDark: true,
                                onClick: onUserSubmit
                            })
                        ]
                    })
                ]
            })
        ]
    }, session.id);
}


/***/ }),

/***/ 5208:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "S": () => (/* binding */ ErrorBoundary)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(8038);
var react_default = /*#__PURE__*/__webpack_require__.n(react_);
// EXTERNAL MODULE: ./app/components/button.tsx
var components_button = __webpack_require__(554);
;// CONCATENATED MODULE: ./app/icons/github.svg
var _defs, _mask;
function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

var SvgGithub = function SvgGithub(props) {
  return /*#__PURE__*/react_.createElement("svg", _extends({
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
    width: 16,
    height: 16,
    fill: "none"
  }, props), _defs || (_defs = /*#__PURE__*/react_.createElement("defs", null, /*#__PURE__*/react_.createElement("path", {
    id: "github_svg__a",
    d: "M0 0h16v16H0z"
  }))), /*#__PURE__*/react_.createElement("g", null, _mask || (_mask = /*#__PURE__*/react_.createElement("mask", {
    id: "github_svg__b",
    fill: "#fff"
  }, /*#__PURE__*/react_.createElement("use", {
    xlinkHref: "#github_svg__a"
  }))), /*#__PURE__*/react_.createElement("g", {
    mask: "url(#github_svg__b)"
  }, /*#__PURE__*/react_.createElement("path", {
    style: {
      stroke: "#333",
      strokeWidth: 1.3333333333333333,
      strokeOpacity: 1,
      strokeDasharray: "0 0"
    },
    transform: "translate(2.667 1.645)",
    d: "M7.11 8.51c.81-.16 1.53-.45 2.1-.87.96-.73 1.46-1.85 1.46-2.95 0-.78-.3-1.5-.81-2.11-.28-.34.55-2.89-.19-2.55-.73.34-1.81 1.1-2.38.94C6.68.79 6.02.69 5.33.69c-.6 0-1.17.07-1.71.21-.79.2-1.53-.54-2.29-.87C.58-.29.99 2.34.77 2.62.28 3.22 0 3.93 0 4.69c0 1.1.6 2.22 1.56 2.95.65.48 1.45.78 2.35.94"
  }), /*#__PURE__*/react_.createElement("path", {
    style: {
      stroke: "#333",
      strokeWidth: 1.3333333333333333,
      strokeOpacity: 1,
      strokeDasharray: "0 0"
    },
    transform: "translate(6 10.22)",
    d: "M.58 0C.19.43 0 .83 0 1.21v2.91"
  }), /*#__PURE__*/react_.createElement("path", {
    style: {
      stroke: "#333",
      strokeWidth: 1.3333333333333333,
      strokeOpacity: 1,
      strokeDasharray: "0 0"
    },
    transform: "translate(9.782 10.159)",
    d: "M0 0c.37.48.55.91.55 1.29v2.89"
  }), /*#__PURE__*/react_.createElement("path", {
    style: {
      stroke: "#333",
      strokeWidth: 1.3333333333333333,
      strokeOpacity: 1,
      strokeDasharray: "0 0"
    },
    transform: "translate(2 10.405)",
    d: "M0 0c.3.04.52.17.67.41C.88.77 1.69 2.1 2.61 2.1H4"
  }))));
};
/* harmony default export */ const github = (SvgGithub);
// EXTERNAL MODULE: ./app/constant.ts
var constant = __webpack_require__(2080);
;// CONCATENATED MODULE: ./app/components/error.tsx





class ErrorBoundary extends (react_default()).Component {
    constructor(props){
        super(props);
        this.state = {
            hasError: false,
            error: null,
            info: null
        };
    }
    componentDidCatch(error, info) {
        // Update state with error details
        this.setState({
            hasError: true,
            error,
            info
        });
    }
    render() {
        if (this.state.hasError) {
            // Render error message
            return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "error",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                        children: "Oops, something went wrong!"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("pre", {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("code", {
                                children: this.state.error?.toString()
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("code", {
                                children: this.state.info?.componentStack
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        href: constant/* ISSUE_URL */.TH,
                        className: "report",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(components_button/* IconButton */.h, {
                            text: "Report This Error",
                            icon: /*#__PURE__*/ jsx_runtime_.jsx(github, {}),
                            bordered: true
                        })
                    })
                ]
            });
        }
        // if no error occurred, render children
        return this.props.children;
    }
}


/***/ }),

/***/ 1780:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Home": () => (/* binding */ Home),
  "Loading": () => (/* binding */ Loading),
  "useSwitchTheme": () => (/* binding */ useSwitchTheme)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(8038);
// EXTERNAL MODULE: ./app/components/home.module.scss
var home_module = __webpack_require__(7986);
var home_module_default = /*#__PURE__*/__webpack_require__.n(home_module);
// EXTERNAL MODULE: ./app/icons/bot.svg
var bot = __webpack_require__(3106);
// EXTERNAL MODULE: ./app/icons/three-dots.svg
var three_dots = __webpack_require__(3076);
// EXTERNAL MODULE: ./app/utils.ts
var utils = __webpack_require__(6433);
// EXTERNAL MODULE: ./app/components/chat.tsx + 14 modules
var chat = __webpack_require__(1741);
// EXTERNAL MODULE: ./node_modules/next/dist/shared/lib/app-dynamic.js
var app_dynamic = __webpack_require__(9535);
var app_dynamic_default = /*#__PURE__*/__webpack_require__.n(app_dynamic);
// EXTERNAL MODULE: ./app/constant.ts
var constant = __webpack_require__(2080);
// EXTERNAL MODULE: ./app/components/error.tsx + 1 modules
var error = __webpack_require__(5208);
// EXTERNAL MODULE: ./node_modules/react-router-dom/dist/umd/react-router-dom.production.min.js
var react_router_dom_production_min = __webpack_require__(9742);
// EXTERNAL MODULE: ./app/components/button.tsx
var components_button = __webpack_require__(554);
;// CONCATENATED MODULE: ./app/icons/chatgpt.svg
var _defs, _mask;
function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

var SvgChatgpt = function SvgChatgpt(props) {
  return /*#__PURE__*/react_.createElement("svg", _extends({
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
    width: 43,
    height: 44,
    fill: "none"
  }, props), _defs || (_defs = /*#__PURE__*/react_.createElement("defs", null, /*#__PURE__*/react_.createElement("path", {
    id: "chatgpt_svg__a",
    d: "M0 0h43v43.58H0z"
  }))), /*#__PURE__*/react_.createElement("g", null, _mask || (_mask = /*#__PURE__*/react_.createElement("mask", {
    id: "chatgpt_svg__b",
    fill: "#fff"
  }, /*#__PURE__*/react_.createElement("use", {
    xlinkHref: "#chatgpt_svg__a"
  }))), /*#__PURE__*/react_.createElement("g", {
    mask: "url(#chatgpt_svg__b)"
  }, /*#__PURE__*/react_.createElement("path", {
    fillRule: "evenodd",
    style: {
      fill: "#8bcae0"
    },
    opacity: 0.27,
    d: "M40.17 17.84c.36-1.11.55-2.27.55-3.43 0-1.93-.51-3.83-1.49-5.49a10.98 10.98 0 0 0-9.52-5.51c-.77 0-1.55.08-2.3.24A10.868 10.868 0 0 0 19.29 0h-.1c-4.76 0-8.98 3.07-10.45 7.6-3.06.63-5.71 2.55-7.26 5.27a10.993 10.993 0 0 0 1.35 12.87c-.36 1.11-.55 2.27-.55 3.43 0 1.93.51 3.83 1.49 5.49a10.97 10.97 0 0 0 11.82 5.27c2.06 2.32 5.02 3.65 8.12 3.65h.1c4.76 0 8.99-3.07 10.45-7.61a10.82 10.82 0 0 0 7.26-5.26 10.995 10.995 0 0 0-1.35-12.87ZM18.817 38.695c-.09.05-.17.1-.26.15a8.145 8.145 0 0 0 5.22 1.89h.01c4.5-.01 8.15-3.67 8.16-8.17v-10.13a.153.153 0 0 0-.07-.1l-3.67-2.12v12.24c0 .51-.27.98-.72 1.23l-8.67 5.01Zm-1.424-2.472 8.77-5.06c.04-.03.06-.07.06-.11h-.01v-4.24l-10.59 6.12c-.44.25-.98.25-1.42 0l-8.68-5.01c-.08-.05-.2-.12-.26-.16a8.19 8.19 0 0 0 .97 5.47 8.18 8.18 0 0 0 7.08 4.08c1.43 0 2.84-.37 4.08-1.09Zm-9.187-25.21v-.3c-1.79.66-3.3 1.93-4.25 3.58a8.226 8.226 0 0 0-1.09 4.08c0 2.92 1.55 5.61 4.08 7.07l8.77 5.07c.04.02.09.02.12-.01l3.67-2.12-10.59-6.11c-.44-.25-.71-.72-.71-1.23v-10.03Zm27.849 7.117-8.77-5.07a.126.126 0 0 0-.12.01l-3.67 2.12 10.59 6.12c.44.25.71.71.71 1.22v10.33a8.168 8.168 0 0 0 5.35-7.66 8.16 8.16 0 0 0-4.09-7.07Zm-19.22-5.718a.16.16 0 0 0-.05.11v4.24l10.59-6.12c.22-.12.47-.19.72-.19s.49.07.71.19l8.68 5.02c.08.05.17.1.25.15.08-.46.12-.92.12-1.38 0-4.51-3.66-8.17-8.17-8.17-1.43 0-2.83.38-4.08 1.09l-8.77 5.06ZM19.22 2.85c-4.51 0-8.17 3.65-8.17 8.16v10.13c.01.05.03.08.07.1l3.67 2.12.01-12.23v-.01c0-.5.27-.97.71-1.22l8.68-5.01c.07-.05.19-.11.25-.15a8.145 8.145 0 0 0-5.22-1.89ZM16.783 24.51l4.72 2.73 4.72-2.73v-5.45l-4.72-2.72-4.72 2.73v5.44Z"
  }))));
};
/* harmony default export */ const chatgpt = (SvgChatgpt);
// EXTERNAL MODULE: ./app/icons/add.svg
var add = __webpack_require__(1935);
// EXTERNAL MODULE: ./app/icons/close.svg
var icons_close = __webpack_require__(4299);
// EXTERNAL MODULE: ./app/locales/index.ts + 8 modules
var locales = __webpack_require__(1452);
// EXTERNAL MODULE: ./app/store/index.ts + 3 modules
var store = __webpack_require__(1209);
;// CONCATENATED MODULE: ./app/components/sidebar.tsx













const ChatList = app_dynamic_default()(async ()=>(await Promise.all(/* import() */[__webpack_require__.e(717), __webpack_require__.e(423), __webpack_require__.e(710)]).then(__webpack_require__.bind(__webpack_require__, 5710))).ChatList, {
    loadableGenerated: {
        modules: [
            "E:\\code\\ChatGPT-Next-Web-main\\app\\components\\sidebar.tsx -> " + "./chat-list"
        ]
    },
    loading: ()=>null
});
function useDragSideBar() {
    const limit = (x)=>Math.min(constant/* MAX_SIDEBAR_WIDTH */.kf, x);
    const config = (0,store/* useAppConfig */.MG)();
    const startX = (0,react_.useRef)(0);
    const startDragWidth = (0,react_.useRef)(config.sidebarWidth ?? 300);
    const lastUpdateTime = (0,react_.useRef)(Date.now());
    const handleMouseMove = (0,react_.useRef)((e)=>{
        if (Date.now() < lastUpdateTime.current + 50) {
            return;
        }
        lastUpdateTime.current = Date.now();
        const d = e.clientX - startX.current;
        const nextWidth = limit(startDragWidth.current + d);
        config.update((config)=>config.sidebarWidth = nextWidth);
    });
    const handleMouseUp = (0,react_.useRef)(()=>{
        startDragWidth.current = config.sidebarWidth ?? 300;
        window.removeEventListener("mousemove", handleMouseMove.current);
        window.removeEventListener("mouseup", handleMouseUp.current);
    });
    const onDragMouseDown = (e)=>{
        startX.current = e.clientX;
        window.addEventListener("mousemove", handleMouseMove.current);
        window.addEventListener("mouseup", handleMouseUp.current);
    };
    const isMobileScreen = (0,utils/* useMobileScreen */.S0)();
    const shouldNarrow = !isMobileScreen && config.sidebarWidth < constant/* MIN_SIDEBAR_WIDTH */.NQ;
    (0,react_.useEffect)(()=>{
        const barWidth = shouldNarrow ? constant/* NARROW_SIDEBAR_WIDTH */.bH : limit(config.sidebarWidth ?? 300);
        const sideBarWidth = isMobileScreen ? "100vw" : `${barWidth}px`;
        document.documentElement.style.setProperty("--sidebar-width", sideBarWidth);
    }, [
        config.sidebarWidth,
        isMobileScreen,
        shouldNarrow
    ]);
    return {
        onDragMouseDown,
        shouldNarrow
    };
}
function SideBar(props) {
    const chatStore = (0,store/* useChatStore */.aK)();
    // drag side bar
    const { onDragMouseDown , shouldNarrow  } = useDragSideBar();
    const navigate = (0,react_router_dom_production_min.useNavigate)();
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: `${(home_module_default()).sidebar} ${props.className} ${shouldNarrow && (home_module_default())["narrow-sidebar"]}`,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (home_module_default())["sidebar-header"],
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (home_module_default())["sidebar-title"],
                        children: "高济AI"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (home_module_default())["sidebar-sub-title"]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (home_module_default())["sidebar-logo"],
                        children: /*#__PURE__*/ jsx_runtime_.jsx(chatgpt, {})
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (home_module_default())["sidebar-body"],
                onClick: (e)=>{
                    if (e.target === e.currentTarget) {
                        navigate(constant/* Path.Home */.y$.Home);
                    }
                },
                children: /*#__PURE__*/ jsx_runtime_.jsx(ChatList, {
                    narrow: shouldNarrow
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (home_module_default())["sidebar-tail"],
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (home_module_default())["sidebar-actions"],
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: (home_module_default())["sidebar-action"] + " " + (home_module_default()).mobile,
                            children: /*#__PURE__*/ jsx_runtime_.jsx(components_button/* IconButton */.h, {
                                icon: /*#__PURE__*/ jsx_runtime_.jsx(icons_close/* default */.Z, {}),
                                onClick: chatStore.deleteSession
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        children: /*#__PURE__*/ jsx_runtime_.jsx(components_button/* IconButton */.h, {
                            icon: /*#__PURE__*/ jsx_runtime_.jsx(add/* default */.Z, {}),
                            text: shouldNarrow ? undefined : locales/* default.Home.NewChat */.ZP.Home.NewChat,
                            onClick: ()=>{
                                chatStore.newSession();
                            },
                            shadow: true
                        })
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (home_module_default())["sidebar-drag"],
                onMouseDown: (e)=>onDragMouseDown(e)
            })
        ]
    });
}

// EXTERNAL MODULE: ./app/store/config.ts
var store_config = __webpack_require__(293);
;// CONCATENATED MODULE: ./app/components/home.tsx
/* __next_internal_client_entry_do_not_use__ Loading,useSwitchTheme,Home auto */ 
__webpack_require__(1682);












function Loading(props) {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (home_module_default())["loading-content"] + " no-dark",
        children: [
            !props.noLogo && /*#__PURE__*/ jsx_runtime_.jsx(bot/* default */.Z, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(three_dots/* default */.Z, {})
        ]
    });
}
const Settings = app_dynamic_default()(async ()=>(await Promise.all(/* import() */[__webpack_require__.e(480), __webpack_require__.e(621), __webpack_require__.e(698)]).then(__webpack_require__.bind(__webpack_require__, 8698))).Settings, {
    loadableGenerated: {
        modules: [
            "E:\\code\\ChatGPT-Next-Web-main\\app\\components\\home.tsx -> " + "./settings"
        ]
    },
    loading: ()=>/*#__PURE__*/ jsx_runtime_.jsx(Loading, {
            noLogo: true
        })
});
function useSwitchTheme() {
    const config = (0,store_config/* useAppConfig */.MG)();
    (0,react_.useEffect)(()=>{
        document.body.classList.remove("light");
        document.body.classList.remove("dark");
        if (config.theme === "dark") {
            document.body.classList.add("dark");
        } else if (config.theme === "light") {
            document.body.classList.add("light");
        }
        const metaDescriptionDark = document.querySelector('meta[name="theme-color"][media]');
        const metaDescriptionLight = document.querySelector('meta[name="theme-color"]:not([media])');
        if (config.theme === "auto") {
            metaDescriptionDark?.setAttribute("content", "#151515");
            metaDescriptionLight?.setAttribute("content", "#fafafa");
        } else {
            const themeColor = (0,utils/* getCSSVar */.K1)("--themeColor");
            metaDescriptionDark?.setAttribute("content", themeColor);
            metaDescriptionLight?.setAttribute("content", themeColor);
        }
    }, [
        config.theme
    ]);
}
const useHasHydrated = ()=>{
    const [hasHydrated, setHasHydrated] = (0,react_.useState)(false);
    (0,react_.useEffect)(()=>{
        setHasHydrated(true);
    }, []);
    return hasHydrated;
};
function WideScreen() {
    const config = (0,store_config/* useAppConfig */.MG)();
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: `${config.tightBorder ? (home_module_default())["tight-container"] : (home_module_default()).container}`,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(SideBar, {}),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (home_module_default())["window-content"],
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_router_dom_production_min.Routes, {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(react_router_dom_production_min.Route, {
                            path: constant/* Path.Home */.y$.Home,
                            element: /*#__PURE__*/ jsx_runtime_.jsx(chat/* Chat */.en, {})
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(react_router_dom_production_min.Route, {
                            path: constant/* Path.Chat */.y$.Chat,
                            element: /*#__PURE__*/ jsx_runtime_.jsx(chat/* Chat */.en, {})
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(react_router_dom_production_min.Route, {
                            path: constant/* Path.Settings */.y$.Settings,
                            element: /*#__PURE__*/ jsx_runtime_.jsx(Settings, {})
                        })
                    ]
                })
            })
        ]
    });
}
function MobileScreen() {
    const location = (0,react_router_dom_production_min.useLocation)();
    const isHome = location.pathname === constant/* Path.Home */.y$.Home;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (home_module_default()).container,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(SideBar, {
                className: isHome ? (home_module_default())["sidebar-show"] : ""
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (home_module_default())["window-content"],
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_router_dom_production_min.Routes, {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(react_router_dom_production_min.Route, {
                            path: constant/* Path.Home */.y$.Home,
                            element: null
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(react_router_dom_production_min.Route, {
                            path: constant/* Path.Chat */.y$.Chat,
                            element: /*#__PURE__*/ jsx_runtime_.jsx(chat/* Chat */.en, {})
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(react_router_dom_production_min.Route, {
                            path: constant/* Path.Settings */.y$.Settings,
                            element: /*#__PURE__*/ jsx_runtime_.jsx(Settings, {})
                        })
                    ]
                })
            })
        ]
    });
}
function Home() {
    const isMobileScreen = (0,utils/* useMobileScreen */.S0)();
    useSwitchTheme();
    if (!useHasHydrated()) {
        return /*#__PURE__*/ jsx_runtime_.jsx(Loading, {});
    }
    return /*#__PURE__*/ jsx_runtime_.jsx(error/* ErrorBoundary */.S, {
        children: /*#__PURE__*/ jsx_runtime_.jsx(react_router_dom_production_min.HashRouter, {
            children: isMobileScreen ? /*#__PURE__*/ jsx_runtime_.jsx(MobileScreen, {}) : /*#__PURE__*/ jsx_runtime_.jsx(WideScreen, {})
        })
    });
}


/***/ }),

/***/ 2634:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "II": () => (/* binding */ Input),
  "aV": () => (/* binding */ List),
  "HC": () => (/* binding */ ListItem),
  "u_": () => (/* binding */ Modal),
  "J2": () => (/* binding */ Popover),
  "K4": () => (/* binding */ showModal),
  "CF": () => (/* binding */ showToast)
});

// UNUSED EXPORTS: Card, Loading, Toast

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6786);
// EXTERNAL MODULE: ./app/components/ui-lib.module.scss
var ui_lib_module = __webpack_require__(3304);
var ui_lib_module_default = /*#__PURE__*/__webpack_require__.n(ui_lib_module);
// EXTERNAL MODULE: ./app/icons/three-dots.svg
var three_dots = __webpack_require__(3076);
// EXTERNAL MODULE: ./app/icons/close.svg
var icons_close = __webpack_require__(4299);
;// CONCATENATED MODULE: external "next/dist/compiled/react-dom/client"
const client_namespaceObject = require("next/dist/compiled/react-dom/client");
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(8038);
;// CONCATENATED MODULE: ./app/components/ui-lib.tsx






function Popover(props) {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (ui_lib_module_default()).popover,
        children: [
            props.children,
            props.open && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (ui_lib_module_default())["popover-content"],
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (ui_lib_module_default())["popover-mask"],
                        onClick: props.onClose
                    }),
                    props.content
                ]
            })
        ]
    });
}
function Card(props) {
    return /*#__PURE__*/ _jsx("div", {
        className: styles.card + " " + props.className,
        children: props.children
    });
}
function ListItem(props) {
    if (props.children.length > 2) {
        throw Error("Only Support Two Children");
    }
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: (ui_lib_module_default())["list-item"],
        children: props.children
    });
}
function List(props) {
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: (ui_lib_module_default()).list,
        children: props.children
    });
}
function Loading() {
    return /*#__PURE__*/ _jsx("div", {
        style: {
            height: "100vh",
            width: "100vw",
            display: "flex",
            alignItems: "center",
            justifyContent: "center"
        },
        children: /*#__PURE__*/ _jsx(LoadingIcon, {})
    });
}
function Modal(props) {
    (0,react_.useEffect)(()=>{
        const onKeyDown = (e)=>{
            if (e.key === "Escape") {
                props.onClose?.();
            }
        };
        window.addEventListener("keydown", onKeyDown);
        return ()=>{
            window.removeEventListener("keydown", onKeyDown);
        };
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (ui_lib_module_default())["modal-container"],
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (ui_lib_module_default())["modal-header"],
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (ui_lib_module_default())["modal-title"],
                        children: props.title
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (ui_lib_module_default())["modal-close-btn"],
                        onClick: props.onClose,
                        children: /*#__PURE__*/ jsx_runtime_.jsx(icons_close/* default */.Z, {})
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (ui_lib_module_default())["modal-content"],
                children: props.children
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (ui_lib_module_default())["modal-footer"],
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: (ui_lib_module_default())["modal-actions"],
                    children: props.actions?.map((action, i)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: (ui_lib_module_default())["modal-action"],
                            children: action
                        }, i))
                })
            })
        ]
    });
}
function showModal(props) {
    const div = document.createElement("div");
    div.className = "modal-mask";
    document.body.appendChild(div);
    const root = (0,client_namespaceObject.createRoot)(div);
    const closeModal = ()=>{
        props.onClose?.();
        root.unmount();
        div.remove();
    };
    div.onclick = (e)=>{
        if (e.target === div) {
            closeModal();
        }
    };
    root.render(/*#__PURE__*/ jsx_runtime_.jsx(Modal, {
        ...props,
        onClose: closeModal
    }));
}
function Toast(props) {
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: (ui_lib_module_default())["toast-container"],
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: (ui_lib_module_default())["toast-content"],
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                    children: props.content
                }),
                props.action && /*#__PURE__*/ jsx_runtime_.jsx("button", {
                    onClick: props.action.onClick,
                    className: (ui_lib_module_default())["toast-action"],
                    children: props.action.text
                })
            ]
        })
    });
}
function showToast(content, action, delay = 3000) {
    const div = document.createElement("div");
    div.className = (ui_lib_module_default()).show;
    document.body.appendChild(div);
    const root = (0,client_namespaceObject.createRoot)(div);
    const close = ()=>{
        div.classList.add((ui_lib_module_default()).hide);
        setTimeout(()=>{
            root.unmount();
            div.remove();
        }, 300);
    };
    setTimeout(()=>{
        close();
    }, delay);
    root.render(/*#__PURE__*/ jsx_runtime_.jsx(Toast, {
        content: content,
        action: action
    }));
}
function Input(props) {
    return /*#__PURE__*/ jsx_runtime_.jsx("textarea", {
        ...props,
        className: `${(ui_lib_module_default()).input} ${props.className}`
    });
}


/***/ }),

/***/ 2080:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Cs": () => (/* binding */ UPDATE_URL),
/* harmony export */   "NQ": () => (/* binding */ MIN_SIDEBAR_WIDTH),
/* harmony export */   "TE": () => (/* binding */ FETCH_COMMIT_URL),
/* harmony export */   "TH": () => (/* binding */ ISSUE_URL),
/* harmony export */   "bH": () => (/* binding */ NARROW_SIDEBAR_WIDTH),
/* harmony export */   "kf": () => (/* binding */ MAX_SIDEBAR_WIDTH),
/* harmony export */   "y$": () => (/* binding */ Path)
/* harmony export */ });
/* unused harmony exports OWNER, REPO, REPO_URL, FETCH_TAG_URL, RUNTIME_CONFIG_DOM */
const OWNER = "Yidadaa";
const REPO = "ChatGPT-Next-Web";
const REPO_URL = `https://github.com/${OWNER}/${REPO}`;
const ISSUE_URL = `https://github.com/${OWNER}/${REPO}/issues`;
const UPDATE_URL = `${REPO_URL}#keep-updated`;
const FETCH_COMMIT_URL = `https://api.github.com/repos/${OWNER}/${REPO}/commits?per_page=1`;
const FETCH_TAG_URL = `https://api.github.com/repos/${OWNER}/${REPO}/tags?per_page=1`;
const RUNTIME_CONFIG_DOM = "danger-runtime-config";
var Path;
(function(Path) {
    Path["Home"] = "/";
    Path["Chat"] = "/chat";
    Path["Settings"] = "/settings";
})(Path || (Path = {}));
const MAX_SIDEBAR_WIDTH = 500;
const MIN_SIDEBAR_WIDTH = 230;
const NARROW_SIDEBAR_WIDTH = 100;


/***/ }),

/***/ 1452:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "DC": () => (/* binding */ AllLangs),
  "t4": () => (/* binding */ changeLang),
  "ZP": () => (/* binding */ locales),
  "VQ": () => (/* binding */ getLang)
});

// EXTERNAL MODULE: ./app/store/config.ts
var config = __webpack_require__(293);
;// CONCATENATED MODULE: ./app/locales/cn.ts

const cn = {
    WIP: "该功能仍在开发中……",
    Error: {
        Unauthorized: "现在是未授权状态，请点击左下角设置按钮输入访问密码。"
    },
    ChatItem: {
        ChatItemCount: (count)=>`${count} 条对话`
    },
    Chat: {
        SubTitle: (count)=>`与 高济AI 的 ${count} 条对话`,
        Actions: {
            ChatList: "查看消息列表",
            CompressedHistory: "查看压缩后的历史 Prompt",
            Export: "导出聊天记录",
            Copy: "复制",
            Stop: "停止",
            Retry: "重试",
            Delete: "删除"
        },
        Rename: "重命名对话",
        Typing: "正在输入…",
        Input: (submitKey)=>{
            var inputHints = `${submitKey} 发送`;
            if (submitKey === String(config/* SubmitKey.Enter */.mQ.Enter)) {
                inputHints += "，Shift + Enter 换行";
            }
            return inputHints + "，/ 触发补全";
        },
        Send: "发送"
    },
    Export: {
        Title: "导出聊天记录为 Markdown",
        Copy: "全部复制",
        Download: "下载文件",
        MessageFromYou: "来自你的消息",
        MessageFromChatGPT: "来自 高济AI 的消息"
    },
    Memory: {
        Title: "历史摘要",
        EmptyContent: "尚未总结",
        Send: "启用总结并发送摘要",
        Copy: "复制摘要",
        Reset: "重置对话",
        ResetConfirm: "重置后将清空当前对话记录以及历史摘要，确认重置？"
    },
    Home: {
        NewChat: "新的聊天",
        DeleteChat: "确认删除选中的对话？",
        DeleteToast: "已删除会话",
        Revert: "撤销"
    },
    Settings: {
        Title: "设置",
        SubTitle: "设置选项",
        Actions: {
            ClearAll: "清除所有数据",
            ResetAll: "重置所有选项",
            Close: "关闭",
            ConfirmResetAll: {
                Confirm: "确认清除所有配置？"
            },
            ConfirmClearAll: {
                Confirm: "确认清除所有聊天记录？"
            }
        },
        Lang: {
            Name: "Language",
            Options: {
                cn: "简体中文",
                en: "English",
                tw: "繁體中文",
                es: "Espa\xf1ol",
                it: "Italiano",
                tr: "T\xfcrk\xe7e",
                jp: "日本語",
                de: "Deutsch"
            }
        },
        Avatar: "头像",
        FontSize: {
            Title: "字体大小",
            SubTitle: "聊天内容的字体大小"
        },
        Update: {
            Version: (x)=>`当前版本：${x}`,
            IsLatest: "已是最新版本",
            CheckUpdate: "检查更新",
            IsChecking: "正在检查更新...",
            FoundUpdate: (x)=>`发现新版本：${x}`,
            GoToUpdate: "前往更新"
        },
        SendKey: "发送键",
        Theme: "主题",
        TightBorder: "无边框模式",
        SendPreviewBubble: "发送预览气泡",
        Prompt: {
            Disable: {
                Title: "禁用提示词自动补全",
                SubTitle: "在输入框开头输入 / 即可触发自动补全"
            },
            List: "自定义提示词列表",
            ListCount: (builtin, custom)=>`内置 ${builtin} 条，用户定义 ${custom} 条`,
            Edit: "编辑",
            Modal: {
                Title: "提示词列表",
                Add: "增加一条",
                Search: "搜索提示词"
            }
        },
        HistoryCount: {
            Title: "附带历史消息数",
            SubTitle: "每次请求携带的历史消息数"
        },
        CompressThreshold: {
            Title: "历史消息长度压缩阈值",
            SubTitle: "当未压缩的历史消息超过该值时，将进行压缩"
        },
        Token: {
            Title: "API Key",
            SubTitle: "使用自己的 Key 可绕过密码访问限制",
            Placeholder: "OpenAI API Key"
        },
        Usage: {
            Title: "余额查询",
            SubTitle (used, total) {
                return `本月已使用 $${used}，订阅总额 $${total}`;
            },
            IsChecking: "正在检查…",
            Check: "重新检查",
            NoAccess: "输入 API Key 或访问密码查看余额"
        },
        AccessCode: {
            Title: "访问密码",
            SubTitle: "已开启加密访问",
            Placeholder: "请输入访问密码"
        },
        Model: "模型 (model)",
        Temperature: {
            Title: "随机性 (temperature)",
            SubTitle: "值越大，回复越随机，大于 1 的值可能会导致乱码"
        },
        MaxTokens: {
            Title: "单次回复限制 (max_tokens)",
            SubTitle: "单次交互所用的最大 Token 数"
        },
        PresencePenlty: {
            Title: "话题新鲜度 (presence_penalty)",
            SubTitle: "值越大，越有可能扩展到新话题"
        }
    },
    Store: {
        DefaultTopic: "新的聊天",
        BotHello: "有什么可以帮你的吗",
        Error: "出错了，稍后重试吧",
        Prompt: {
            History: (content)=>"这是 ai 和用户的历史聊天总结作为前情提要：" + content,
            Topic: "使用四到五个字直接返回这句话的简要主题，不要解释、不要标点、不要语气词、不要多余文本，如果没有主题，请直接返回“闲聊”",
            Summarize: "简要总结一下你和用户的对话，用作后续的上下文提示 prompt，控制在 200 字以内"
        },
        ConfirmClearAll: "确认清除所有聊天、设置数据？"
    },
    Copy: {
        Success: "已写入剪切板",
        Failed: "复制失败，请赋予剪切板权限"
    },
    Context: {
        Toast: (x)=>`已设置 ${x} 条前置上下文`,
        Edit: "前置上下文和历史记忆",
        Add: "新增一条"
    }
};
/* harmony default export */ const locales_cn = (cn);

;// CONCATENATED MODULE: ./app/locales/en.ts

const en = {
    WIP: "WIP...",
    Error: {
        Unauthorized: "Unauthorized access, please enter access code in settings page."
    },
    ChatItem: {
        ChatItemCount: (count)=>`${count} messages`
    },
    Chat: {
        SubTitle: (count)=>`${count} messages with 高济AI`,
        Actions: {
            ChatList: "Go To Chat List",
            CompressedHistory: "Compressed History Memory Prompt",
            Export: "Export All Messages as Markdown",
            Copy: "Copy",
            Stop: "Stop",
            Retry: "Retry",
            Delete: "Delete"
        },
        Rename: "Rename Chat",
        Typing: "Typing…",
        Input: (submitKey)=>{
            var inputHints = `${submitKey} to send`;
            if (submitKey === String(config/* SubmitKey.Enter */.mQ.Enter)) {
                inputHints += ", Shift + Enter to wrap";
            }
            return inputHints + ", / to search prompts";
        },
        Send: "Send"
    },
    Export: {
        Title: "All Messages",
        Copy: "Copy All",
        Download: "Download",
        MessageFromYou: "Message From You",
        MessageFromChatGPT: "Message From 高济AI"
    },
    Memory: {
        Title: "Memory Prompt",
        EmptyContent: "Nothing yet.",
        Send: "Send Memory",
        Copy: "Copy Memory",
        Reset: "Reset Session",
        ResetConfirm: "Resetting will clear the current conversation history and historical memory. Are you sure you want to reset?"
    },
    Home: {
        NewChat: "New Chat",
        DeleteChat: "Confirm to delete the selected conversation?",
        DeleteToast: "Chat Deleted",
        Revert: "Revert"
    },
    Settings: {
        Title: "Settings",
        SubTitle: "All Settings",
        Actions: {
            ClearAll: "Clear All Data",
            ResetAll: "Reset All Settings",
            Close: "Close",
            ConfirmResetAll: {
                Confirm: "Are you sure you want to reset all configurations?"
            },
            ConfirmClearAll: {
                Confirm: "Are you sure you want to reset all chat?"
            }
        },
        Lang: {
            Name: "Language",
            Options: {
                cn: "简体中文",
                en: "English",
                tw: "繁體中文",
                es: "Espa\xf1ol",
                it: "Italiano",
                tr: "T\xfcrk\xe7e",
                jp: "日本語",
                de: "Deutsch"
            }
        },
        Avatar: "Avatar",
        FontSize: {
            Title: "Font Size",
            SubTitle: "Adjust font size of chat content"
        },
        Update: {
            Version: (x)=>`Version: ${x}`,
            IsLatest: "Latest version",
            CheckUpdate: "Check Update",
            IsChecking: "Checking update...",
            FoundUpdate: (x)=>`Found new version: ${x}`,
            GoToUpdate: "Update"
        },
        SendKey: "Send Key",
        Theme: "Theme",
        TightBorder: "Tight Border",
        SendPreviewBubble: "Send Preview Bubble",
        Prompt: {
            Disable: {
                Title: "Disable auto-completion",
                SubTitle: "Input / to trigger auto-completion"
            },
            List: "Prompt List",
            ListCount: (builtin, custom)=>`${builtin} built-in, ${custom} user-defined`,
            Edit: "Edit",
            Modal: {
                Title: "Prompt List",
                Add: "Add One",
                Search: "Search Prompts"
            }
        },
        HistoryCount: {
            Title: "Attached Messages Count",
            SubTitle: "Number of sent messages attached per request"
        },
        CompressThreshold: {
            Title: "History Compression Threshold",
            SubTitle: "Will compress if uncompressed messages length exceeds the value"
        },
        Token: {
            Title: "API Key",
            SubTitle: "Use your key to ignore access code limit",
            Placeholder: "OpenAI API Key"
        },
        Usage: {
            Title: "Account Balance",
            SubTitle (used, total) {
                return `Used this month $${used}, subscription $${total}`;
            },
            IsChecking: "Checking...",
            Check: "Check",
            NoAccess: "Enter API Key to check balance"
        },
        AccessCode: {
            Title: "Access Code",
            SubTitle: "Access control enabled",
            Placeholder: "Need Access Code"
        },
        Model: "Model",
        Temperature: {
            Title: "Temperature",
            SubTitle: "A larger value makes the more random output"
        },
        MaxTokens: {
            Title: "Max Tokens",
            SubTitle: "Maximum length of input tokens and generated tokens"
        },
        PresencePenlty: {
            Title: "Presence Penalty",
            SubTitle: "A larger value increases the likelihood to talk about new topics"
        }
    },
    Store: {
        DefaultTopic: "New Conversation",
        BotHello: "Hello! How can I assist you today?",
        Error: "Something went wrong, please try again later.",
        Prompt: {
            History: (content)=>"This is a summary of the chat history between the AI and the user as a recap: " + content,
            Topic: "Please generate a four to five word title summarizing our conversation without any lead-in, punctuation, quotation marks, periods, symbols, or additional text. Remove enclosing quotation marks.",
            Summarize: "Summarize our discussion briefly in 200 words or less to use as a prompt for future context."
        },
        ConfirmClearAll: "Confirm to clear all chat and setting data?"
    },
    Copy: {
        Success: "Copied to clipboard",
        Failed: "Copy failed, please grant permission to access clipboard"
    },
    Context: {
        Toast: (x)=>`With ${x} contextual prompts`,
        Edit: "Contextual and Memory Prompts",
        Add: "Add One"
    }
};
/* harmony default export */ const locales_en = (en);

;// CONCATENATED MODULE: ./app/locales/tw.ts

const tw = {
    WIP: "該功能仍在開發中……",
    Error: {
        Unauthorized: "目前您的狀態是未授權，請前往設定頁面輸入授權碼。"
    },
    ChatItem: {
        ChatItemCount: (count)=>`${count} 條對話`
    },
    Chat: {
        SubTitle: (count)=>`您已經與 高济AI 進行了 ${count} 條對話`,
        Actions: {
            ChatList: "查看訊息列表",
            CompressedHistory: "查看壓縮後的歷史 Prompt",
            Export: "匯出聊天紀錄",
            Copy: "複製",
            Stop: "停止",
            Retry: "重試",
            Delete: "刪除"
        },
        Rename: "重命名對話",
        Typing: "正在輸入…",
        Input: (submitKey)=>{
            var inputHints = `輸入訊息後，按下 ${submitKey} 鍵即可發送`;
            if (submitKey === String(config/* SubmitKey.Enter */.mQ.Enter)) {
                inputHints += "，Shift + Enter 鍵換行";
            }
            return inputHints;
        },
        Send: "發送"
    },
    Export: {
        Title: "將聊天記錄匯出為 Markdown",
        Copy: "複製全部",
        Download: "下載檔案",
        MessageFromYou: "來自您的訊息",
        MessageFromChatGPT: "來自 高济AI 的訊息"
    },
    Memory: {
        Title: "上下文記憶 Prompt",
        EmptyContent: "尚未記憶",
        Copy: "複製全部",
        Send: "發送記憶",
        Reset: "重設對話",
        ResetConfirm: "重設後將清除目前對話記錄以及歷史記憶，確認重設？"
    },
    Home: {
        NewChat: "新的對話",
        DeleteChat: "確定要刪除選取的對話嗎？",
        DeleteToast: "已刪除對話",
        Revert: "撤銷"
    },
    Settings: {
        Title: "設定",
        SubTitle: "設定選項",
        Actions: {
            ClearAll: "清除所有資料",
            ResetAll: "重設所有設定",
            Close: "關閉",
            ConfirmResetAll: {
                Confirm: "您確定要重設所有設定嗎？"
            },
            ConfirmClearAll: {
                Confirm: "您確定要清除所有聊天嗎？"
            }
        },
        Lang: {
            Name: "語言",
            Options: {
                cn: "简体中文",
                en: "English",
                tw: "繁體中文",
                es: "Espa\xf1ol",
                it: "Italiano",
                tr: "T\xfcrk\xe7e",
                jp: "日本語",
                de: "Deutsch"
            }
        },
        Avatar: "大頭貼",
        FontSize: {
            Title: "字型大小",
            SubTitle: "聊天內容的字型大小"
        },
        Update: {
            Version: (x)=>`當前版本：${x}`,
            IsLatest: "已是最新版本",
            CheckUpdate: "檢查更新",
            IsChecking: "正在檢查更新...",
            FoundUpdate: (x)=>`發現新版本：${x}`,
            GoToUpdate: "前往更新"
        },
        SendKey: "發送鍵",
        Theme: "主題",
        TightBorder: "緊湊邊框",
        SendPreviewBubble: "發送預覽氣泡",
        Prompt: {
            Disable: {
                Title: "停用提示詞自動補齊",
                SubTitle: "在輸入框開頭輸入 / 即可觸發自動補齊"
            },
            List: "自定義提示詞列表",
            ListCount: (builtin, custom)=>`內建 ${builtin} 條，用戶定義 ${custom} 條`,
            Edit: "編輯",
            Modal: {
                Title: "提示詞列表",
                Add: "新增一條",
                Search: "搜尋提示詞"
            }
        },
        HistoryCount: {
            Title: "附帶歷史訊息數",
            SubTitle: "每次請求附帶的歷史訊息數"
        },
        CompressThreshold: {
            Title: "歷史訊息長度壓縮閾值",
            SubTitle: "當未壓縮的歷史訊息超過該值時，將進行壓縮"
        },
        Token: {
            Title: "API Key",
            SubTitle: "使用自己的 Key 可規避授權存取限制",
            Placeholder: "OpenAI API Key"
        },
        Usage: {
            Title: "帳戶餘額",
            SubTitle (used, total) {
                return `本月已使用 $${used}，訂閱總額 $${total}`;
            },
            IsChecking: "正在檢查…",
            Check: "重新檢查",
            NoAccess: "輸入API Key查看餘額"
        },
        AccessCode: {
            Title: "授權碼",
            SubTitle: "目前是未授權存取狀態",
            Placeholder: "請輸入授權碼"
        },
        Model: "模型 (model)",
        Temperature: {
            Title: "隨機性 (temperature)",
            SubTitle: "值越大，回應越隨機"
        },
        MaxTokens: {
            Title: "單次回應限制 (max_tokens)",
            SubTitle: "單次互動所用的最大 Token 數"
        },
        PresencePenlty: {
            Title: "話題新穎度 (presence_penalty)",
            SubTitle: "值越大，越有可能擴展到新話題"
        }
    },
    Store: {
        DefaultTopic: "新的對話",
        BotHello: "請問需要我的協助嗎？",
        Error: "出錯了，請稍後再嘗試",
        Prompt: {
            History: (content)=>"這是 AI 與用戶的歷史聊天總結，作為前情提要：" + content,
            Topic: "Use the language used by the user (e.g. en for english conversation, zh-hant for chinese conversation, etc.) to generate a title (at most 6 words) summarizing our conversation without any lead-in, quotation marks, preamble like 'Title:', direct text copies, single-word replies, quotation marks, translations, or brackets. Remove enclosing quotation marks. The title should make third-party grasp the essence of the conversation in first sight.",
            Summarize: "Use the language used by the user (e.g. en-us for english conversation, zh-hant for chinese conversation, etc.) to summarise the conversation in at most 200 words. The summary will be used as prompt for you to continue the conversation in the future."
        },
        ConfirmClearAll: "確認清除所有對話、設定？"
    },
    Copy: {
        Success: "已複製到剪貼簿中",
        Failed: "複製失敗，請賦予剪貼簿權限"
    },
    Context: {
        Toast: (x)=>`已設定 ${x} 條前置上下文`,
        Edit: "前置上下文和歷史記憶",
        Add: "新增一條"
    }
};
/* harmony default export */ const locales_tw = (tw);

;// CONCATENATED MODULE: ./app/locales/es.ts

const es = {
    WIP: "En construcci\xf3n...",
    Error: {
        Unauthorized: "Acceso no autorizado, por favor ingrese el c\xf3digo de acceso en la p\xe1gina de configuraci\xf3n."
    },
    ChatItem: {
        ChatItemCount: (count)=>`${count} mensajes`
    },
    Chat: {
        SubTitle: (count)=>`${count} mensajes con 高济AI`,
        Actions: {
            ChatList: "Ir a la lista de chats",
            CompressedHistory: "Historial de memoria comprimido",
            Export: "Exportar todos los mensajes como Markdown",
            Copy: "Copiar",
            Stop: "Detener",
            Retry: "Reintentar",
            Delete: "Delete"
        },
        Rename: "Renombrar chat",
        Typing: "Escribiendo...",
        Input: (submitKey)=>{
            var inputHints = `Escribe algo y presiona ${submitKey} para enviar`;
            if (submitKey === String(config/* SubmitKey.Enter */.mQ.Enter)) {
                inputHints += ", presiona Shift + Enter para nueva l\xednea";
            }
            return inputHints;
        },
        Send: "Enviar"
    },
    Export: {
        Title: "Todos los mensajes",
        Copy: "Copiar todo",
        Download: "Descargar",
        MessageFromYou: "Mensaje de ti",
        MessageFromChatGPT: "Mensaje de 高济AI"
    },
    Memory: {
        Title: "Historial de memoria",
        EmptyContent: "A\xfan no hay nada.",
        Copy: "Copiar todo",
        Send: "Send Memory",
        Reset: "Reset Session",
        ResetConfirm: "Resetting will clear the current conversation history and historical memory. Are you sure you want to reset?"
    },
    Home: {
        NewChat: "Nuevo chat",
        DeleteChat: "\xbfConfirmar eliminaci\xf3n de la conversaci\xf3n seleccionada?",
        DeleteToast: "Chat Deleted",
        Revert: "Revert"
    },
    Settings: {
        Title: "Configuraci\xf3n",
        SubTitle: "Todas las configuraciones",
        Actions: {
            ClearAll: "Borrar todos los datos",
            ResetAll: "Restablecer todas las configuraciones",
            Close: "Cerrar",
            ConfirmResetAll: {
                Confirm: "Are you sure you want to reset all configurations?"
            },
            ConfirmClearAll: {
                Confirm: "Are you sure you want to reset all chat?"
            }
        },
        Lang: {
            Name: "Language",
            Options: {
                cn: "简体中文",
                en: "Ingl\xe9s",
                tw: "繁體中文",
                es: "Espa\xf1ol",
                it: "Italiano",
                tr: "T\xfcrk\xe7e",
                jp: "日本語",
                de: "Deutsch"
            }
        },
        Avatar: "Avatar",
        FontSize: {
            Title: "Tama\xf1o de fuente",
            SubTitle: "Ajustar el tama\xf1o de fuente del contenido del chat"
        },
        Update: {
            Version: (x)=>`Versión: ${x}`,
            IsLatest: "\xdaltima versi\xf3n",
            CheckUpdate: "Buscar actualizaciones",
            IsChecking: "Buscando actualizaciones...",
            FoundUpdate: (x)=>`Se encontró una nueva versión: ${x}`,
            GoToUpdate: "Actualizar"
        },
        SendKey: "Tecla de env\xedo",
        Theme: "Tema",
        TightBorder: "Borde ajustado",
        SendPreviewBubble: "Enviar burbuja de vista previa",
        Prompt: {
            Disable: {
                Title: "Desactivar autocompletado",
                SubTitle: "Escribe / para activar el autocompletado"
            },
            List: "Lista de autocompletado",
            ListCount: (builtin, custom)=>`${builtin} incorporado, ${custom} definido por el usuario`,
            Edit: "Editar",
            Modal: {
                Title: "Prompt List",
                Add: "Add One",
                Search: "Search Prompts"
            }
        },
        HistoryCount: {
            Title: "Cantidad de mensajes adjuntos",
            SubTitle: "N\xfamero de mensajes enviados adjuntos por solicitud"
        },
        CompressThreshold: {
            Title: "Umbral de compresi\xf3n de historial",
            SubTitle: "Se comprimir\xe1n los mensajes si la longitud de los mensajes no comprimidos supera el valor"
        },
        Token: {
            Title: "Clave de API",
            SubTitle: "Utiliza tu clave para ignorar el l\xedmite de c\xf3digo de acceso",
            Placeholder: "Clave de la API de OpenAI"
        },
        Usage: {
            Title: "Saldo de la cuenta",
            SubTitle (used, total) {
                return `Usado $${used}, subscription $${total}`;
            },
            IsChecking: "Comprobando...",
            Check: "Comprobar de nuevo",
            NoAccess: "Introduzca la clave API para comprobar el saldo"
        },
        AccessCode: {
            Title: "C\xf3digo de acceso",
            SubTitle: "Control de acceso habilitado",
            Placeholder: "Necesita c\xf3digo de acceso"
        },
        Model: "Modelo",
        Temperature: {
            Title: "Temperatura",
            SubTitle: "Un valor mayor genera una salida m\xe1s aleatoria"
        },
        MaxTokens: {
            Title: "M\xe1ximo de tokens",
            SubTitle: "Longitud m\xe1xima de tokens de entrada y tokens generados"
        },
        PresencePenlty: {
            Title: "Penalizaci\xf3n de presencia",
            SubTitle: "Un valor mayor aumenta la probabilidad de hablar sobre nuevos temas"
        }
    },
    Store: {
        DefaultTopic: "Nueva conversaci\xf3n",
        BotHello: "\xa1Hola! \xbfC\xf3mo puedo ayudarte hoy?",
        Error: "Algo sali\xf3 mal, por favor intenta nuevamente m\xe1s tarde.",
        Prompt: {
            History: (content)=>"Este es un resumen del historial del chat entre la IA y el usuario como recapitulaci\xf3n: " + content,
            Topic: "Por favor, genera un t\xedtulo de cuatro a cinco palabras que resuma nuestra conversaci\xf3n sin ning\xfan inicio, puntuaci\xf3n, comillas, puntos, s\xedmbolos o texto adicional. Elimina las comillas que lo envuelven.",
            Summarize: "Resuma nuestra discusi\xf3n brevemente en 200 caracteres o menos para usarlo como un recordatorio para futuros contextos."
        },
        ConfirmClearAll: "\xbfConfirmar para borrar todos los datos de chat y configuraci\xf3n?"
    },
    Copy: {
        Success: "Copiado al portapapeles",
        Failed: "La copia fall\xf3, por favor concede permiso para acceder al portapapeles"
    },
    Context: {
        Toast: (x)=>`With ${x} contextual prompts`,
        Edit: "Contextual and Memory Prompts",
        Add: "Add One"
    }
};
/* harmony default export */ const locales_es = (es);

;// CONCATENATED MODULE: ./app/locales/it.ts

const it = {
    WIP: "Work in progress...",
    Error: {
        Unauthorized: "Accesso non autorizzato, inserire il codice di accesso nella pagina delle impostazioni."
    },
    ChatItem: {
        ChatItemCount: (count)=>`${count} messaggi`
    },
    Chat: {
        SubTitle: (count)=>`${count} messaggi con 高济AI`,
        Actions: {
            ChatList: "Vai alla Chat List",
            CompressedHistory: "Prompt di memoria della cronologia compressa",
            Export: "Esportazione di tutti i messaggi come Markdown",
            Copy: "Copia",
            Stop: "Stop",
            Retry: "Riprova",
            Delete: "Delete"
        },
        Rename: "Rinomina Chat",
        Typing: "Typing…",
        Input: (submitKey)=>{
            var inputHints = `Scrivi qualcosa e premi ${submitKey} per inviare`;
            if (submitKey === String(config/* SubmitKey.Enter */.mQ.Enter)) {
                inputHints += ", premi Shift + Enter per andare a capo";
            }
            return inputHints;
        },
        Send: "Invia"
    },
    Export: {
        Title: "Tutti i messaggi",
        Copy: "Copia tutto",
        Download: "Scarica",
        MessageFromYou: "Messaggio da te",
        MessageFromChatGPT: "Messaggio da 高济AI"
    },
    Memory: {
        Title: "Prompt di memoria",
        EmptyContent: "Vuoto.",
        Copy: "Copia tutto",
        Send: "Send Memory",
        Reset: "Reset Session",
        ResetConfirm: "Ripristinare canceller\xe0 la conversazione corrente e la cronologia di memoria. Sei sicuro che vuoi riavviare?"
    },
    Home: {
        NewChat: "Nuova Chat",
        DeleteChat: "Confermare la cancellazione della conversazione selezionata?",
        DeleteToast: "Chat Cancellata",
        Revert: "Revert"
    },
    Settings: {
        Title: "Impostazioni",
        SubTitle: "Tutte le impostazioni",
        Actions: {
            ClearAll: "Cancella tutti i dati",
            ResetAll: "Resetta tutte le impostazioni",
            Close: "Chiudi",
            ConfirmResetAll: {
                Confirm: "Sei sicuro vuoi cancellare tutte le impostazioni?"
            },
            ConfirmClearAll: {
                Confirm: "Sei sicuro vuoi cancellare tutte le chat?"
            }
        },
        Lang: {
            Name: "Lingue",
            Options: {
                cn: "简体中文",
                en: "English",
                tw: "繁體中文",
                es: "Espa\xf1ol",
                it: "Italiano",
                tr: "T\xfcrk\xe7e",
                jp: "日本語",
                de: "Deutsch"
            }
        },
        Avatar: "Avatar",
        FontSize: {
            Title: "Dimensione carattere",
            SubTitle: "Regolare la dimensione dei caratteri del contenuto della chat"
        },
        Update: {
            Version: (x)=>`Versione: ${x}`,
            IsLatest: "Ultima versione",
            CheckUpdate: "Controlla aggiornamenti",
            IsChecking: "Sto controllando gli aggiornamenti...",
            FoundUpdate: (x)=>`Trovata nuova versione: ${x}`,
            GoToUpdate: "Aggiorna"
        },
        SendKey: "Tasto invia",
        Theme: "Tema",
        TightBorder: "Schermo intero",
        SendPreviewBubble: "Anteprima di digitazione",
        Prompt: {
            Disable: {
                Title: "Disabilita l'auto completamento",
                SubTitle: "Input / per attivare il completamento automatico"
            },
            List: "Elenco dei suggerimenti",
            ListCount: (builtin, custom)=>`${builtin} built-in, ${custom} user-defined`,
            Edit: "Modifica",
            Modal: {
                Title: "Prompt List",
                Add: "Add One",
                Search: "Search Prompts"
            }
        },
        HistoryCount: {
            Title: "Conteggio dei messaggi allegati",
            SubTitle: "Numero di messaggi inviati allegati per richiesta"
        },
        CompressThreshold: {
            Title: "Soglia di compressione della cronologia",
            SubTitle: "Comprimer\xe0 se la lunghezza dei messaggi non compressi supera il valore"
        },
        Token: {
            Title: "API Key",
            SubTitle: "Utilizzare la chiave per ignorare il limite del codice di accesso",
            Placeholder: "OpenAI API Key"
        },
        Usage: {
            Title: "Bilancio Account",
            SubTitle (used, total) {
                return `Attualmente usato in questo mese $${used}, soglia massima $${total}`;
            },
            IsChecking: "Controllando...",
            Check: "Controlla ancora",
            NoAccess: "Inserire la chiave API per controllare il saldo"
        },
        AccessCode: {
            Title: "Codice d'accesso",
            SubTitle: "Controllo d'accesso abilitato",
            Placeholder: "Inserisci il codice d'accesso"
        },
        Model: "Modello GPT",
        Temperature: {
            Title: "Temperature",
            SubTitle: "Un valore maggiore rende l'output pi\xf9 casuale"
        },
        MaxTokens: {
            Title: "Token massimi",
            SubTitle: "Lunghezza massima dei token in ingresso e dei token generati"
        },
        PresencePenlty: {
            Title: "Penalit\xe0 di presenza",
            SubTitle: "Un valore maggiore aumenta la probabilit\xe0 di parlare di nuovi argomenti"
        }
    },
    Store: {
        DefaultTopic: "Nuova conversazione",
        BotHello: "Ciao, come posso aiutarti oggi?",
        Error: "Qualcosa \xe8 andato storto, riprova pi\xf9 tardi.",
        Prompt: {
            History: (content)=>"Questo \xe8 un riassunto della cronologia delle chat tra l'IA e l'utente:" + content,
            Topic: "Si prega di generare un titolo di quattro o cinque parole che riassuma la nostra conversazione senza alcuna traccia, punteggiatura, virgolette, punti, simboli o testo aggiuntivo. Rimuovere le virgolette",
            Summarize: "Riassumi brevemente la nostra discussione in 200 caratteri o meno per usarla come spunto per una futura conversazione."
        },
        ConfirmClearAll: "Confermi la cancellazione di tutti i dati della chat e delle impostazioni?"
    },
    Copy: {
        Success: "Copiato sugli appunti",
        Failed: "Copia fallita, concedere l'autorizzazione all'accesso agli appunti"
    },
    Context: {
        Toast: (x)=>`Con ${x} prompts contestuali`,
        Edit: "Prompt contestuali e di memoria",
        Add: "Aggiungi altro"
    }
};
/* harmony default export */ const locales_it = (it);

;// CONCATENATED MODULE: ./app/locales/tr.ts

const tr = {
    WIP: "\xc7alışma devam ediyor...",
    Error: {
        Unauthorized: "Yetkisiz erişim, l\xfctfen erişim kodunu ayarlar sayfasından giriniz."
    },
    ChatItem: {
        ChatItemCount: (count)=>`${count} mesaj`
    },
    Chat: {
        SubTitle: (count)=>`高济AI tarafından ${count} mesaj`,
        Actions: {
            ChatList: "Sohbet Listesine Git",
            CompressedHistory: "Sıkıştırılmış Ge\xe7miş Bellek Komutu",
            Export: "T\xfcm Mesajları Markdown Olarak Dışa Aktar",
            Copy: "Kopyala",
            Stop: "Durdur",
            Retry: "Tekrar Dene",
            Delete: "Delete"
        },
        Rename: "Sohbeti Yeniden Adlandır",
        Typing: "Yazıyor…",
        Input: (submitKey)=>{
            var inputHints = `Göndermek için ${submitKey}`;
            if (submitKey === String(config/* SubmitKey.Enter */.mQ.Enter)) {
                inputHints += ", kaydırmak i\xe7in Shift + Enter";
            }
            return inputHints + ", komutları aramak i\xe7in / (eğik \xe7izgi)";
        },
        Send: "G\xf6nder"
    },
    Export: {
        Title: "T\xfcm Mesajlar",
        Copy: "T\xfcm\xfcn\xfc Kopyala",
        Download: "İndir",
        MessageFromYou: "Sizin Mesajınız",
        MessageFromChatGPT: "高济AI'nin Mesajı"
    },
    Memory: {
        Title: "Bellek Komutları",
        EmptyContent: "Hen\xfcz değil.",
        Send: "Belleği G\xf6nder",
        Copy: "Belleği Kopyala",
        Reset: "Oturumu Sıfırla",
        ResetConfirm: "Sıfırlama, ge\xe7erli g\xf6r\xfcşme ge\xe7mişini ve ge\xe7miş belleği siler. Sıfırlamak istediğinizden emin misiniz?"
    },
    Home: {
        NewChat: "Yeni Sohbet",
        DeleteChat: "Se\xe7ili sohbeti silmeyi onaylıyor musunuz?",
        DeleteToast: "Sohbet Silindi",
        Revert: "Geri Al"
    },
    Settings: {
        Title: "Ayarlar",
        SubTitle: "T\xfcm Ayarlar",
        Actions: {
            ClearAll: "T\xfcm Verileri Temizle",
            ResetAll: "T\xfcm Ayarları Sıfırla",
            Close: "Kapat",
            ConfirmResetAll: {
                Confirm: "T\xfcm ayarları sıfırlamak istediğinizden emin misiniz?"
            },
            ConfirmClearAll: {
                Confirm: "T\xfcm sohbeti sıfırlamak istediğinizden emin misiniz?"
            }
        },
        Lang: {
            Name: "Language",
            Options: {
                cn: "简体中文",
                en: "English",
                tw: "繁體中文",
                es: "Espa\xf1ol",
                it: "Italiano",
                tr: "T\xfcrk\xe7e",
                jp: "日本語",
                de: "Deutsch"
            }
        },
        Avatar: "Avatar",
        FontSize: {
            Title: "Yazı Boyutu",
            SubTitle: "Sohbet i\xe7eriğinin yazı boyutunu ayarlayın"
        },
        Update: {
            Version: (x)=>`Sürüm: ${x}`,
            IsLatest: "En son s\xfcr\xfcm",
            CheckUpdate: "G\xfcncellemeyi Kontrol Et",
            IsChecking: "G\xfcncelleme kontrol ediliyor...",
            FoundUpdate: (x)=>`Yeni sürüm bulundu: ${x}`,
            GoToUpdate: "G\xfcncelle"
        },
        SendKey: "G\xf6nder Tuşu",
        Theme: "Tema",
        TightBorder: "Tam Ekran",
        SendPreviewBubble: "Mesaj \xd6nizleme Balonu",
        Prompt: {
            Disable: {
                Title: "Otomatik tamamlamayı devre dışı bırak",
                SubTitle: "Otomatik tamamlamayı kullanmak i\xe7in / (eğik \xe7izgi) girin"
            },
            List: "Komut Listesi",
            ListCount: (builtin, custom)=>`${builtin} yerleşik, ${custom} kullanıcı tanımlı`,
            Edit: "D\xfczenle",
            Modal: {
                Title: "Prompt List",
                Add: "Add One",
                Search: "Search Prompts"
            }
        },
        HistoryCount: {
            Title: "Ekli Mesaj Sayısı",
            SubTitle: "İstek başına ekli g\xf6nderilen mesaj sayısı"
        },
        CompressThreshold: {
            Title: "Ge\xe7miş Sıkıştırma Eşiği",
            SubTitle: "Sıkıştırılmamış mesajların uzunluğu bu değeri aşarsa sıkıştırılır"
        },
        Token: {
            Title: "API Anahtarı",
            SubTitle: "Erişim kodu sınırını yoksaymak i\xe7in anahtarınızı kullanın",
            Placeholder: "OpenAI API Anahtarı"
        },
        Usage: {
            Title: "Hesap Bakiyesi",
            SubTitle (used, total) {
                return `Bu ay kullanılan $${used}, abonelik $${total}`;
            },
            IsChecking: "Kontrol ediliyor...",
            Check: "Tekrar Kontrol Et",
            NoAccess: "Bakiyeyi kontrol etmek i\xe7in API anahtarını girin"
        },
        AccessCode: {
            Title: "Erişim Kodu",
            SubTitle: "Erişim kontrol\xfc etkinleştirme",
            Placeholder: "Erişim Kodu Gerekiyor"
        },
        Model: "Model",
        Temperature: {
            Title: "Ger\xe7eklik",
            SubTitle: "Daha b\xfcy\xfck bir değer girildiğinde ger\xe7eklik oranı d\xfcşer ve daha rastgele \xe7ıktılar \xfcretir"
        },
        MaxTokens: {
            Title: "Maksimum Belirte\xe7",
            SubTitle: "Girdi belirte\xe7lerinin ve oluşturulan belirte\xe7lerin maksimum uzunluğu"
        },
        PresencePenlty: {
            Title: "Varlık Cezası",
            SubTitle: "Daha b\xfcy\xfck bir değer, yeni konular hakkında konuşma olasılığını artırır"
        }
    },
    Store: {
        DefaultTopic: "Yeni Konuşma",
        BotHello: "Merhaba! Size bug\xfcn nasıl yardımcı olabilirim?",
        Error: "Bir şeyler yanlış gitti. L\xfctfen daha sonra tekrar deneyiniz.",
        Prompt: {
            History: (content)=>"Bu, yapay zeka ile kullanıcı arasındaki sohbet ge\xe7mişinin bir \xf6zetidir: " + content,
            Topic: "L\xfctfen herhangi bir giriş, noktalama işareti, tırnak işareti, nokta, sembol veya ek metin olmadan konuşmamızı \xf6zetleyen d\xf6rt ila beş kelimelik bir başlık oluşturun. \xc7evreleyen tırnak işaretlerini kaldırın.",
            Summarize: "Gelecekteki bağlam i\xe7in bir bilgi istemi olarak kullanmak \xfczere tartışmamızı en fazla 200 kelimeyle \xf6zetleyin."
        },
        ConfirmClearAll: "T\xfcm sohbet ve ayar verilerini temizlemeyi onaylıyor musunuz?"
    },
    Copy: {
        Success: "Panoya kopyalandı",
        Failed: "Kopyalama başarısız oldu, l\xfctfen panoya erişim izni verin"
    },
    Context: {
        Toast: (x)=>`${x} bağlamsal bellek komutu`,
        Edit: "Bağlamsal ve Bellek Komutları",
        Add: "Yeni Ekle"
    }
};
/* harmony default export */ const locales_tr = (tr);

;// CONCATENATED MODULE: ./app/locales/jp.ts

const jp = {
    WIP: "この機能は開発中です……",
    Error: {
        Unauthorized: "現在は未承認状態です。左下の設定ボタンをクリックし、アクセスパスワードを入力してください。"
    },
    ChatItem: {
        ChatItemCount: (count)=>`${count} 通のチャット`
    },
    Chat: {
        SubTitle: (count)=>`高济AIとの ${count} 通のチャット`,
        Actions: {
            ChatList: "メッセージリストを表示",
            CompressedHistory: "圧縮された履歴プロンプトを表示",
            Export: "チャット履歴をエクスポート",
            Copy: "コピー",
            Stop: "停止",
            Retry: "リトライ",
            Delete: "Delete"
        },
        Rename: "チャットの名前を変更",
        Typing: "入力中…",
        Input: (submitKey)=>{
            var inputHints = `${submitKey} で送信`;
            if (submitKey === String(config/* SubmitKey.Enter */.mQ.Enter)) {
                inputHints += "，Shift + Enter で改行";
            }
            return inputHints + "，/ で自動補完をトリガー";
        },
        Send: "送信"
    },
    Export: {
        Title: "チャット履歴をMarkdown形式でエクスポート",
        Copy: "すべてコピー",
        Download: "ファイルをダウンロード",
        MessageFromYou: "あなたからのメッセージ",
        MessageFromChatGPT: "高济AIからのメッセージ"
    },
    Memory: {
        Title: "履歴メモリ",
        EmptyContent: "まだ記憶されていません",
        Send: "メモリを送信",
        Copy: "メモリをコピー",
        Reset: "チャットをリセット",
        ResetConfirm: "リセット後、現在のチャット履歴と過去のメモリがクリアされます。リセットしてもよろしいですか？"
    },
    Home: {
        NewChat: "新しいチャット",
        DeleteChat: "選択したチャットを削除してもよろしいですか？",
        DeleteToast: "チャットが削除されました",
        Revert: "元に戻す"
    },
    Settings: {
        Title: "設定",
        SubTitle: "設定オプション",
        Actions: {
            ClearAll: "すべてのデータをクリア",
            ResetAll: "すべてのオプションをリセット",
            Close: "閉じる",
            ConfirmResetAll: {
                Confirm: "すべての設定をリセットしてもよろしいですか？"
            },
            ConfirmClearAll: {
                Confirm: "すべてのチャットをリセットしてもよろしいですか？"
            }
        },
        Lang: {
            Name: "Language",
            Options: {
                cn: "简体中文",
                en: "English",
                tw: "繁體中文",
                es: "Espa\xf1ol",
                it: "Italiano",
                tr: "T\xfcrk\xe7e",
                jp: "日本語",
                de: "Deutsch"
            }
        },
        Avatar: "アバター",
        FontSize: {
            Title: "フォントサイズ",
            SubTitle: "チャット内容のフォントサイズ"
        },
        Update: {
            Version: (x)=>`現在のバージョン：${x}`,
            IsLatest: "最新バージョンです",
            CheckUpdate: "アップデートを確認",
            IsChecking: "アップデートを確認しています...",
            FoundUpdate: (x)=>`新しいバージョンが見つかりました：${x}`,
            GoToUpdate: "更新する"
        },
        SendKey: "送信キー",
        Theme: "テーマ",
        TightBorder: "ボーダーレスモード",
        SendPreviewBubble: "プレビューバブルの送信",
        Prompt: {
            Disable: {
                Title: "プロンプトの自動補完を無効にする",
                SubTitle: "入力フィールドの先頭に / を入力すると、自動補完がトリガーされます。"
            },
            List: "カスタムプロンプトリスト",
            ListCount: (builtin, custom)=>`組み込み ${builtin} 件、ユーザー定義 ${custom} 件`,
            Edit: "編集",
            Modal: {
                Title: "プロンプトリスト",
                Add: "新規追加",
                Search: "プロンプトワード検索"
            }
        },
        HistoryCount: {
            Title: "履歴メッセージ数を添付",
            SubTitle: "リクエストごとに添付する履歴メッセージ数"
        },
        CompressThreshold: {
            Title: "履歴メッセージの長さ圧縮しきい値",
            SubTitle: "圧縮されていない履歴メッセージがこの値を超えた場合、圧縮が行われます。"
        },
        Token: {
            Title: "APIキー",
            SubTitle: "自分のキーを使用してパスワードアクセス制限を迂回する",
            Placeholder: "OpenAI APIキー"
        },
        Usage: {
            Title: "残高照会",
            SubTitle (used, total) {
                return `今月は $${used} を使用しました。総額は $${total} です。`;
            },
            IsChecking: "確認中...",
            Check: "再確認",
            NoAccess: "APIキーまたはアクセスパスワードを入力して残高を表示"
        },
        AccessCode: {
            Title: "アクセスパスワード",
            SubTitle: "暗号化アクセスが有効になっています",
            Placeholder: "アクセスパスワードを入力してください"
        },
        Model: "モデル (model)",
        Temperature: {
            Title: "ランダム性 (temperature)",
            SubTitle: "値が大きいほど、回答がランダムになります。1以上の値には文字化けが含まれる可能性があります。"
        },
        MaxTokens: {
            Title: "シングルレスポンス制限 (max_tokens)",
            SubTitle: "1回のインタラクションで使用される最大トークン数"
        },
        PresencePenlty: {
            Title: "トピックの新鮮度 (presence_penalty)",
            SubTitle: "値が大きいほど、新しいトピックへの展開が可能になります。"
        }
    },
    Store: {
        DefaultTopic: "新しいチャット",
        BotHello: "何かお手伝いできることはありますか",
        Error: "エラーが発生しました。しばらくしてからやり直してください。",
        Prompt: {
            History: (content)=>"これは、AI とユーザの過去のチャットを要約した前提となるストーリーです：" + content,
            Topic: "4～5文字でこの文章の簡潔な主題を返してください。説明、句読点、感嘆詞、余分なテキストは無しで。もし主題がない場合は、「おしゃべり」を返してください",
            Summarize: "あなたとユーザの会話を簡潔にまとめて、後続のコンテキストプロンプトとして使ってください。200字以内に抑えてください。"
        },
        ConfirmClearAll: "すべてのチャット、設定データをクリアしてもよろしいですか？"
    },
    Copy: {
        Success: "クリップボードに書き込みました",
        Failed: "コピーに失敗しました。クリップボード許可を与えてください。"
    },
    Context: {
        Toast: (x)=>`前置コンテキストが ${x} 件設定されました`,
        Edit: "前置コンテキストと履歴メモリ",
        Add: "新規追加"
    }
};
/* harmony default export */ const locales_jp = (jp);

;// CONCATENATED MODULE: ./app/locales/de.ts

const de = {
    WIP: "In Bearbeitung...",
    Error: {
        Unauthorized: "Unbefugter Zugriff, bitte geben Sie den Zugangscode auf der Einstellungsseite ein."
    },
    ChatItem: {
        ChatItemCount: (count)=>`${count} Nachrichten`
    },
    Chat: {
        SubTitle: (count)=>`${count} Nachrichten mit 高济AI`,
        Actions: {
            ChatList: "Zur Chat-Liste gehen",
            CompressedHistory: "Komprimierter Ged\xe4chtnis-Prompt",
            Export: "Alle Nachrichten als Markdown exportieren",
            Copy: "Kopieren",
            Stop: "Stop",
            Retry: "Wiederholen",
            Delete: "Delete"
        },
        Rename: "Chat umbenennen",
        Typing: "Tippen...",
        Input: (submitKey)=>{
            var inputHints = `${submitKey} um zu Senden`;
            if (submitKey === String(config/* SubmitKey.Enter */.mQ.Enter)) {
                inputHints += ", Umschalt + Eingabe f\xfcr Zeilenumbruch";
            }
            return inputHints + ", / zum Durchsuchen von Prompts";
        },
        Send: "Senden"
    },
    Export: {
        Title: "Alle Nachrichten",
        Copy: "Alles kopieren",
        Download: "Herunterladen",
        MessageFromYou: "Deine Nachricht",
        MessageFromChatGPT: "Nachricht von 高济AI"
    },
    Memory: {
        Title: "Ged\xe4chtnis-Prompt",
        EmptyContent: "Noch nichts.",
        Send: "Ged\xe4chtnis senden",
        Copy: "Ged\xe4chtnis kopieren",
        Reset: "Sitzung zur\xfccksetzen",
        ResetConfirm: "Das Zur\xfccksetzen l\xf6scht den aktuellen Gespr\xe4chsverlauf und das Langzeit-Ged\xe4chtnis. M\xf6chten Sie wirklich zur\xfccksetzen?"
    },
    Home: {
        NewChat: "Neuer Chat",
        DeleteChat: "Best\xe4tigen Sie, um das ausgew\xe4hlte Gespr\xe4ch zu l\xf6schen?",
        DeleteToast: "Chat gel\xf6scht",
        Revert: "Zur\xfccksetzen"
    },
    Settings: {
        Title: "Einstellungen",
        SubTitle: "Alle Einstellungen",
        Actions: {
            ClearAll: "Alle Daten l\xf6schen",
            ResetAll: "Alle Einstellungen zur\xfccksetzen",
            Close: "Schlie\xdfen",
            ConfirmResetAll: {
                Confirm: "M\xf6chten Sie wirklich alle Konfigurationen zur\xfccksetzen?"
            },
            ConfirmClearAll: {
                Confirm: "M\xf6chten Sie wirklich alle Chats zur\xfccksetzen?"
            }
        },
        Lang: {
            Name: "Language",
            Options: {
                cn: "简体中文",
                en: "English",
                tw: "繁體中文",
                es: "Espa\xf1ol",
                it: "Italiano",
                tr: "T\xfcrk\xe7e",
                jp: "日本語",
                de: "Deutsch"
            }
        },
        Avatar: "Avatar",
        FontSize: {
            Title: "Schriftgr\xf6\xdfe",
            SubTitle: "Schriftgr\xf6\xdfe des Chat-Inhalts anpassen"
        },
        Update: {
            Version: (x)=>`Version: ${x}`,
            IsLatest: "Neueste Version",
            CheckUpdate: "Update pr\xfcfen",
            IsChecking: "Update wird gepr\xfcft...",
            FoundUpdate: (x)=>`Neue Version gefunden: ${x}`,
            GoToUpdate: "Aktualisieren"
        },
        SendKey: "Senden-Taste",
        Theme: "Erscheinungsbild",
        TightBorder: "Enger Rahmen",
        SendPreviewBubble: "Vorschau-Bubble senden",
        Prompt: {
            Disable: {
                Title: "Autovervollst\xe4ndigung deaktivieren",
                SubTitle: "Autovervollst\xe4ndigung mit / starten"
            },
            List: "Prompt-Liste",
            ListCount: (builtin, custom)=>`${builtin} integriert, ${custom} benutzerdefiniert`,
            Edit: "Bearbeiten",
            Modal: {
                Title: "Prompt List",
                Add: "Add One",
                Search: "Search Prompts"
            }
        },
        HistoryCount: {
            Title: "Anzahl der angeh\xe4ngten Nachrichten",
            SubTitle: "Anzahl der pro Anfrage angeh\xe4ngten gesendeten Nachrichten"
        },
        CompressThreshold: {
            Title: "Schwellenwert f\xfcr Verlaufskomprimierung",
            SubTitle: "Komprimierung, wenn die L\xe4nge der unkomprimierten Nachrichten den Wert \xfcberschreitet"
        },
        Token: {
            Title: "API-Schl\xfcssel",
            SubTitle: "Verwenden Sie Ihren Schl\xfcssel, um das Zugangscode-Limit zu ignorieren",
            Placeholder: "OpenAI API-Schl\xfcssel"
        },
        Usage: {
            Title: "Kontostand",
            SubTitle (used, total) {
                return `Diesen Monat ausgegeben $${used}, Abonnement $${total}`;
            },
            IsChecking: "Wird \xfcberpr\xfcft...",
            Check: "Erneut pr\xfcfen",
            NoAccess: "API-Schl\xfcssel eingeben, um den Kontostand zu \xfcberpr\xfcfen"
        },
        AccessCode: {
            Title: "Zugangscode",
            SubTitle: "Zugangskontrolle aktiviert",
            Placeholder: "Zugangscode erforderlich"
        },
        Model: "Modell",
        Temperature: {
            Title: "Temperature",
            SubTitle: "Ein gr\xf6\xdferer Wert f\xfchrt zu zuf\xe4lligeren Antworten"
        },
        MaxTokens: {
            Title: "Max Tokens",
            SubTitle: "Maximale Anzahl der Anfrage- plus Antwort-Token"
        },
        PresencePenlty: {
            Title: "Presence Penalty",
            SubTitle: "Ein gr\xf6\xdferer Wert erh\xf6ht die Wahrscheinlichkeit, dass \xfcber neue Themen gesprochen wird"
        }
    },
    Store: {
        DefaultTopic: "Neues Gespr\xe4ch",
        BotHello: "Hallo! Wie kann ich Ihnen heute helfen?",
        Error: "Etwas ist schief gelaufen, bitte versuchen Sie es sp\xe4ter noch einmal.",
        Prompt: {
            History: (content)=>"Dies ist eine Zusammenfassung des Chatverlaufs zwischen dem KI und dem Benutzer als R\xfcckblick: " + content,
            Topic: "Bitte erstellen Sie einen vier- bis f\xfcnfw\xf6rtigen Titel, der unser Gespr\xe4ch zusammenfasst, ohne Einleitung, Zeichensetzung, Anf\xfchrungszeichen, Punkte, Symbole oder zus\xe4tzlichen Text. Entfernen Sie Anf\xfchrungszeichen.",
            Summarize: "Fassen Sie unsere Diskussion kurz in 200 W\xf6rtern oder weniger zusammen, um sie als Pronpt f\xfcr zuk\xfcnftige Gespr\xe4che zu verwenden."
        },
        ConfirmClearAll: "Best\xe4tigen Sie, um alle Chat- und Einstellungsdaten zu l\xf6schen?"
    },
    Copy: {
        Success: "In die Zwischenablage kopiert",
        Failed: "Kopieren fehlgeschlagen, bitte geben Sie die Berechtigung zum Zugriff auf die Zwischenablage frei"
    },
    Context: {
        Toast: (x)=>`Mit ${x} Kontext-Prompts`,
        Edit: "Kontext- und Ged\xe4chtnis-Prompts",
        Add: "Hinzuf\xfcgen"
    }
};
/* harmony default export */ const locales_de = (de);

;// CONCATENATED MODULE: ./app/locales/index.ts








const AllLangs = [
    "en",
    "cn",
    "tw",
    "es",
    "it",
    "tr",
    "jp",
    "de"
];
const LANG_KEY = "lang";
function getItem(key) {
    try {
        return localStorage.getItem(key);
    } catch  {
        return null;
    }
}
function setItem(key, value) {
    try {
        localStorage.setItem(key, value);
    } catch  {}
}
function getLanguage() {
    try {
        return navigator.language.toLowerCase();
    } catch  {
        return "cn";
    }
}
function getLang() {
    const savedLang = getItem(LANG_KEY);
    if (AllLangs.includes(savedLang ?? "")) {
        return savedLang;
    }
    const lang = getLanguage();
    for (const option of AllLangs){
        if (lang.includes(option)) {
            return option;
        }
    }
    return "en";
}
function changeLang(lang) {
    setItem(LANG_KEY, lang);
    location.reload();
}
/* harmony default export */ const locales = (({
    en: locales_en,
    cn: locales_cn,
    tw: locales_tw,
    es: locales_es,
    it: locales_it,
    tr: locales_tr,
    jp: locales_jp,
    de: locales_de
})[getLang()]);


/***/ }),

/***/ 1682:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
if (!Array.prototype.at) {
    Array.prototype.at = function(index) {
        // Get the length of the array
        const length = this.length;
        // Convert negative index to a positive index
        if (index < 0) {
            index = length + index;
        }
        // Return undefined if the index is out of range
        if (index < 0 || index >= length) {
            return undefined;
        }
        // Use Array.prototype.slice method to get value at the specified index
        return Array.prototype.slice.call(this, index, index + 1)[0];
    };
}



/***/ }),

/***/ 6561:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "b6": () => (/* binding */ requestUsage),
/* harmony export */   "qd": () => (/* binding */ requestWithPrompt),
/* harmony export */   "u4": () => (/* binding */ ControllerPool),
/* harmony export */   "yY": () => (/* binding */ requestChatStream)
/* harmony export */ });
/* unused harmony exports requestOpenaiClient, requestChat */
/* harmony import */ var _store__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1209);
/* harmony import */ var _components_ui_lib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2634);


const TIME_OUT_MS = 60000;
const makeRequestParam = (messages, options)=>{
    let sendMessages = messages.map((v)=>({
            role: v.role,
            content: v.content
        }));
    if (options?.filterBot) {
        sendMessages = sendMessages.filter((m)=>m.role !== "assistant");
    }
    const modelConfig = {
        ..._store__WEBPACK_IMPORTED_MODULE_0__/* .useAppConfig.getState */ .MG.getState().modelConfig
    };
    // @yidadaa: wont send max_tokens, because it is nonsense for Muggles
    // @ts-expect-error
    delete modelConfig.max_tokens;
    // override model config
    if (options?.model) {
        modelConfig.model = options.model;
    }
    return {
        messages: sendMessages,
        stream: options?.stream,
        ...modelConfig
    };
};
function getHeaders() {
    const accessStore = _store__WEBPACK_IMPORTED_MODULE_0__/* .useAccessStore.getState */ ._X.getState();
    let headers = {};
    if (accessStore.enabledAccessControl()) {
        headers["access-code"] = accessStore.accessCode;
    }
    if (accessStore.token && accessStore.token.length > 0) {
        headers["token"] = accessStore.token;
    }
    return headers;
}
function requestOpenaiClient(path) {
    return (body, method = "POST")=>fetch("/api/openai", {
            method,
            headers: {
                "Content-Type": "application/json",
                path,
                ...getHeaders()
            },
            body: body && JSON.stringify(body)
        });
}
async function requestChat(messages, options) {
    const req = makeRequestParam(messages, {
        filterBot: true,
        model: options?.model
    });
    const res = await requestOpenaiClient("v1/chat/completions")(req);
    try {
        const response = await res.json();
        return response;
    } catch (error) {
        console.error("[Request Chat] ", error, res.body);
    }
}
async function requestUsage() {
    const formatDate = (d)=>`${d.getFullYear()}-${(d.getMonth() + 1).toString().padStart(2, "0")}-${d.getDate().toString().padStart(2, "0")}`;
    const ONE_DAY = 2 * 24 * 60 * 60 * 1000;
    const now = new Date(Date.now() + ONE_DAY);
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
    const startDate = formatDate(startOfMonth);
    const endDate = formatDate(now);
    const [used, subs] = await Promise.all([
        requestOpenaiClient(`dashboard/billing/usage?start_date=${startDate}&end_date=${endDate}`)(null, "GET"),
        requestOpenaiClient("dashboard/billing/subscription")(null, "GET")
    ]);
    const response = await used.json();
    const total = await subs.json();
    if (response.error && response.error.type) {
        (0,_components_ui_lib__WEBPACK_IMPORTED_MODULE_1__/* .showToast */ .CF)(response.error.message);
        return;
    }
    if (response.total_usage) {
        response.total_usage = Math.round(response.total_usage) / 100;
    }
    if (total.hard_limit_usd) {
        total.hard_limit_usd = Math.round(total.hard_limit_usd * 100) / 100;
    }
    return {
        used: response.total_usage,
        subscription: total.hard_limit_usd
    };
}
async function requestChatStream(messages, options) {
    const req = makeRequestParam(messages, {
        stream: true,
        filterBot: options?.filterBot,
        model: options?.model
    });
    console.log("[Request] ", req);
    const controller = new AbortController();
    const reqTimeoutId = setTimeout(()=>controller.abort(), TIME_OUT_MS);
    try {
        const res = await fetch("/api/chat-stream", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                path: "v1/chat/completions",
                ...getHeaders()
            },
            body: JSON.stringify(req),
            signal: controller.signal
        });
        clearTimeout(reqTimeoutId);
        let responseText = "";
        const finish = ()=>{
            options?.onMessage(responseText, true);
            controller.abort();
        };
        if (res.ok) {
            const reader = res.body?.getReader();
            const decoder = new TextDecoder();
            options?.onController?.(controller);
            while(true){
                const resTimeoutId = setTimeout(()=>finish(), TIME_OUT_MS);
                const content = await reader?.read();
                clearTimeout(resTimeoutId);
                if (!content || !content.value) {
                    break;
                }
                const text = decoder.decode(content.value, {
                    stream: true
                });
                responseText += text;
                const done = content.done;
                options?.onMessage(responseText, false);
                if (done) {
                    break;
                }
            }
            finish();
        } else if (res.status === 401) {
            console.error("Unauthorized");
            options?.onError(new Error("Unauthorized"), res.status);
        } else {
            console.error("Stream Error", res.body);
            options?.onError(new Error("Stream Error"), res.status);
        }
    } catch (err) {
        console.error("NetWork Error", err);
        options?.onError(err);
    }
}
async function requestWithPrompt(messages, prompt, options) {
    messages = messages.concat([
        {
            role: "user",
            content: prompt,
            date: new Date().toLocaleString()
        }
    ]);
    const res = await requestChat(messages, options);
    return res?.choices?.at(0)?.message?.content ?? "";
}
// To store message streaming controller
const ControllerPool = {
    controllers: {},
    addController (sessionIndex, messageId, controller) {
        const key = this.key(sessionIndex, messageId);
        this.controllers[key] = controller;
        return key;
    },
    stop (sessionIndex, messageId) {
        const key = this.key(sessionIndex, messageId);
        const controller = this.controllers[key];
        controller?.abort();
    },
    stopAll () {
        Object.values(this.controllers).forEach((v)=>v.abort());
    },
    hasPending () {
        return Object.values(this.controllers).length > 0;
    },
    remove (sessionIndex, messageId) {
        const key = this.key(sessionIndex, messageId);
        delete this.controllers[key];
    },
    key (sessionIndex, messageIndex) {
        return `${sessionIndex},${messageIndex}`;
    }
};


/***/ }),

/***/ 293:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "L": () => (/* binding */ ALL_MODELS),
/* harmony export */   "MG": () => (/* binding */ useAppConfig),
/* harmony export */   "Q2": () => (/* binding */ Theme),
/* harmony export */   "Xm": () => (/* binding */ ModalConfigValidator),
/* harmony export */   "mQ": () => (/* binding */ SubmitKey)
/* harmony export */ });
/* unused harmony exports limitNumber, limitModel */
/* harmony import */ var zustand__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3998);
/* harmony import */ var zustand_middleware__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8658);


var SubmitKey;
(function(SubmitKey) {
    SubmitKey["Enter"] = "Enter";
    SubmitKey["CtrlEnter"] = "Ctrl + Enter";
    SubmitKey["ShiftEnter"] = "Shift + Enter";
    SubmitKey["AltEnter"] = "Alt + Enter";
    SubmitKey["MetaEnter"] = "Meta + Enter";
})(SubmitKey || (SubmitKey = {}));
var Theme;
(function(Theme) {
    Theme["Auto"] = "auto";
    Theme["Dark"] = "dark";
    Theme["Light"] = "light";
})(Theme || (Theme = {}));
const DEFAULT_CONFIG = {
    historyMessageCount: 4,
    compressMessageLengthThreshold: 1000,
    sendBotMessages: true,
    submitKey: SubmitKey.CtrlEnter,
    avatar: "1f603",
    fontSize: 14,
    theme: Theme.Auto,
    tightBorder: false,
    sendPreviewBubble: true,
    sidebarWidth: 300,
    disablePromptHint: false,
    modelConfig: {
        model: "gpt-3.5-turbo",
        temperature: 1,
        max_tokens: 2000,
        presence_penalty: 0
    }
};
const ENABLE_GPT4 = true;
const ALL_MODELS = [
    {
        name: "gpt-4",
        available: ENABLE_GPT4
    },
    {
        name: "gpt-4-0314",
        available: ENABLE_GPT4
    },
    {
        name: "gpt-4-32k",
        available: ENABLE_GPT4
    },
    {
        name: "gpt-4-32k-0314",
        available: ENABLE_GPT4
    },
    {
        name: "gpt-3.5-turbo",
        available: true
    },
    {
        name: "gpt-3.5-turbo-0301",
        available: true
    }
];
function limitNumber(x, min, max, defaultValue) {
    if (typeof x !== "number" || isNaN(x)) {
        return defaultValue;
    }
    return Math.min(max, Math.max(min, x));
}
function limitModel(name) {
    return ALL_MODELS.some((m)=>m.name === name && m.available) ? name : ALL_MODELS[4].name;
}
const ModalConfigValidator = {
    model (x) {
        return limitModel(x);
    },
    max_tokens (x) {
        return limitNumber(x, 0, 32000, 2000);
    },
    presence_penalty (x) {
        return limitNumber(x, -2, 2, 0);
    },
    temperature (x) {
        return limitNumber(x, 0, 2, 1);
    }
};
const CONFIG_KEY = "app-config";
const useAppConfig = (0,zustand__WEBPACK_IMPORTED_MODULE_0__/* .create */ .Ue)()((0,zustand_middleware__WEBPACK_IMPORTED_MODULE_1__/* .persist */ .tJ)((set, get)=>({
        ...DEFAULT_CONFIG,
        reset () {
            set(()=>({
                    ...DEFAULT_CONFIG
                }));
        },
        update (updater) {
            const config = {
                ...get()
            };
            updater(config);
            set(()=>config);
        }
    }), {
    name: CONFIG_KEY
}));


/***/ }),

/***/ 1209:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "L": () => (/* reexport */ store_config/* ALL_MODELS */.L),
  "ux": () => (/* reexport */ BOT_HELLO),
  "Xm": () => (/* reexport */ store_config/* ModalConfigValidator */.Xm),
  "K$": () => (/* reexport */ ROLES),
  "mQ": () => (/* reexport */ store_config/* SubmitKey */.mQ),
  "Q2": () => (/* reexport */ store_config/* Theme */.Q2),
  "tn": () => (/* reexport */ createMessage),
  "_X": () => (/* reexport */ useAccessStore),
  "MG": () => (/* reexport */ store_config/* useAppConfig */.MG),
  "aK": () => (/* reexport */ useChatStore),
  "u2": () => (/* reexport */ useUpdateStore)
});

// UNUSED EXPORTS: ACCESS_KEY, UPDATE_KEY, limitModel, limitNumber

// EXTERNAL MODULE: ./node_modules/zustand/esm/index.mjs + 1 modules
var esm = __webpack_require__(3998);
// EXTERNAL MODULE: ./node_modules/zustand/esm/middleware.mjs
var middleware = __webpack_require__(8658);
// EXTERNAL MODULE: ./app/requests.ts
var requests = __webpack_require__(6561);
// EXTERNAL MODULE: ./app/utils.ts
var utils = __webpack_require__(6433);
// EXTERNAL MODULE: ./app/locales/index.ts + 8 modules
var locales = __webpack_require__(1452);
// EXTERNAL MODULE: ./app/components/ui-lib.tsx + 1 modules
var ui_lib = __webpack_require__(2634);
// EXTERNAL MODULE: ./app/store/config.ts
var store_config = __webpack_require__(293);
;// CONCATENATED MODULE: ./app/store/app.ts







function createMessage(override) {
    return {
        id: Date.now(),
        date: new Date().toLocaleString(),
        role: "user",
        content: "",
        ...override
    };
}
const ROLES = [
    "system",
    "user",
    "assistant"
];
const DEFAULT_TOPIC = locales/* default.Store.DefaultTopic */.ZP.Store.DefaultTopic;
const BOT_HELLO = createMessage({
    role: "assistant",
    content: locales/* default.Store.BotHello */.ZP.Store.BotHello
});
function createEmptySession() {
    const createDate = new Date().toLocaleString();
    return {
        id: Date.now(),
        topic: DEFAULT_TOPIC,
        sendMemory: true,
        memoryPrompt: "",
        context: [],
        messages: [],
        stat: {
            tokenCount: 0,
            wordCount: 0,
            charCount: 0
        },
        lastUpdate: createDate,
        lastSummarizeIndex: 0
    };
}
function countMessages(msgs) {
    return msgs.reduce((pre, cur)=>pre + cur.content.length, 0);
}
const LOCAL_KEY = "chat-next-web-store";
const useChatStore = (0,esm/* create */.Ue)()((0,middleware/* persist */.tJ)((set, get)=>({
        sessions: [
            createEmptySession()
        ],
        currentSessionIndex: 0,
        clearSessions () {
            set(()=>({
                    sessions: [
                        createEmptySession()
                    ],
                    currentSessionIndex: 0
                }));
        },
        selectSession (index) {
            set({
                currentSessionIndex: index
            });
        },
        removeSession (index) {
            set((state)=>{
                let nextIndex = state.currentSessionIndex;
                const sessions = state.sessions;
                if (sessions.length === 1) {
                    return {
                        currentSessionIndex: 0,
                        sessions: [
                            createEmptySession()
                        ]
                    };
                }
                sessions.splice(index, 1);
                if (nextIndex === index) {
                    nextIndex -= 1;
                }
                return {
                    currentSessionIndex: nextIndex,
                    sessions
                };
            });
        },
        moveSession (from, to) {
            set((state)=>{
                const { sessions , currentSessionIndex: oldIndex  } = state;
                // move the session
                const newSessions = [
                    ...sessions
                ];
                const session = newSessions[from];
                newSessions.splice(from, 1);
                newSessions.splice(to, 0, session);
                // modify current session id
                let newIndex = oldIndex === from ? to : oldIndex;
                if (oldIndex > from && oldIndex <= to) {
                    newIndex -= 1;
                } else if (oldIndex < from && oldIndex >= to) {
                    newIndex += 1;
                }
                return {
                    currentSessionIndex: newIndex,
                    sessions: newSessions
                };
            });
        },
        newSession () {
            set((state)=>({
                    currentSessionIndex: 0,
                    sessions: [
                        createEmptySession()
                    ].concat(state.sessions)
                }));
        },
        deleteSession (i) {
            const deletedSession = get().currentSession();
            const index = i ?? get().currentSessionIndex;
            const isLastSession = get().sessions.length === 1;
            if (!(0,utils/* isMobileScreen */.Av)() || confirm(locales/* default.Home.DeleteChat */.ZP.Home.DeleteChat)) {
                get().removeSession(index);
                (0,ui_lib/* showToast */.CF)(locales/* default.Home.DeleteToast */.ZP.Home.DeleteToast, {
                    text: locales/* default.Home.Revert */.ZP.Home.Revert,
                    onClick () {
                        set((state)=>({
                                sessions: state.sessions.slice(0, index).concat([
                                    deletedSession
                                ]).concat(state.sessions.slice(index + Number(isLastSession)))
                            }));
                    }
                }, 5000);
            }
        },
        currentSession () {
            let index = get().currentSessionIndex;
            const sessions = get().sessions;
            if (index < 0 || index >= sessions.length) {
                index = Math.min(sessions.length - 1, Math.max(0, index));
                set(()=>({
                        currentSessionIndex: index
                    }));
            }
            const session = sessions[index];
            return session;
        },
        onNewMessage (message) {
            get().updateCurrentSession((session)=>{
                session.lastUpdate = new Date().toLocaleString();
            });
            get().updateStat(message);
            get().summarizeSession();
        },
        async onUserInput (content) {
            const userMessage = createMessage({
                role: "user",
                content
            });
            const botMessage = createMessage({
                role: "assistant",
                streaming: true,
                id: userMessage.id + 1,
                model: store_config/* useAppConfig.getState */.MG.getState().modelConfig.model
            });
            // get recent messages
            const recentMessages = get().getMessagesWithMemory();
            const sendMessages = recentMessages.concat(userMessage);
            const sessionIndex = get().currentSessionIndex;
            const messageIndex = get().currentSession().messages.length + 1;
            // save user's and bot's message
            get().updateCurrentSession((session)=>{
                session.messages.push(userMessage);
                session.messages.push(botMessage);
            });
            // make request
            console.log("[User Input] ", sendMessages);
            (0,requests/* requestChatStream */.yY)(sendMessages, {
                onMessage (content, done) {
                    // stream response
                    if (done) {
                        botMessage.streaming = false;
                        botMessage.content = content;
                        get().onNewMessage(botMessage);
                        requests/* ControllerPool.remove */.u4.remove(sessionIndex, botMessage.id ?? messageIndex);
                    } else {
                        botMessage.content = content;
                        set(()=>({}));
                    }
                },
                onError (error, statusCode) {
                    if (statusCode === 401) {
                        botMessage.content = locales/* default.Error.Unauthorized */.ZP.Error.Unauthorized;
                    } else if (!error.message.includes("aborted")) {
                        botMessage.content += "\n\n" + locales/* default.Store.Error */.ZP.Store.Error;
                    }
                    botMessage.streaming = false;
                    userMessage.isError = true;
                    botMessage.isError = true;
                    set(()=>({}));
                    requests/* ControllerPool.remove */.u4.remove(sessionIndex, botMessage.id ?? messageIndex);
                },
                onController (controller) {
                    // collect controller for stop/retry
                    requests/* ControllerPool.addController */.u4.addController(sessionIndex, botMessage.id ?? messageIndex, controller);
                },
                filterBot: !store_config/* useAppConfig.getState */.MG.getState().sendBotMessages,
                modelConfig: store_config/* useAppConfig.getState */.MG.getState().modelConfig
            });
        },
        getMemoryPrompt () {
            const session = get().currentSession();
            return {
                role: "system",
                content: locales/* default.Store.Prompt.History */.ZP.Store.Prompt.History(session.memoryPrompt),
                date: ""
            };
        },
        getMessagesWithMemory () {
            const session = get().currentSession();
            const config = store_config/* useAppConfig.getState */.MG.getState();
            const messages = session.messages.filter((msg)=>!msg.isError);
            const n = messages.length;
            const context = session.context.slice();
            // long term memory
            if (session.sendMemory && session.memoryPrompt && session.memoryPrompt.length > 0) {
                const memoryPrompt = get().getMemoryPrompt();
                context.push(memoryPrompt);
            }
            // get short term and unmemoried long term memory
            const shortTermMemoryMessageIndex = Math.max(0, n - config.historyMessageCount);
            const longTermMemoryMessageIndex = session.lastSummarizeIndex;
            const oldestIndex = Math.max(shortTermMemoryMessageIndex, longTermMemoryMessageIndex);
            const threshold = config.compressMessageLengthThreshold;
            // get recent messages as many as possible
            const reversedRecentMessages = [];
            for(let i = n - 1, count = 0; i >= oldestIndex && count < threshold; i -= 1){
                const msg = messages[i];
                if (!msg || msg.isError) continue;
                count += msg.content.length;
                reversedRecentMessages.push(msg);
            }
            // concat
            const recentMessages = context.concat(reversedRecentMessages.reverse());
            return recentMessages;
        },
        updateMessage (sessionIndex, messageIndex, updater) {
            const sessions = get().sessions;
            const session = sessions.at(sessionIndex);
            const messages = session?.messages;
            updater(messages?.at(messageIndex));
            set(()=>({
                    sessions
                }));
        },
        resetSession () {
            get().updateCurrentSession((session)=>{
                session.messages = [];
                session.memoryPrompt = "";
            });
        },
        summarizeSession () {
            const session = get().currentSession();
            // should summarize topic after chating more than 50 words
            const SUMMARIZE_MIN_LEN = 50;
            if (session.topic === DEFAULT_TOPIC && countMessages(session.messages) >= SUMMARIZE_MIN_LEN) {
                (0,requests/* requestWithPrompt */.qd)(session.messages, locales/* default.Store.Prompt.Topic */.ZP.Store.Prompt.Topic, {
                    model: "gpt-3.5-turbo"
                }).then((res)=>{
                    get().updateCurrentSession((session)=>session.topic = res ? (0,utils/* trimTopic */.ez)(res) : DEFAULT_TOPIC);
                });
            }
            const config = store_config/* useAppConfig.getState */.MG.getState();
            let toBeSummarizedMsgs = session.messages.slice(session.lastSummarizeIndex);
            const historyMsgLength = countMessages(toBeSummarizedMsgs);
            if ((historyMsgLength > config?.modelConfig?.max_tokens) ?? 4000) {
                const n = toBeSummarizedMsgs.length;
                toBeSummarizedMsgs = toBeSummarizedMsgs.slice(Math.max(0, n - config.historyMessageCount));
            }
            // add memory prompt
            toBeSummarizedMsgs.unshift(get().getMemoryPrompt());
            const lastSummarizeIndex = session.messages.length;
            console.log("[Chat History] ", toBeSummarizedMsgs, historyMsgLength, config.compressMessageLengthThreshold);
            if (historyMsgLength > config.compressMessageLengthThreshold && session.sendMemory) {
                (0,requests/* requestChatStream */.yY)(toBeSummarizedMsgs.concat({
                    role: "system",
                    content: locales/* default.Store.Prompt.Summarize */.ZP.Store.Prompt.Summarize,
                    date: ""
                }), {
                    filterBot: false,
                    model: "gpt-3.5-turbo",
                    onMessage (message, done) {
                        session.memoryPrompt = message;
                        if (done) {
                            console.log("[Memory] ", session.memoryPrompt);
                            session.lastSummarizeIndex = lastSummarizeIndex;
                        }
                    },
                    onError (error) {
                        console.error("[Summarize] ", error);
                    }
                });
            }
        },
        updateStat (message) {
            get().updateCurrentSession((session)=>{
                session.stat.charCount += message.content.length;
            // TODO: should update chat count and word count
            });
        },
        updateCurrentSession (updater) {
            const sessions = get().sessions;
            const index = get().currentSessionIndex;
            updater(sessions[index]);
            set(()=>({
                    sessions
                }));
        },
        clearAllData () {
            if (confirm(locales/* default.Store.ConfirmClearAll */.ZP.Store.ConfirmClearAll)) {
                localStorage.clear();
                location.reload();
            }
        }
    }), {
    name: LOCAL_KEY,
    version: 1.2,
    migrate (persistedState, version) {
        const state = persistedState;
        if (version === 1) {
            state.sessions.forEach((s)=>s.context = []);
        }
        if (version < 1.2) {
            state.sessions.forEach((s)=>s.sendMemory = true);
        }
        return state;
    }
}));

// EXTERNAL MODULE: ./app/constant.ts
var constant = __webpack_require__(2080);
;// CONCATENATED MODULE: ./app/store/update.ts




const UPDATE_KEY = "chat-update";
function queryMeta(key, defaultValue) {
    let ret;
    if (document) {
        const meta = document.head.querySelector(`meta[name='${key}']`);
        ret = meta?.content ?? "";
    } else {
        ret = defaultValue ?? "";
    }
    return ret;
}
const ONE_MINUTE = 60 * 1000;
const useUpdateStore = (0,esm/* create */.Ue)()((0,middleware/* persist */.tJ)((set, get)=>({
        lastUpdate: 0,
        remoteVersion: "",
        lastUpdateUsage: 0,
        version: "unknown",
        async getLatestVersion (force = false) {
            set(()=>({
                    version: queryMeta("version") ?? "unknown"
                }));
            const overTenMins = Date.now() - get().lastUpdate > 10 * ONE_MINUTE;
            if (!force && !overTenMins) return;
            set(()=>({
                    lastUpdate: Date.now()
                }));
            try {
                // const data = await (await fetch(FETCH_TAG_URL)).json();
                // const remoteId = data[0].name as string;
                const data = await (await fetch(constant/* FETCH_COMMIT_URL */.TE)).json();
                const remoteId = data[0].sha.substring(0, 7);
                set(()=>({
                        remoteVersion: remoteId
                    }));
                console.log("[Got Upstream] ", remoteId);
            } catch (error) {
                console.error("[Fetch Upstream Commit Id]", error);
            }
        },
        async updateUsage (force = false) {
            const overOneMinute = Date.now() - get().lastUpdateUsage >= ONE_MINUTE;
            if (!overOneMinute && !force) return;
            set(()=>({
                    lastUpdateUsage: Date.now()
                }));
            const usage = await (0,requests/* requestUsage */.b6)();
            if (usage) {
                set(()=>usage);
            }
        }
    }), {
    name: UPDATE_KEY,
    version: 1
}));

;// CONCATENATED MODULE: ./app/store/access.ts


const ACCESS_KEY = "access-control";
let fetchState = 0; // 0 not fetch, 1 fetching, 2 done
const useAccessStore = (0,esm/* create */.Ue)()(// 密码
(0,middleware/* persist */.tJ)((set, get)=>({
        token: "",
        accessCode: "",
        needCode: true,
        enabledAccessControl () {
            get().fetch();
            return get().needCode;
        },
        updateCode (code) {
            set((state)=>({
                    accessCode: code
                }));
        },
        updateToken (token) {
            set((state)=>({
                    token
                }));
        },
        isAuthorized () {
            // has token or has code or disabled access control
            return !!get().token || !!get().accessCode || !get().enabledAccessControl();
        },
        fetch () {
            if (fetchState > 0) return;
            fetchState = 1;
            fetch("/api/config", {
                method: "post",
                body: null
            }).then((res)=>res.json()).then((res)=>{
                console.log("[Config] got config from server", res);
                set(()=>({
                        ...res
                    }));
            }).catch(()=>{
                console.error("[Config] failed to fetch config");
            }).finally(()=>{
                fetchState = 2;
            });
        }
    }), {
    name: ACCESS_KEY,
    version: 1
}));

;// CONCATENATED MODULE: ./app/store/index.ts






/***/ }),

/***/ 9498:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "f5": () => (/* binding */ usePromptStore),
/* harmony export */   "oD": () => (/* binding */ SearchService)
/* harmony export */ });
/* unused harmony export PROMPT_KEY */
/* harmony import */ var zustand__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3998);
/* harmony import */ var zustand_middleware__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8658);
/* harmony import */ var fuse_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5971);
/* harmony import */ var fuse_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(fuse_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _locales__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1452);




const PROMPT_KEY = "prompt-store";
const SearchService = {
    ready: false,
    builtinEngine: new (fuse_js__WEBPACK_IMPORTED_MODULE_1___default())([], {
        keys: [
            "title"
        ]
    }),
    userEngine: new (fuse_js__WEBPACK_IMPORTED_MODULE_1___default())([], {
        keys: [
            "title"
        ]
    }),
    count: {
        builtin: 0
    },
    allPrompts: [],
    builtinPrompts: [],
    init (builtinPrompts, userPrompts) {
        if (this.ready) {
            return;
        }
        this.allPrompts = userPrompts.concat(builtinPrompts);
        this.builtinPrompts = builtinPrompts.slice();
        this.builtinEngine.setCollection(builtinPrompts);
        this.userEngine.setCollection(userPrompts);
        this.ready = true;
    },
    remove (id) {
        this.userEngine.remove((doc)=>doc.id === id);
    },
    add (prompt) {
        this.userEngine.add(prompt);
    },
    search (text) {
        const userResults = this.userEngine.search(text);
        const builtinResults = this.builtinEngine.search(text);
        return userResults.concat(builtinResults).map((v)=>v.item);
    }
};
const usePromptStore = (0,zustand__WEBPACK_IMPORTED_MODULE_2__/* .create */ .Ue)()((0,zustand_middleware__WEBPACK_IMPORTED_MODULE_3__/* .persist */ .tJ)((set, get)=>({
        counter: 0,
        latestId: 0,
        prompts: {},
        add (prompt) {
            const prompts = get().prompts;
            prompt.id = get().latestId + 1;
            prompt.isUser = true;
            prompts[prompt.id] = prompt;
            set(()=>({
                    latestId: prompt.id,
                    prompts: prompts
                }));
            return prompt.id;
        },
        remove (id) {
            const prompts = get().prompts;
            delete prompts[id];
            SearchService.remove(id);
            set(()=>({
                    prompts,
                    counter: get().counter + 1
                }));
        },
        getUserPrompts () {
            const userPrompts = Object.values(get().prompts ?? {});
            userPrompts.sort((a, b)=>b.id && a.id ? b.id - a.id : 0);
            return userPrompts;
        },
        updateUserPrompts (id, updater) {
            const prompt = get().prompts[id] ?? {
                title: "",
                content: "",
                id
            };
            SearchService.remove(id);
            updater(prompt);
            const prompts = get().prompts;
            prompts[id] = prompt;
            set(()=>({
                    prompts
                }));
            SearchService.add(prompt);
        },
        search (text) {
            if (text.length === 0) {
                // return all rompts
                return SearchService.allPrompts.concat([
                    ...get().getUserPrompts()
                ]);
            }
            return SearchService.search(text);
        }
    }), {
    name: PROMPT_KEY,
    version: 1,
    onRehydrateStorage (state) {
        const PROMPT_URL = "./prompts.json";
        fetch(PROMPT_URL).then((res)=>res.json()).then((res)=>{
            let fetchPrompts = [
                res.en,
                res.cn
            ];
            if ((0,_locales__WEBPACK_IMPORTED_MODULE_0__/* .getLang */ .VQ)() === "cn") {
                fetchPrompts = fetchPrompts.reverse();
            }
            const builtinPrompts = fetchPrompts.map((promptList)=>{
                return promptList.map(([title, content])=>({
                        id: Math.random(),
                        title,
                        content
                    }));
            });
            const userPrompts = usePromptStore.getState().getUserPrompts() ?? [];
            const allPromptsForSearch = builtinPrompts.reduce((pre, cur)=>pre.concat(cur), []).filter((v)=>!!v.title && !!v.content);
            SearchService.count.builtin = res.en.length + res.cn.length;
            SearchService.init(allPromptsForSearch, userPrompts);
        });
    }
}));


/***/ }),

/***/ 6433:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Av": () => (/* binding */ isMobileScreen),
/* harmony export */   "CP": () => (/* binding */ downloadAs),
/* harmony export */   "K1": () => (/* binding */ getCSSVar),
/* harmony export */   "Ri": () => (/* binding */ selectOrCopy),
/* harmony export */   "S0": () => (/* binding */ useMobileScreen),
/* harmony export */   "ez": () => (/* binding */ trimTopic),
/* harmony export */   "lx": () => (/* binding */ autoGrowTextArea),
/* harmony export */   "qc": () => (/* binding */ getEmojiUrl),
/* harmony export */   "vQ": () => (/* binding */ copyToClipboard)
/* harmony export */ });
/* unused harmony exports isIOS, isFirefox */
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_ui_lib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2634);
/* harmony import */ var _locales__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1452);



function trimTopic(topic) {
    return topic.replace(/[，。！？”“"、,.!?]*$/, "");
}
async function copyToClipboard(text) {
    try {
        await navigator.clipboard.writeText(text);
        (0,_components_ui_lib__WEBPACK_IMPORTED_MODULE_1__/* .showToast */ .CF)(_locales__WEBPACK_IMPORTED_MODULE_2__/* ["default"].Copy.Success */ .ZP.Copy.Success);
    } catch (error) {
        const textArea = document.createElement("textarea");
        textArea.value = text;
        document.body.appendChild(textArea);
        textArea.focus();
        textArea.select();
        try {
            document.execCommand("copy");
            (0,_components_ui_lib__WEBPACK_IMPORTED_MODULE_1__/* .showToast */ .CF)(_locales__WEBPACK_IMPORTED_MODULE_2__/* ["default"].Copy.Success */ .ZP.Copy.Success);
        } catch (error) {
            (0,_components_ui_lib__WEBPACK_IMPORTED_MODULE_1__/* .showToast */ .CF)(_locales__WEBPACK_IMPORTED_MODULE_2__/* ["default"].Copy.Failed */ .ZP.Copy.Failed);
        }
        document.body.removeChild(textArea);
    }
}
function downloadAs(text, filename) {
    const element = document.createElement("a");
    element.setAttribute("href", "data:text/plain;charset=utf-8," + encodeURIComponent(text));
    element.setAttribute("download", filename);
    element.style.display = "none";
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
}
function isIOS() {
    const userAgent = navigator.userAgent.toLowerCase();
    return /iphone|ipad|ipod/.test(userAgent);
}
function useMobileScreen() {
    const [isMobileScreen_, setIsMobileScreen] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(isMobileScreen());
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        const onResize = ()=>{
            setIsMobileScreen(isMobileScreen());
        };
        window.addEventListener("resize", onResize);
        return ()=>{
            window.removeEventListener("resize", onResize);
        };
    }, []);
    return isMobileScreen_;
}
function isMobileScreen() {
    if (true) {
        return false;
    }
    return window.innerWidth <= 600;
}
function isFirefox() {
    return typeof navigator !== "undefined" && /firefox/i.test(navigator.userAgent);
}
function selectOrCopy(el, content) {
    const currentSelection = window.getSelection();
    if (currentSelection?.type === "Range") {
        return false;
    }
    copyToClipboard(content);
    return true;
}
function getEmojiUrl(unified, style) {
    return `https://cdn.staticfile.org/emoji-datasource-apple/14.0.0/img/${style}/64/${unified}.png`;
}
function getDomContentWidth(dom) {
    const style = window.getComputedStyle(dom);
    const paddingWidth = parseFloat(style.paddingLeft) + parseFloat(style.paddingRight);
    const width = dom.clientWidth - paddingWidth;
    return width;
}
function getOrCreateMeasureDom(id, init) {
    let dom = document.getElementById(id);
    if (!dom) {
        dom = document.createElement("span");
        dom.style.position = "absolute";
        dom.style.wordBreak = "break-word";
        dom.style.fontSize = "14px";
        dom.style.transform = "translateY(-200vh)";
        dom.style.pointerEvents = "none";
        dom.style.opacity = "0";
        dom.id = id;
        document.body.appendChild(dom);
        init?.(dom);
    }
    return dom;
}
function autoGrowTextArea(dom) {
    const measureDom = getOrCreateMeasureDom("__measure");
    const singleLineDom = getOrCreateMeasureDom("__single_measure", (dom)=>{
        dom.innerText = "TEXT_FOR_MEASURE";
    });
    const width = getDomContentWidth(dom);
    measureDom.style.width = width + "px";
    measureDom.innerHTML = dom.value.trim().length > 0 ? dom.value : "1";
    const lineWrapCount = Math.max(0, dom.value.split("\n").length - 1);
    const height = parseFloat(window.getComputedStyle(measureDom).height);
    const singleLineHeight = parseFloat(window.getComputedStyle(singleLineDom).height);
    const rows = Math.round(height / singleLineHeight) + lineWrapCount;
    return rows;
}
function getCSSVar(varName) {
    return getComputedStyle(document.body).getPropertyValue(varName).trim();
}


/***/ }),

/***/ 373:
/***/ ((module) => {

// Exports
module.exports = {
	"icon-button": "button_icon-button__BC_Ca",
	"shadow": "button_shadow__Ap98F",
	"border": "button_border__nGPHl",
	"icon-button-icon": "button_icon-button-icon__qlUH3",
	"icon-button-text": "button_icon-button-text__k3vob"
};


/***/ }),

/***/ 3493:
/***/ ((module) => {

// Exports
module.exports = {
	"chat-input-actions": "chat_chat-input-actions__fJw2y",
	"chat-input-action": "chat_chat-input-action__dB24v",
	"slide-in": "chat_slide-in__jGTU7",
	"prompt-toast": "chat_prompt-toast__v0Ha5",
	"prompt-toast-inner": "chat_prompt-toast-inner__qUzGo",
	"slide-in-from-top": "chat_slide-in-from-top__QIZOS",
	"prompt-toast-content": "chat_prompt-toast-content__tDz2h",
	"context-prompt": "chat_context-prompt__a3Xrj",
	"context-prompt-row": "chat_context-prompt-row__D24xk",
	"context-role": "chat_context-role___RwCJ",
	"context-content": "chat_context-content__3iEuJ",
	"context-delete-button": "chat_context-delete-button__rSrlO",
	"context-prompt-button": "chat_context-prompt-button__MmudR",
	"memory-prompt": "chat_memory-prompt__HLWNg",
	"memory-prompt-title": "chat_memory-prompt-title__eZIzp",
	"memory-prompt-action": "chat_memory-prompt-action__eyGdY",
	"memory-prompt-content": "chat_memory-prompt-content__Zgo_G"
};


/***/ }),

/***/ 7986:
/***/ ((module) => {

// Exports
module.exports = {
	"window-header": "home_window-header__248BE",
	"window-header-title": "home_window-header-title__bJCkO",
	"window-header-main-title": "home_window-header-main-title__Y16Es",
	"window-header-sub-title": "home_window-header-sub-title__9rZM1",
	"window-actions": "home_window-actions__k4f3s",
	"window-action-button": "home_window-action-button__Is6GK",
	"container": "home_container__Myqoy",
	"tight-container": "home_tight-container__sz6zy",
	"sidebar": "home_sidebar__4L4yT",
	"sidebar-drag": "home_sidebar-drag__hOnXd",
	"window-content": "home_window-content__RRVow",
	"mobile": "home_mobile__ako7k",
	"sidebar-show": "home_sidebar-show__I77cg",
	"sidebar-header": "home_sidebar-header__b5asC",
	"sidebar-logo": "home_sidebar-logo__FFdBS",
	"sidebar-title": "home_sidebar-title__d8_c_",
	"slide-in": "home_slide-in__gYZA0",
	"sidebar-sub-title": "home_sidebar-sub-title__IS2Or",
	"sidebar-body": "home_sidebar-body__zSPJN",
	"chat-item": "home_chat-item__7LfQR",
	"chat-item-selected": "home_chat-item-selected__6TyNm",
	"chat-item-title": "home_chat-item-title__LZXA_",
	"chat-item-delete": "home_chat-item-delete__xQ_8e",
	"chat-item-info": "home_chat-item-info__UAzOv",
	"chat-item-count": "home_chat-item-count__pilKg",
	"chat-item-date": "home_chat-item-date__0scNw",
	"narrow-sidebar": "home_narrow-sidebar__htVlK",
	"chat-item-narrow": "home_chat-item-narrow__JELZ0",
	"sidebar-tail": "home_sidebar-tail__R8VX2",
	"sidebar-actions": "home_sidebar-actions__zyNfR",
	"sidebar-action": "home_sidebar-action__JhMu0",
	"chat": "home_chat__7Bh_I",
	"chat-body": "home_chat-body__mbaM8",
	"chat-body-title": "home_chat-body-title__5S8w4",
	"chat-message": "home_chat-message__rdH_g",
	"chat-message-user": "home_chat-message-user__WsuiB",
	"chat-message-container": "home_chat-message-container__plj_e",
	"chat-message-top-actions": "home_chat-message-top-actions__PfOzb",
	"chat-message-avatar": "home_chat-message-avatar__611lI",
	"chat-message-status": "home_chat-message-status__EsVNi",
	"user-avtar": "home_user-avtar__3QksJ",
	"chat-message-item": "home_chat-message-item__hDEOq",
	"chat-message-top-action": "home_chat-message-top-action__wXKmA",
	"chat-message-actions": "home_chat-message-actions__nrHd1",
	"chat-message-action-date": "home_chat-message-action-date__6ToUp",
	"chat-input-panel": "home_chat-input-panel__kmhBn",
	"prompt-hints": "home_prompt-hints__Nv0JN",
	"prompt-hint": "home_prompt-hint__7bycW",
	"hint-title": "home_hint-title__V1gw6",
	"hint-content": "home_hint-content__GHRmC",
	"prompt-hint-selected": "home_prompt-hint-selected__LI_5l",
	"chat-input-panel-inner": "home_chat-input-panel-inner__8J59p",
	"chat-input": "home_chat-input__qM_hd",
	"chat-input-send": "home_chat-input-send__rsJfH",
	"export-content": "home_export-content__ZTj0v",
	"loading-content": "home_loading-content__tru2c",
	"slide-in-from-top": "home_slide-in-from-top__DysOS"
};


/***/ }),

/***/ 3304:
/***/ ((module) => {

// Exports
module.exports = {
	"card": "ui-lib_card__umMjN",
	"popover": "ui-lib_popover__5cywD",
	"popover-content": "ui-lib_popover-content__gZ0he",
	"slide-in": "ui-lib_slide-in__iob7i",
	"popover-mask": "ui-lib_popover-mask__iViG8",
	"list-item": "ui-lib_list-item__MN4sf",
	"list": "ui-lib_list__uHeWh",
	"modal-container": "ui-lib_modal-container__Ra9HB",
	"modal-header": "ui-lib_modal-header__S9ma8",
	"modal-title": "ui-lib_modal-title__i_dpP",
	"modal-close-btn": "ui-lib_modal-close-btn__mIjOX",
	"modal-content": "ui-lib_modal-content__nFcGO",
	"modal-footer": "ui-lib_modal-footer__J_cgq",
	"modal-actions": "ui-lib_modal-actions__0VvYa",
	"modal-action": "ui-lib_modal-action__12xLt",
	"show": "ui-lib_show__3Gd4p",
	"hide": "ui-lib_hide__GF1sp",
	"toast-container": "ui-lib_toast-container__7epyd",
	"toast-content": "ui-lib_toast-content__XpHSf",
	"toast-action": "ui-lib_toast-action__wO4Lv",
	"input": "ui-lib_input__v_cwR",
	"slide-in-from-top": "ui-lib_slide-in-from-top__Qfsdu"
};


/***/ }),

/***/ 6830:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "g": () => (/* binding */ getServerSideConfig)
/* harmony export */ });
/* harmony import */ var spark_md5__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8197);
/* harmony import */ var spark_md5__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(spark_md5__WEBPACK_IMPORTED_MODULE_0__);

const ACCESS_CODES = function getAccessCodes() {
    const code = process.env.CODE;
    try {
        const codes = (code?.split(",") ?? []).filter((v)=>!!v).map((v)=>spark_md5__WEBPACK_IMPORTED_MODULE_0___default().hash(v.trim()));
        return new Set(codes);
    } catch (e) {
        return new Set();
    }
}();
const getServerSideConfig = ()=>{
    if (typeof process === "undefined") {
        throw Error("[Server Config] you are importing a nodejs-only module outside of nodejs");
    }
    return {
        apiKey: "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:7gbzRcji",
        code: process.env.CODE,
        codes: ACCESS_CODES,
        needCode: ACCESS_CODES.size > 0,
        proxyUrl: process.env.PROXY_URL,
        isVercel: !!process.env.VERCEL
    };
};


/***/ }),

/***/ 8666:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ RootLayout),
  "metadata": () => (/* binding */ metadata)
});

// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(3146);
// EXTERNAL MODULE: ./app/styles/globals.scss
var globals = __webpack_require__(8036);
// EXTERNAL MODULE: ./app/styles/markdown.scss
var markdown = __webpack_require__(5322);
// EXTERNAL MODULE: ./app/styles/highlight.scss
var highlight = __webpack_require__(6741);
;// CONCATENATED MODULE: ./app/config/build.ts
const COMMIT_ID = (()=>{
    try {
        const childProcess = __webpack_require__(2081);
        return childProcess// .execSync("git describe --tags --abbrev=0")
        .execSync("git rev-parse --short HEAD").toString().trim();
    } catch (e) {
        console.error("[Build Config] No git or not from git repo.");
        return "unknown";
    }
})();
const getBuildConfig = ()=>{
    if (typeof process === "undefined") {
        throw Error("[Server Config] you are importing a nodejs-only module outside of nodejs");
    }
    return {
        commitId: COMMIT_ID
    };
};

;// CONCATENATED MODULE: ./app/layout.tsx
/* eslint-disable @next/next/no-page-custom-font */ 




const buildConfig = getBuildConfig();
const metadata = {
    title: "高济AI",
    description: "Your personal ChatGPT Chat Bot.",
    appleWebApp: {
        title: "高济AI",
        statusBarStyle: "default"
    },
    themeColor: "#fafafa"
};
function RootLayout({ children  }) {
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("html", {
        lang: "en",
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("head", {
                children: [
                    /*#__PURE__*/ jsx_runtime.jsx("meta", {
                        name: "viewport",
                        content: "width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0"
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("meta", {
                        name: "theme-color",
                        content: "#151515",
                        media: "(prefers-color-scheme: dark)"
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("meta", {
                        name: "version",
                        content: buildConfig.commitId
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("link", {
                        rel: "manifest",
                        href: "/site.webmanifest"
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("link", {
                        rel: "preconnect",
                        href: "https://fonts.googleapis.com"
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("link", {
                        rel: "preconnect",
                        href: "https://fonts.gstatic.com"
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("link", {
                        href: "https://fonts.googleapis.com/css2?family=Noto+Sans+SC:wght@300;400;700;900&display=swap",
                        rel: "stylesheet"
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("script", {
                        src: "/serviceWorkerRegister.js",
                        defer: true
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime.jsx("body", {
                children: children
            })
        ]
    });
}


/***/ }),

/***/ 3877:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ App)
});

// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(3146);
// EXTERNAL MODULE: ./node_modules/@vercel/analytics/dist/react/index.js
var react = __webpack_require__(4732);
// EXTERNAL MODULE: ./node_modules/next/dist/build/webpack/loaders/next-flight-loader/module-proxy.js
var module_proxy = __webpack_require__(5985);
;// CONCATENATED MODULE: ./app/components/home.tsx

const proxy = (0,module_proxy.createProxy)(String.raw`E:\code\ChatGPT-Next-Web-main\app\components\home.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
/* harmony default export */ const home = (proxy.default);

const e0 = proxy["Loading"];

const e1 = proxy["useSwitchTheme"];

const e2 = proxy["Home"];

// EXTERNAL MODULE: ./app/config/server.ts
var server = __webpack_require__(6830);
;// CONCATENATED MODULE: ./app/page.tsx




const serverConfig = (0,server/* getServerSideConfig */.g)();
async function App() {
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime.jsx(e2, {}),
            serverConfig?.isVercel && /*#__PURE__*/ jsx_runtime.jsx(react/* Analytics */.cp, {})
        ]
    });
}


/***/ }),

/***/ 8036:
/***/ (() => {



/***/ }),

/***/ 6741:
/***/ (() => {



/***/ }),

/***/ 5322:
/***/ (() => {



/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [713,529], () => (__webpack_exec__(1890)));
module.exports = __webpack_exports__;

})();