"use strict";
exports.id = 182;
exports.ids = [182];
exports.modules = {

/***/ 8182:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Markdown": () => (/* binding */ Markdown),
/* harmony export */   "PreCode": () => (/* binding */ PreCode)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_markdown__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7060);
/* harmony import */ var katex_dist_katex_min_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4095);
/* harmony import */ var katex_dist_katex_min_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(katex_dist_katex_min_css__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var remark_math__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1645);
/* harmony import */ var remark_breaks__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(415);
/* harmony import */ var rehype_katex__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(8546);
/* harmony import */ var remark_gfm__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6231);
/* harmony import */ var rehype_highlight__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(3247);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6433);
/* harmony import */ var _icons_three_dots_svg__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3076);











function PreCode(props) {
    const ref = (0,react__WEBPACK_IMPORTED_MODULE_2__.useRef)(null);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("pre", {
        ref: ref,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                className: "copy-code-button",
                onClick: ()=>{
                    if (ref.current) {
                        const code = ref.current.innerText;
                        (0,_utils__WEBPACK_IMPORTED_MODULE_3__/* .copyToClipboard */ .vQ)(code);
                    }
                }
            }),
            props.children
        ]
    });
}
function Markdown(props) {
    const mdRef = (0,react__WEBPACK_IMPORTED_MODULE_2__.useRef)(null);
    const parent = props.parentRef.current;
    const md = mdRef.current;
    const rendered = (0,react__WEBPACK_IMPORTED_MODULE_2__.useRef)(true); // disable lazy loading for bad ux
    const [counter, setCounter] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(0);
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        // to triggr rerender
        setCounter(counter + 1);
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        props.loading
    ]);
    const inView = rendered.current || (()=>{
        if (parent && md) {
            const parentBounds = parent.getBoundingClientRect();
            const mdBounds = md.getBoundingClientRect();
            const isInRange = (x)=>x <= parentBounds.bottom && x >= parentBounds.top;
            const inView = isInRange(mdBounds.top) || isInRange(mdBounds.bottom);
            if (inView) {
                rendered.current = true;
            }
            return inView;
        }
    })();
    const shouldLoading = props.loading || !inView;
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "markdown-body",
        style: {
            fontSize: `${props.fontSize ?? 14}px`
        },
        ref: mdRef,
        onContextMenu: props.onContextMenu,
        onDoubleClickCapture: props.onDoubleClickCapture,
        children: shouldLoading ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_icons_three_dots_svg__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {}) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_markdown__WEBPACK_IMPORTED_MODULE_5__/* .ReactMarkdown */ .D, {
            remarkPlugins: [
                remark_math__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z,
                remark_gfm__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z,
                remark_breaks__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z
            ],
            rehypePlugins: [
                rehype_katex__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z,
                [
                    rehype_highlight__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z,
                    {
                        detect: false,
                        ignoreMissing: true
                    }
                ]
            ],
            components: {
                pre: PreCode
            },
            linkTarget: "_blank",
            children: props.content
        })
    });
}


/***/ })

};
;